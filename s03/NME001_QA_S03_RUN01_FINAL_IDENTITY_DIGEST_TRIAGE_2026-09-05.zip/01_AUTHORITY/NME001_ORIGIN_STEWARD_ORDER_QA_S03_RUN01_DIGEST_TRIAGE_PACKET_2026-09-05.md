# Project Nexus — Steward Order for S03 RUN01 QA Triage Packet

**Identity:** `NME001-ORIGIN-STEWARD-ORDER-QA-S03-RUN01-DIGEST-TRIAGE-PACKET-01`  
**Issued:** `2026-09-05T21:06:37Z`  
**Disposition:** `FORMAL_QA_TRIAGE_AUTHORIZED / STEWARD_PACKET_ASSEMBLY_AUTHORIZED / DEVELOPER_REMAINS_STOPPED`  
**Scope:** `POST_2026-09-02_DELTA / PACKAGING_AND_DIAGNOSTIC_REVIEW_ONLY / ZERO_SCIENTIFIC_VOTE`  
**Product Owner approval:** `ALREADY_GRANTED_BY_DIRECT_REQUEST`

## 1. Controlling state

Accept the exact S03 return as:

`S03_RUN01_DEFINED_STOP / RUN01_CONSUMED / INCOMPLETE_NOT_EVIDENCE / HERMETIC_980_OF_980_PASS / LICENSED_INCLUSIVE_1041_OF_1041_PASS / POST_LICENSED_PLACEMENT_REHASH_PASS / SCIENTIFIC_DEVELOPMENT_FAILED / NO_SCIENTIFIC_RESULT / NO_SEALED_RETURN`.

Controlling stop:

- `NME001_EPOCH07_S03_RUN01_SCIENTIFIC_DEVELOPMENT_DEFINED_STOP_2026-09-05.json`
- Library `libfile_12ba2627f2b88191b3e3128eb2efb401`, version `0`
- 9,497 bytes
- SHA-256 `90c9cc26b6ec36860bea0fbc010b87cb4926bc1ae819c0ff913f295b0137c990`
- fresh readback `PASS`

The unchanged command failed with `S02ExecutionError: frozen final ordered identity digest mismatch`. The failure occurred after both engineering lanes and the nine-placement rehash passed, but before the Kibot development prefix was read, the corporate-action ledger was parsed, a scientific result was emitted, or a historical-final payload byte was accessed. Historical-final outcomes remain unopened. The passing lanes are diagnostic only and are not official evidence because RUN01 did not complete and no sealed return or final review exists.

Writer Lease 03 is closed. No Developer writer is active. No scientific-stage resume, RUN02, Lease 04, checkpoint v4, source edit, rerun, or evidence promotion is authorized while QA triage is pending.

## 2. Incoming QA baseline and delta rule

Outside QA supplied `NME001_THIRD_PARTY_QA_KNOWLEDGE_STATE_2026-09-05.zip`:

- Library `libfile_ff31f30a37808191ac917ded5d6b2e33`
- 84,800 bytes
- SHA-256 `a0c10beac6a5aef00334ad7e0bc880e4ab2e09d696b7257b6116171889604358`
- its `01_HELD_ARTIFACT_INVENTORY_SHA256.txt` SHA-256 is `99431d7acfd918ef321dfa38779be4a09ca338a26896ac01e4c6672b6e600dfe`
- archive integrity, internal SHA list, path safety, duplicate-path check, and nested-archive check all `PASS`

That packet establishes QA's knowledge horizon through `2026-09-02`. QA already holds the August 29–September 2 DWO-04/DWO-05, Kibot acceptance-delta, prior QA, and TVCA corpus. Do not copy that history back to QA. Bind this baseline in `00_READ_FIRST.md` and supply only the causal post-horizon delta. Do not place QA's incoming ZIP inside the outgoing ZIP.

Require `00_READ_FIRST.md` to state:

```text
CONTEXT MODEL: INCOMING_QA_BASELINE_PLUS_THIS_DELTA_PACKET

This outgoing ZIP is a post-2026-09-02 delta, not a standalone project history.
Outside QA and any advisory Developer must use it together with
NME001_THIRD_PARTY_QA_KNOWLEDGE_STATE_2026-09-05.zip,
SHA-256 a0c10beac6a5aef00334ad7e0bc880e4ab2e09d696b7257b6116171889604358.
If that baseline is unavailable, do not claim a full-context review; return
INSUFFICIENT_CONTEXT.
```

The old `07_DRAFT_PAUSE_RATIFICATION_DIRECTIVE_2026-08-29.md` is `HISTORICAL_REFERENCE / NONCONTROLLING / NO_CURRENT_AUTHORITY`; never place it in an active-instructions compartment.

## 3. Preliminary Origin hypothesis — independent QA verification required

This is a diagnostic lead, not an adopted finding:

1. The exact frozen identity file passed its filename, whole-file SHA-256 `db4737f03b94c1779ccd186b675d0a41fb33af3e165a949c36e476bef224c003`, count `630`, first session `2022-06-22`, and last session `2024-12-31` checks.
2. Nexus's established `exposure.session_identity_bytes` convention serializes the ordered dates as a compact JSON array plus one terminal LF. It produces the frozen digest `423f3ad6a8b398b12700710cdb37584ded4beac091d985118a7ebebf159bf429`. Outside QA reports independently reproducing the canonical identity, displayed in its return as `423f3ad6...`.
3. `s02_execution.load_frozen_final_identities` appears to serialize one ISO date plus LF per line. On the same 630 dates that produces `ba899593920081b0ee17a2e19c7331fef9defd1a96a57c2901006f3c120013b2`, then fails against the frozen digest.
4. Its synthetic test appears to derive its expectation with the same newline-per-date algorithm, permitting test and implementation to agree with each other while disagreeing with the real frozen contract.

The separate `authority_order_sha256` value `8c340da0f567d68bd812daca1950d427f0cf39ba09ea7fa287709de60d046b2d` identifies the governing DWO-03 order. It is not another serialization of the 630 dates. The unrelated nine-session technical-event digest begins `c7f252dd...`; it is not the historical-final identity.

QA must reproduce or reject each point from exact packet bytes. Do not change the 630-date identity file or frozen `423f...f429` value merely to make execution pass. A change to either is out of scope unless QA first proves an authoritative conflict.

## 4. Steward assignment and packet layout

Create exactly one packet:

`NME001_QA_S03_RUN01_FINAL_IDENTITY_DIGEST_TRIAGE_2026-09-05.zip`

Place it in `/Project Nexus/03_QA/OUTGOING/`. Build only from exact durable Library records through the allowlist below. Do not interrupt Developer, inspect or package a mutable workspace, move originals, rename authoritative files, change their bytes, or adjudicate the defect.

Use this lean layout:

```text
00_READ_FIRST.md
PACKAGE_CONTENTS.json
MANIFEST_SHA256SUMS.txt
01_AUTHORITY/
02_SOURCE_CHECKPOINT/
03_RUN01_CORE_DIAGNOSTICS/
```

Generated metadata is limited to the three root files above. Nest the checkpoint ZIP byte-for-byte; do not unpack and repack it as a substitute.

## 5. Exact copied-byte allowlist

### `01_AUTHORITY/`

Include unchanged:

1. `NME001_ORIGIN_EPOCH07_S03_POST_CHECKPOINT_RECOVERY_AND_RUN01_2026-09-05.md` — `libfile_8a0d418fea648191bd9a3ef93154f1a2`, version `0`, 17,343 bytes, SHA-256 `17efb16a19fa403aca9e98388129a7bfab976a39861df0300e4222fb25a047ea`.
2. `NME001_ORIGIN_EPOCH07_S02_V4_CONTROL_PROJECTION_AND_CONFORMANCE_REMEDIATION_2026-09-04.json` — `libfile_96adab97fea88191a3218df17cc83033`, version `0`, 13,805 bytes, SHA-256 `2d42306ab9a37d225fe6354345bbd6826d69d5bc8da1d47025ef0803f7f3b03b`.
3. `NME001_ORIGIN_EPOCH07_S03_DURABILITY_PREFIX_REMEDIATION_AND_RUN01_CONTINUATION_2026-09-05.md` — `libfile_3b6c79761e40819185e27684e25ed4d3`, version `0`, 12,885 bytes, SHA-256 `e773e9abaaa167965587f46ca82433d65a4592e7dbb8af203a84e338d23f5e70`.
4. `NME001_ORIGIN_EPOCH07_PROVENANCE_SAFE_CONTINUATION_2026-09-03.md` — `libfile_b5fb67f073dc8191b6a294097fc3e0c4`, version `0`, 10,607 bytes, SHA-256 `ae268b60d68dde4c751fe2728eec3fb9e9ea9b0c12ec8141897ad08b0e8d302c`; classify `INHERITED_LINEAGE / NONCONTROLLING_WHERE_SUPERSEDED`.
5. This Steward order after its durable Library identity is known.

State precedence explicitly: current defined stop, then Lease-03 continuation, S03 parent, and scientific control projection. Epoch-07 lineage cannot override their later terms.

Use `00_READ_FIRST.md` for a compact current role/authority map. Product Owner authority is reserved for material scientific changes, spending/provider/account/security action, historical-final opening, authority promotion, broker/trading/automation, public disclosure, and destructive action. Origin owns bounded direction and disposition within the adopted goal. Developer is stopped with no lease. Outside QA is an independent documentary/technical reviewer with zero execution authority. Steward only assembles and files the packet and gains no new private-data custodian authority; protected inputs remain under their existing custody controls. Live Market Desk may make descriptive current-market observations only. TradingView Lab develops the separate direct interpreter. Researcher may develop research candidates but cannot purchase, implement, or approve modules. All trading, broker, alerting, predictive-release, and automated-action authority remains `NONE`. Nexus is active; unrelated projects remain paused.

Also state that the historical `1,461` count was rejected as unsupported and is noncontrolling; the prospective named inventories and ordered digests govern. Historical candidate, return, or PASS-shaped documents nested inside checkpoint v3 are checkpoint/source context only and cannot override the current `INCOMPLETE_NOT_EVIDENCE` stop.

Do not copy the Compass or any role memory. They are navigation, not evidence, and contain rapidly changing or historical execution summaries. The exact controls and stop govern.

### `02_SOURCE_CHECKPOINT/`

Include as one unchanged nested ZIP:

- `NME001_SEO01_RECOVERY_EPOCH07_S02_PROSPECTIVE_SOURCE_CHECKPOINT.zip`
- Library `libfile_04f5f1bfe55881919e025e0214c2f06d`, version `3`
- 3,966,322 bytes
- SHA-256 `c046792f90ab2362993bf556e3a8abc855524af2b88d41823d6c4986c6f22894`
- manifest SHA-256 `5a4e3f4d10943918b4525cd0b21fcf514aebb93c6caeff6fb68d072faf9febbf`
- source-tree SHA-256 `8f53575bb5101096be63809cd9096217f0092c59a9c85ba3ba60208b781cab78`
- `169/169` manifest-bound payload members verified

The archive has `170` paths: `169` manifest-bound members plus the prospective-checkpoint manifest. Its allowed categories are sanitized artifacts (including historical candidate ZIPs), configuration, receipt metadata, documentation, governance, recovery records, source, tests, `pyproject.toml`, `uv.lock`, and the checkpoint manifest. Recursively inventory its nested archives. It must contain no private fixture payload, Kibot/raw market data, historical-final bars, outcomes, or `data/raw` member.

Point QA to these paths inside the nested checkpoint without duplicating extracted copies:

- `src/nexus_nme001/s02_execution.py`
- `src/nexus_nme001/exposure.py`
- `src/nexus_nme001/calendar.py`
- `src/nexus_nme001/partitions.py`
- `tests/test_s02_execution.py`
- `tests/test_identity_dwo02.py`
- `tests/test_exposure_dwo04.py`
- `tests/test_partitions_holdout.py`
- `config/frozen_config.json`
- `governance/NEXUS_MARKET_EXPERIMENT_001_v1_2_2.md`
- `governance/NME001_HISTORICAL_FINAL_IDENTITIES_2022-06-22_TO_2024-12-31.json`
- `governance/NME001_PRIOR_EXPOSURE_LEDGER_v1_0_1.json`
- `s02_recovery/S02_DEPENDENCY_PROJECTION.json`
- `s02_recovery/S02_TEST_INVENTORIES.json`

A separate checkpoint-v3 freeze/review receipt is `NOT_SEPARATELY_RESOLVED / NOT_INCLUDED / NOT_RECONSTRUCTED`; rely on the checkpoint's own manifest and the copied S03 parent control.

### `03_RUN01_CORE_DIAGNOSTICS/`

Include unchanged. Label items 1–3 `CORE_CAUSAL_DIAGNOSTIC / NOT_EVIDENCE` and items 4–7 `SUPPORTING_LANE_CONTEXT / NOT_EVIDENCE`:

1. `NME001_EPOCH07_S03_RUN01_SCIENTIFIC_DEVELOPMENT_DEFINED_STOP_2026-09-05.json` — `libfile_12ba2627f2b88191b3e3128eb2efb401`, v0, 9,497 bytes, SHA-256 `90c9cc26b6ec36860bea0fbc010b87cb4926bc1ae819c0ff913f295b0137c990`.
2. `s03_supervisor.log` — `libfile_c75b37feecb081918612e03e9bcc3038`, v0, 6,261 bytes, SHA-256 `ad42bc57d3ab8f8d155545a12dd8a705d3ee30ebc0e18115f833a753de78d318`.
3. `s03_stage_status.jsonl` — `libfile_32be10a0d9b08191a22fbdaee0702c29`, v0, 2,474 bytes, SHA-256 `5a4d5b783cdb054fc1bb8eb4ce5ce03955abe969e76a69e1fdcbd1f4370d2ea3`.
4. `s03_hermetic_collection_check.json` — `libfile_fa365b89bc5081919904e1fdbda77d43`, v0, 347 bytes, SHA-256 `e2a531c80b611d48fb3cefbcb8e7dc224a0a352fa675431522588c8ce6eb7635`.
5. `s03_hermetic_junit_check.json` — `libfile_64ac70370d608191ad14acff030cc706`, v0, 213 bytes, SHA-256 `846dedc3a8123ff26bfb3d8d41347b4744b9791b396d706d684cbc65785a2dd5`.
6. `s03_licensed_collection_check.json` — `libfile_aced3166fa988191bbd50bfc18af7068`, v0, 359 bytes, SHA-256 `e4b3769ce590704c353aecee148839d77d0d32e30ff058db5139e504400daff6`.
7. `s03_licensed_junit_check.json` — `libfile_51c1239083448191a546c08ef4ec71d9`, v0, 224 bytes, SHA-256 `a05433a0f1de664158ca67ef78f656763cafa5525a539b80e1f1f1ccab579780`.

The four collection/JUnit files are compact validation records, not raw inventories or JUnit XML. Those raw artifacts are `NOT_DURABLY_RESOLVED / NOT_INCLUDED / NOT_RECONSTRUCTED`; do not substitute historical JUnits or regenerate current results.

List the following as stable supporting pointers in `00_READ_FIRST.md`, not copied bytes, unless QA later requests an identified item:

- heartbeat `libfile_53546766c5408191bfb058bf36c999bc`
- launcher `libfile_d107e91ba40c8191b167844c9f18e52c`, v1
- durability probe `libfile_f3864ecfae1c8191a7a33d975982623a`, v1
- supervisor probe `libfile_1d72471e446881919596e509bca0edce`
- static review `libfile_a1912726f93881919386a20902fea18d`
- allowlist result `libfile_8c9fc247444081919b73b8fae1900b45`
- positive control `libfile_8ff061e826688191b9090ee5a3f74dc3`
- component manifest `libfile_a9917da9c0148191a7e75228a87e0d42`
- placement matrix `libfile_a22543713b34819198ba9b938452738f`
- cache probe `libfile_2fde4bd7991c819183ab6fdf85663ecb`
- harness diff `libfile_174dcd05899c8191937978571ba6bb60`, v1
- placement receipt `libfile_5dcf843cb1f881918aaf2aa5a795723e`
- initial protected gate `libfile_d7717bdf12ec81918e759a35ee1683f1`, v0, 3,573 bytes, SHA-256 `d5d799fde356fabbe4e820a198036eb7d6aa9b6cf3a49bd8503f499e49c2f573`
- post-licensed placement rehash `libfile_82f4667f75688191a90dfd5746507280`, v0, 3,573 bytes, SHA-256 `d5d799fde356fabbe4e820a198036eb7d6aa9b6cf3a49bd8503f499e49c2f573`

Also point to, but do not copy: SEO-01 order `libfile_b0c21e139bc48191a00cac3abf20cc30`, SHA-256 `92a1da1ad9904ee63358c545562aea1cf05b717a8618be25b8f94b06b6fffcb3` (already held by QA); Lease-02 continuation `libfile_32de2d2010a08191b571fd7c570fc823`; custody control `libfile_ee142cefd5188191a3089a901596a920`; accepted Kibot evidence `libfile_397205f46a148191b92100cdf42e5f63`; execution-neutral corporate-action ledger `libfile_21d801cfae948191b83b0e016976d4c6`, version `2`, SHA-256 `fc36574eedb161284fb9be2d857b468df3e09720ca738717b878987d64ff55b9`; prior QA delta `libfile_d316dd90c110819182e72682daad07ff`; and TVCA return `libfile_e0122623fa5881918254917170f60056`.

To close QA's historical Product Owner ratification question without resending old history, also point to `NEXUS_ORIGIN_SUCCESSION_AND_STATE_RECONCILIATION_2026-08-31.md`, `libfile_b9c11ca7773881918daa3319e407aec1`, 15,058 bytes, SHA-256 `5f8fc87d1c11f9daf17e86b2e0e24947c4d7d59c1d9a026ae842ce4a6b09bf80`; summarize that it records the Product Owner's bounded `stage=development` continuation.

The superseded Epoch-05/TVCA-custody continuation `libfile_86f9a750a10c8191b4664460605e7a55` is `SUPERSEDED / NOT_SUPPLIED` because its bytes contain account/browser-specific information excluded from external QA packages. Do not copy, quote, or expose those details. In `00_READ_FIRST.md`, use this sanitized chronology: “The legacy TradingView corporate-action fixture was initially missing, then later recovered exactly and custody-bound. Separately, a subsequent semantic stop found that the complete 1998–2024 corporate-action boundary set lacked an authoritative source; the execution-neutral ledger addressed that distinct metadata-boundary blocker. The present RUN01 failure occurred before ledger parsing.” The ledger remains pointer-only here.

## 6. Absolute exclusions

Do not contain, materialize for packaging, or expose:

- private Kibot gzip or decompressed data;
- any TradingView licensed fixture CSV payload;
- protected-stage, custody, or checkpoint `data/raw` working copies;
- raw or derived OHLCV/market rows;
- historical-final bars, outcomes, events, features, labels, predictions, metrics, plots, or scores;
- credentials, account/session data, browser state, or secrets;
- `.venv`, dependency cache, temporary roots, build/cache/bytecode material;
- mutable Developer workspaces or execution roots;
- invalidated checkpoints; or
- a fabricated sealed return, scientific output, JUnit, inventory, or final-review record.

Do not materialize private payload bytes merely to prove absence. Use the allowlist, durable classifications, recursive archive inventory, and candidate-package scans.

## 7. Manifest and verification contract

1. Verify each imported file against its durable Library identity and every bound size/SHA-256.
2. Recursively inventory all nested archive paths without extracting protected payloads.
3. Reject duplicate or case-colliding ZIP paths, absolute or traversal paths, symlink/special-file members, and encrypted or otherwise uninspectable nested archives. Textual private filenames, `.csv` or `data/raw` strings, sizes, and SHA-256 identities inside source, controls, or metadata are expected references and are not payload leakage. Scan for credentials, account/browser details, prohibited archive members, actual tabular market rows, and any candidate member whose actual bytes/size/hash match a protected payload identity; classify and explain every scan hit.
4. `PACKAGE_CONTENTS.json` must enumerate every final packet member. For imported bytes, record relative path, source Library identity/version, size, SHA-256, classification, and purpose. For generated members, record relative path, classification, purpose, and `origin: GENERATED_FOR_PACKET`. It must not record a hash for itself or for the subsequently generated `MANIFEST_SHA256SUMS.txt`; it may record the finalized `00_READ_FIRST.md` hash. `MANIFEST_SHA256SUMS.txt` remains the hash authority for every final regular member except itself.
5. `MANIFEST_SHA256SUMS.txt` covers every final regular packet member except itself, ordered bytewise by relative UTF-8 path and formatted as `SHA256`, two ASCII spaces, relative path, LF.
6. Declare `manifest_excludes_self: true`. Bind the manifest SHA-256 and outer ZIP size/SHA-256 only in Steward's external return/readback.
7. Independently read back the completed ZIP and repeat integrity, member-count, manifest, source-identity, and exclusion checks.
8. Return the ZIP's Library ID, backing file, version, path, size, SHA-256, manifest SHA-256, and readback result. A separate receipt is unnecessary unless an existing archive rule requires one.

A clean package is only `READY_FOR_INDEPENDENT_QA_TRIAGE`, never `QA_APPROVED`.

## 8. QA and advisory-Developer authority

Outside QA may use its capable Developer as an advisory technical reviewer in a private isolated copy. They may inspect sanitized source/tests/configuration/protocols/controls/manifests/logs, recompute digests, run no-network synthetic or hermetic diagnostics requiring no excluded input, identify root cause, and return an unapplied source/test diff.

They may not modify Nexus Library records, claim a Nexus writer lease, touch licensed inputs, run the official licensed or scientific lane, open historical-final market bytes/outcomes, create or seal official evidence, promote a result, or authorize execution. Any proposed patch has zero authority until Origin independently adopts it.

## 9. Questions for QA

Return one independently reasoned report:

1. Does the exact 630-date file reproduce `423f...f429` under the established canonical serialization?
2. Does `load_frozen_final_identities` produce `ba899...013b2` because it uses a different serializer?
3. Did the synthetic test mask that divergence?
4. Is this localized binding/serialization implementation drift with zero scientific-semantic effect, or an authoritative conflict?
5. Do supplied records show checkpoint corruption, identity-list drift, protected-data leakage, or final-outcome exposure? Use `NOT_ASSESSED / INSUFFICIENT_SCOPE` for anything the sanitized packet cannot establish.
6. What is the smallest exact repair? Prefer the established canonical helper over another duplicate serializer.
7. What exact real-artifact regression is needed? If a test is added/renamed, identify the named-inventory and ordered-digest consequence.
8. Can the diagnosis and repair be established without licensed bytes or final outcomes?
9. Must a repair create a new prospective checkpoint and run every lane afresh under a new segment/run identity?
10. What immutable inputs, competence requirements, and fresh-root boundary should the sole successor Developer receive?
11. `SECONDARY / NONBLOCKING`: reconcile the historical `922/983` parents with current `980/1041` inventories from supplied records, or state exactly what evidence is unavailable. This must not delay the serializer-root-cause disposition.

Preferred return: one concise Markdown main report plus an optional separate unapplied source/test diff, each with exact size and SHA-256. Do not create a giant appendix unless a material finding cannot be evidenced otherwise.

Classify the return as one of:

- `ROOT_CAUSE_CONFIRMED / NARROW_REPAIR_RECOMMENDED`
- `ROOT_CAUSE_REJECTED / ALTERNATE_DIAGNOSIS_PROVIDED`
- `AUTHORITATIVE_CONFLICT / ORIGIN_DECISION_REQUIRED`
- `INSUFFICIENT_SANITIZED_EVIDENCE`

## 10. Steward stop rules

Proceed autonomously through this single packaging operation. Stop only if a required durable identity cannot be resolved; bytes or metadata disagree; sensitivity is ambiguous; a nested archive contains prohibited material; readback fails; or safe packaging would require private raw data or a mutable workspace.

Return the completed packet identity and a concise inclusion/exclusion summary. Do not transmit it outside Nexus, alter scientific status, treat passing lanes as evidence, issue a Developer continuation, or update a role's scientific authority.
