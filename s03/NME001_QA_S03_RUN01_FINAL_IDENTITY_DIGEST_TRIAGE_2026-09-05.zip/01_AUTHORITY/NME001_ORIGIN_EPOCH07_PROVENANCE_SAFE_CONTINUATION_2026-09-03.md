# NME-001 Origin Disposition — Epoch-07 Provenance-Safe Continuation

**Decision date:** 2026-09-03  
**Origin disposition:** `EPOCH06_STOP_ACCEPTED / NOT_RUN / NO_DURABLE_SOURCE_OR_TEST_EVIDENCE / EPHEMERAL_WIP_LOST / NO_NEW_SCIENTIFIC_EXPOSURE / EPOCH07_AUTHORIZED_WITH_ROLLING_RECOVERY_CHECKPOINTS`  
**Existing work order:** `NME-001-SEO-01`  
**New execution identity:** `NME-001-SEO-01-RECOVERY-EPOCH-07`  
**Authority:** Historical final and operational release remain `HOLD`. Formal predictive, trading, alerting, broker, and automated-action authority remain `NONE`.

## Executive decision

The Epoch-06 defined stop is accepted as correct and fail-closed. The shared executor returned `409 environment_offline` while Developer was reconstructing the prospective source/test checkpoint. When access returned, the complete Epoch-06 scratch root was absent and remained absent beyond the controlling 20-minute no-progress threshold. Developer correctly refused to use visible Epoch-04/Epoch-05 roots.

This is an infrastructure and filesystem-continuity failure, not a scientific failure. No durable Epoch-06 source or test evidence exists. No evidentiary test inventory or test lane ran; earlier precollection attempts were diagnostic only. The Kibot payload was not decompressed, no market rows were processed, no scientific output was created, and the historical final remained unopened. The stop receipt itself remains valid process evidence.

Epoch 06 is closed as `NOT_RUN`. A later-reappearing Epoch-06 root, fragment, provisional hash, log, or recollection must be quarantined as unverified diagnostic material and must not become source, checkpoint, manifest, inventory, test evidence, or scientific evidence.

Origin authorizes a clean Epoch-07 continuation inside the existing SEO-01 work order. This changes only execution identity and operational durability. It does not change the scientific question, inputs, source vintage, exclusions, partition, adjustment policy, models, features, labels, metrics, gates, or authority. No new Product Owner approval is required.

## Accepted Epoch-06 stopped state

- Stop receipt: `NME001_SEO01_RECOVERY_EPOCH06_PROVENANCE_STOP_2026-09-03.md`.
- Library ID: `libfile_fb459fb8efa88191a3c313cd8010c440`.
- Version: `0`.
- Size: `2,681` bytes.
- SHA-256: `11a1312847f9e3464d27b1876bf7a501b9f4db39ca53c094277139f1bdc992c7`.
- Classification: `SANITIZED_PROCESS_EVIDENCE / DEFINED_STOP / NOT_RUN / EPOCH06_SCRATCH_PROVENANCE_UNAVAILABLE`.

`FILESYSTEM_PROVENANCE_UNAVAILABLE` applies only to the vanished Epoch-06 scratch continuity. It does not invalidate or imply corruption of the authoritative DWO-05 foundation, registered inputs, licensed fixtures, or corporate-action ledger.

## Controlling authority and inputs

The scientific instructions and frozen input meanings in `NME001_ORIGIN_EPOCH06_CORPORATE_ACTION_SUPPLEMENT_AND_CONTINUATION_2026-09-02.md` remain controlling by reference:

- Library ID: `libfile_c61f0bebac6c8191b1094cea0a7ae861`.
- Version: `0`.
- SHA-256: `b6a135ae30c9bd2cf5acee09bbd2b8dbe3fb8d35f1594af9b936ca7f3f168c1c`.

This Epoch-07 disposition supersedes only its Epoch-06 execution identity and durability procedure.

Reverify all unchanged authoritative inputs before implementation, including:

1. DWO-05 clean foundation — `libfile_e716d00202688191a1ac59c2343e4edf` — SHA-256 `8cb8151a9ef619db96d5f9ed4d8c6ba01f635b309a0224634432b523d952ffbd`.
2. Offline dependency cache — `libfile_7e5b770cc5708191a05b044ebdecf534` — SHA-256 `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`.
3. Accepted private Kibot vintage — `libfile_95d9d67146688191b4613336d950a3e3` — SHA-256 `065b5225fb58ad7ff43e33d9540b3ae452749028cdb9b7054a0cd7ff00e1d8e5`.
4. Post-delivery acceptance evidence — `libfile_397205f46a148191b92100cdf42e5f63` — SHA-256 `2784509e4cf3e0ef13b93c6750f3e0a595a5bf0a36971f0d7c3ded2580685eee`.
5. SEO-01 execution order — `libfile_b0c21e139bc48191a00cac3abf20cc30` — SHA-256 `92a1da1ad9904ee63358c545562aea1cf05b717a8618be25b8f94b06b6fffcb3`.
6. QA delta package — `libfile_d316dd90c110819182e72682daad07ff` — SHA-256 `f168863f2530c2047c5d7cffc99876c86ed13e0296e3173bc5d6385c1efbe5a3`.
7. Untouched TradingView fixture — `libfile_09b7172563fc819196ffcaf1329776f8` — SHA-256 `ee9391284564b85e8875aa95be51eb74898d38455e87e9e5335c07ad79214985`.
8. Split-check TradingView fixture — `libfile_7960fcb71af88191809af6f37cee8bde` — SHA-256 `10231f1451f79a09b8242528d78adf239bf6c55c2ff014735d9754a9f1ad519d`.
9. Corporate-action TradingView fixture — `libfile_6b220bf7f8ac8191a46e380635ffe99d` — SHA-256 `11215bd7ce1fec4d8fb2b92c3437e3085de67a909a41a9324ddf726a1f86a5c8`.
10. Execution-neutral corporate-action ledger — `libfile_21d801cfae948191b83b0e016976d4c6`, version `2` — SHA-256 `fc36574eedb161284fb9be2d857b468df3e09720ca738717b878987d64ff55b9`.

The historical 1,461-test expectation remains non-controlling. Accepted parent references remain 922 hermetic and 983 licensed-inclusive cases; Epoch-07 inventories must be frozen prospectively from the exact final checkpoint.

## Clean Epoch-07 start

1. Create a new isolated Epoch-07 segment from the exact DWO-05 foundation and controlling inputs. Initial segment identity is `EPOCH07-S01`.
2. Do not copy or resume any Epoch-04, Epoch-05, or Epoch-06 source tree, scratch root, provisional manifest, test output, or evidence.
3. Before material editing, verify every controlling input and preserve a bootstrap record binding the segment/executor identity, DWO-05 source identity, input-resolution matrix, environment identity, and explicit `NO_KIBOT_ACCESS / NO_MARKET_ROWS / NO_TEST_EXECUTION / FINAL_CLOSED` state.
4. Establish one stable replace-in-place archive named `NME001_SEO01_RECOVERY_EPOCH07_ROLLING_SOURCE_WIP.zip`.
5. Independently rematerialize and rehash the bootstrap archive before continuing.

## Rolling recovery checkpoint contract

Replace the same rolling WIP archive after each coherent implementation unit or no later than ten minutes after changed work begins, whichever occurs first. Do not begin an uninterrupted edit expected to exceed that cadence without first preserving the current state. If an operation unexpectedly exceeds the cadence, checkpoint immediately when control returns.

Every version must contain only:

- the complete current source and tests;
- unified diff from exact DWO-05;
- file manifest and SHA-256 list;
- exact controlling-input bindings and executor-segment identity;
- completed and pending implementation items;
- scope reconciliation against the frozen order;
- the prior verified rolling-version identity and SHA-256, when one exists; and
- explicit classification `RECOVERY_ONLY / ENGINEERING_WIP / NOT_A_PROSPECTIVE_CHECKPOINT / NOT_TEST_EVIDENCE / NOT_SCIENTIFIC_EVIDENCE`.

Exclude licensed fixture bytes, Kibot bytes, market rows, credentials, dependency caches, virtual environments, build caches, JUnits, scientific outputs, and prior-epoch evidence. After each replacement, independently rematerialize and rehash the exact Library version. Update Developer role memory with the stable file ID, version, hash, completed state, and next action before relying on it as recoverable work.

Rolling WIP versions are recovery sources only. They do not satisfy the final prospective checkpoint and authorize no Kibot decompression, market-row processing, evidentiary inventory, full test lane, scientific lane, or final access.

## Autonomous executor recovery

If an executor or scratch root disappears before the final prospective checkpoint:

1. Stop the affected segment.
2. Start the next numbered segment, such as `EPOCH07-S02`.
3. Reverify the controlling identities and rematerialize only the latest independently verified Epoch-07 rolling WIP version.
4. Record the new environment identity and continue within Epoch 07 without another Origin or Product Owner approval.
5. If no verified rolling WIP exists, restart cleanly from DWO-05 within Epoch 07.

Never use merely visible rematerialized scratch state. Return to Origin only if the durable WIP cannot be verified, a controlling identity differs, licensed/final exposure may have occurred, or a scientific/semantic decision is required.

If interruption occurs after the final prospective checkpoint, rematerialize that exact checkpoint into a new segment and restart every affected test or scientific lane from zero. Never combine partial outputs across executor segments. Give every run attempt a unique identity and return evidence from one clean attempt only.

## Final prospective checkpoint and execution gate

Complete every Epoch-06 implementation obligation under the unchanged scientific instructions. Then create the separately frozen, immutable prospective Epoch-07 source/test checkpoint containing the complete source, DWO-05 diff, manifest, SHA-256 list, scope reconciliation, environment identity, and exact ordered hermetic/licensed inventories and digests.

Independently read back and verify that checkpoint. Only that checkpoint—not a rolling WIP version—may open the Kibot decompression, development-row processing, full-test, and scientific-development gates already authorized by SEO-01.

All post-gate JUnits, logs, ledgers, scientific outputs, manifests, receipts, and packages must originate from one clean Epoch-07 run attempt. Apply the unchanged leakage, custody, exclusion/no-reachback, final-guard, packaging, and authority controls.

## Stop conditions

Stop and return to Origin if:

- any controlling identity or hash differs;
- no verified DWO-05 or Epoch-07 recovery source is available;
- source/test provenance becomes ambiguous;
- the corporate-action ledger cannot be integrated without changing frozen semantics;
- a new source, fixture, mapping, split, listing, adjustment, or exclusion ambiguity appears;
- licensed bytes escape their approved custody boundary;
- any historical-final row, label, outcome, metric, or scientific product is accessed or created;
- partial outputs would need to be combined across segments; or
- the controlling no-progress rule is reached without a durably verified recovery checkpoint.

Routine implementation, testing, packaging, checkpointing, executor-segment recovery, and reproducibility repair inside these boundaries require no further approval.

## Final disposition

`EPOCH06_ACCEPTED_DEFINED_STOP / EPOCH06_NOT_RUN / EPOCH07_AUTHORIZED_UNDER_EXISTING_SEO01 / ROLLING_RECOVERY_CHECKPOINTS_REQUIRED / AUTONOMOUS_SEGMENT_RECOVERY_AUTHORIZED / HISTORICAL_FINAL_HOLD / ALL_ACTION_AUTHORITY_NONE`
