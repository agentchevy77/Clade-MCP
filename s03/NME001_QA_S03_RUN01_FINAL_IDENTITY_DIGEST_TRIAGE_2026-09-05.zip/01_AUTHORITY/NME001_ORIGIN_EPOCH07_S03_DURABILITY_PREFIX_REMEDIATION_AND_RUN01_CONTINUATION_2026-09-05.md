# Project Nexus — EPOCH07-S03 Durability-Prefix Remediation and RUN01 Continuation

**Identity:** `NME001-ORIGIN-EPOCH07-S03-DURABILITY-PREFIX-REMEDIATION-AND-RUN01-CONTINUATION-01`  
**Issued:** `2026-09-05T19:06:24Z`  
**Disposition:** `LEASE02_STATIC_REVIEW_STOP_ACCEPTED / RUN01_NOT_STARTED / LEASE02_CLOSED / LEASE03_AUTHORIZED_FOR_ONE_DURABILITY_PREFIX_RESTORATION_AND_THE_SAME_RUN01`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`  
**Product Owner approval:** `NOT_REQUIRED / BOUNDED_EXTERNAL_HARNESS_REPRODUCIBILITY_REPAIR`

## 1. Accept the exact defined stop

Accept these records exactly:

1. `NME001_EPOCH07_S03_RUN01_LEASE02_STATIC_REVIEW_DEFINED_STOP_2026-09-05.json`
   - Library: `libfile_b39dadc690e881918fa51aefaf16d266`
   - backing file: `file_0000000082fc81f5bd3d525607a2c213`
   - version: `0`
   - size: `4,017` bytes
   - SHA-256: `ec4b917a627d10778811e1e1d4e131b9c5b64ebb8691f5c560a76eea616f4578`
   - fresh Library readback: `PASS`

2. `NME001_EPOCH07_S03_RUN01_LEASE02_STATIC_REVIEW.json`
   - Library: `libfile_9a96a305668c8191a8f4b032ae1c7e9e`
   - backing file: `file_0000000084d481f5aa474994b5bf5578`
   - version: `0`
   - size: `1,960` bytes
   - SHA-256: `5d6f07672386d912e935a30fd754a91bb5a992a29324589b2c7c2055bd600d0b`
   - fresh Library readback: `PASS`

Classify the stop:

`PRELAUNCH_STATIC_REVIEW_FAILED / RUN01_NOT_STARTED / CHECKER_NOT_INVOKED / SUPERVISOR_NOT_LAUNCHED / NO_PROTECTED_ACCESS / NO_EVIDENCE`.

The required nonauthor reviewer correctly rejected the lease-02 candidate before either permitted checker invocation. The candidate durability probe stripped `uv-cache/` from cache-manifest member paths without first proving that each path carried that prefix. The authoritative RUN04 template performs that validation. Omitting it weakened a fail-closed cache-custody control outside the authorized change categories.

The review passed the other inspected categories only as diagnostic findings. It did not approve the candidate, open RUN01, or create evidence. Both checker invocation counts are zero; launch count is zero. No supervisor, sequence, `uv sync`, project import, test, licensed lane, scientific lane, protected-input action, Kibot decompression, market-row access, historical-final access, checkpoint change, or sealed return occurred.

Permanently close `NME001-E07-S03-WRITER-LEASE-02` at this stop. Do not remediate, invoke, execute, resume, promote, or use its candidate, harness, root, cache realization, probes, receipts, diff, review subfindings, or other mutable bytes as evidence.

## 2. Continuation identities

Remain in the existing execution, segment, and run:

- execution: `NME-001-SEO-01-RECOVERY-EPOCH-07`;
- segment: `EPOCH07-S03`;
- run: `NME001-SEO01-EPOCH07-S03-RUN01`;
- successor lease: `NME001-E07-S03-WRITER-LEASE-03 / PRELAUNCH-DURABILITY-PROBE-UV-CACHE-PREFIX-RESTORATION-AND-SAME-RUN01-ONLY / NO-SOURCE-CONFIGURATION-TEST-LOCKFILE-CHECKPOINT-INVENTORY-DEPENDENCY-OR-SCIENTIFIC-SEMANTIC-CHANGE`.

RUN01 retains its identity because it has never launched and no attempt was consumed. This control expressly supersedes only the prior prohibition on creating lease 03 after a lease-02 mismatch. It does not create S03 RUN02, Epoch 08, or a retry loop.

The same oriented Developer may claim lease 03 only after:

1. exact readback of this control, the two accepted stop/review records, and the governing controls below;
2. confirmation that lease 02 is stopped and no S03 supervisor, sequence, checker, test, or unknown writer remains active; and
3. confirmation that the designated fresh lease-03 parent is absent.

Use the fresh parent:

`/workspace/scratch/8ee21c4e3e47/EPOCH07-S03-LEASE03-EXECUTOR-01`

It was observed absent when this control was issued. If it is no longer absent before claim, choose one different absent absolute lease-03 parent, bind it explicitly, and stop if ownership is ambiguous.

## 3. Unchanged durable authorities

- Lease-02 predecessor continuation: Library `libfile_32de2d2010a08191b571fd7c570fc823`, version `0`, 12,822 bytes, SHA-256 `348e1d25acc66ec898ba255e8c5623a650c1c7fbbe54a8d7968f878681c08b81`.
- Parent S03 control: Library `libfile_8a0d418fea648191bd9a3ef93154f1a2`, version `0`, 17,343 bytes, SHA-256 `17efb16a19fa403aca9e98388129a7bfab976a39861df0300e4222fb25a047ea`.
- Sole checkpoint: Library `libfile_04f5f1bfe55881919e025e0214c2f06d`, version `3`, 3,966,322 bytes, SHA-256 `c046792f90ab2362993bf556e3a8abc855524af2b88d41823d6c4986c6f22894`; manifest SHA-256 `5a4e3f4d10943918b4525cd0b21fcf514aebb93c6caeff6fb68d072faf9febbf`; source-tree SHA-256 `8f53575bb5101096be63809cd9096217f0092c59a9c85ba3ba60208b781cab78`; members `169/169`.
- Frozen inventories: hermetic `980` / ordered SHA-256 `8c9d737fd99d5212891681c2feaad2bdf083d5ef1f3f4bea691ea9166cc67d24`; licensed-inclusive `1,041` / ordered SHA-256 `d6adcdfcd813548e0f11106b6a3c3618218e5cd976992f7b35a8072f049751d3`.
- Sanitized RUN04 harness template: Library `libfile_d5a25ad0a2708191bfbe0bf9ce59896d`, version `0`, 32,874 bytes, SHA-256 `4b30262da949f2ace2f7bb8d54d0ec1f1f86efbb5f7e719f023a2c7a55bf906d`.
- Public offline cache package: Library `libfile_7e5b770cc5708191a05b044ebdecf534`, 148,782,742 bytes, SHA-256 `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`.
- Scientific control projection: Library `libfile_96adab97fea88191a3218df17cc83033`, SHA-256 `2d42306ab9a37d225fe6354345bbd6826d69d5bc8da1d47025ef0803f7f3b03b`.
- Custody/placement control: Library `libfile_ee142cefd5188191a3089a901596a920`, SHA-256 `23919845225e38f0ce660f65563abfa9c95a1b44a9ef381d4b96115afca3f88f`.

All unchanged requirements of the two predecessor S03 controls remain incorporated. This control changes only the stopped lease identity, fresh roots/records/hashes, and the exact restoration below.

No checkpoint version 4, rolling source WIP, source/configuration/test/lockfile/inventory/dependency/scientific change, new data, new checkpoint/source/scientific-design review, or expanded panel is authorized. The sole prelaunch review is the single fresh nonauthor static external-harness review in Section 5; the inherited single final-return review remains unchanged.

## 4. Exact authorized restoration

The authoritative RUN04 template durability probe is 16,305 bytes with SHA-256 `03eded0514bca9d19ae5b922a426e9fb1b772db0a9e31ad3d6aea4008d9ebe50`. The stopped lease-02 durability candidate is 18,902 bytes with SHA-256 `31ec53b09b2a44b305108e186894de4816c35029137e4222ddee484f01b9b7e6`.

Do not patch or copy the stopped candidate. Reconstruct the complete lease-03 harness from the exact sanitized RUN04 template and governing S03 controls in the fresh lease-03 root.

Within the fresh `s03_durability_probe.py`, retain the authoritative RUN04 template block exactly:

```python
    expected_files = {}
    for item in payload_manifest["members"]:
        path = item["path"]
        if not path.startswith("uv-cache/"):
            raise RuntimeError("cache payload path lacks uv-cache prefix")
        expected_files[path.removeprefix("uv-cache/")] = item
```

This is an exact template-byte/logic requirement, not authorization for an equivalent rewrite. Do not rename `payload_manifest`, use a comprehension, reword the failure, narrow its coverage, turn failure into warning, add a silent fallback, or substitute another implementation.

Retain the previously authorized checker self-scan correction exactly:

```python
if ("SOURCE_DATE_EPOCH" + "=0") in "\n".join(...):
```

At runtime it must still search for the exact contiguous forbidden token across every top-level harness file, including itself.

Apart from the inherited S03 bindings, mechanical lease-03/root/path/record/hash substitutions, the retained self-scan correction, and the restored durability-prefix guard, no executable or semantic difference is authorized.

## 5. Fresh lease-03 reconstruction and review

Treat all lease-02 mutable material as `DIAGNOSTIC_ONLY / NON_EVIDENTIARY`. The immutable checkpoint, cache package, template, and controls remain authorities, but freshly materialize/realize and verify them under lease 03. Do not reuse the lease-02 extracted checkpoint, realized cache, receipts, probes, diff, manifest, review, or harness.

Construct fresh lease-03 preflight, harness, runtime, observability, and output paths. Protected staging, custody, checkpoint `data/raw`, readiness bytes, and `.venv` remain absent until their inherited gates.

Create, preserve, and freshly read back one lease-03 two-generation non-project environment probe under the exact final normalized environment. Both generations must observe global `SOURCE_DATE_EPOCH` absent, the exact lease-03 `XDG_CACHE_HOME`, and uv cache resolution to its `uv` child. Bind its exact identity into the lease-03 component/launcher chain. No lease-02 probe or receipt may be reused or allowed to vote.

Before either checker invocation:

1. preserve a fresh exact component manifest and template-to-lease03 unified diff;
2. obtain one fresh nonauthor static review of the complete exact lease-03 bytes;
3. require the reviewer to regenerate the authoritative diff and verify every component identity, every changed hunk, the prefix guard before removal, the exact split-token self-scan correction, unchanged full-harness scan, unchanged custody/lane/scientific controls, and zero project-tree changes; and
4. stop if any additional defect or unauthorized difference exists. Prior lease-02 PASS subfindings do not transfer automatically.

The checker must continue excluding only itself from its embedded fixed-target hashes. Bind the final checker hash externally in the component manifest and verify it through the authoritative result's `logic_sha256` and checker entry in `s03_harness_hashes`. Update the durability-probe fixed-target hash to the exact final lease-03 bytes. Do not create a circular self-hash.

## 6. Checker and RUN01 sequence

Only after the fresh static review passes may lease 03 perform exactly:

1. one disposable positive-control checker invocation with `python -B`, a byte-identical copy of the reviewed harness, the exact reviewed template and planned matrix without path rewriting, one top-level dummy containing the contiguous forbidden token, exact exit `1` with `erroneous global SOURCE_DATE_EPOCH assignment remains`, a sanitized receipt only, and complete residue disposal; then
2. one authoritative checker invocation with `python -B` against the exact reviewed harness, requiring exact exit `0`, `PASS`, and fresh readback/hash binding of all outputs.

The unused lease-02 checker allowance does not transfer. Lease 03 receives its own exact two-invocation allowance. No third lease-03 checker invocation is authorized.

If the static review, positive control, or authoritative checker fails, preserve one defined stop and return to Origin. Do not create lease 04 or S03 RUN02.

If all prelaunch gates pass, create and exactly read back the fresh launcher and durability records, then continue the same `NME001-SEO01-EPOCH07-S03-RUN01` once through the unchanged sequence:

1. normalized environment with global `SOURCE_DATE_EPOCH` absent;
2. unchanged offline `uv sync`;
3. exact `980` hermetic collection and execution;
4. protected placement only after the complete hermetic pass;
5. exact `1,041` licensed-inclusive collection and execution;
6. restoration and exact nine-placement rehash;
7. unchanged scientific-development lane;
8. sealed return, licensed-byte leakage scan, durable observability, and required single final review.

All returned evidence must originate only from this fresh lease-03 execution chain.

## 7. Memory, stop, and authority boundaries

After claiming lease 03, update `NEXUS_DEVELOPER_ROLE_MEMORY.md` in place. At its next material update, compress retired lease-01/02 history into stable pointers and return the file to the memory-system size target without losing the current lease/run, blocker/exposure, next action, or authority state. Do not copy volatile details into the Compass or other role memories.

Stop and preserve if any durable identity differs, the fresh root cannot be established, the exact restoration cannot be isolated, Developer continuity becomes ambiguous, any unauthorized change appears, protected access occurs early, historical-final bytes open, or observability is lost under the inherited threshold.

Historical final remains unopened and `HOLD`. Operational release remains `HOLD`. Development evidence authority remains `NONE` until a complete clean RUN01 return and required review pass. Formal predictive, trading, broker, alerting, and automated-action authority remain `NONE`.

Proceed autonomously after exact control readback and lease claim. Return only at a defined stop or with the complete sealed and reviewed RUN01 return. No intermediate Product Owner approval is required.
