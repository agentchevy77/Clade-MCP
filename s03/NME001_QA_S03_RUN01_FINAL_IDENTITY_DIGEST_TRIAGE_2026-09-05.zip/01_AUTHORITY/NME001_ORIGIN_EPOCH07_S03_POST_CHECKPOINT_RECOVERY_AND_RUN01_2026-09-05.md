# Project Nexus — EPOCH07-S03 Post-Checkpoint Recovery and RUN01

**Identity:** `NME001-ORIGIN-EPOCH07-S03-POST-CHECKPOINT-RECOVERY-AND-RUN01-01`  
**Issued:** `2026-09-05T16:46:48Z`  
**Disposition:** `S02_SEGMENT_CONTINUITY_STOP_ACCEPTED / S02_LEASE06_NOT_CLAIMED / S02_RUN05_NOT_STARTED / S02_CLOSED / S03_AUTHORIZED_FROM_EXACT_CHECKPOINT_V3 / S03_RUN01_RESERVED`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`  
**Authority basis:** Epoch-07 post-checkpoint executor recovery and the Product Owner's standing bounded Nexus autonomy; no new Product Owner approval is required.

## 1. Accept the segment-continuity stop

Accept the Developer's relayed status exactly:

`STATUS: SEGMENT_CONTINUITY_STOP`  
`CONTROL: READ / VERSION_0`  
`S02_CONTINUITY: FAILED`  
`MISSING: RUN04_CHECKPOINT_ROOT / RUNTIME_ROOT / CONTROL_ROOT / CACHE_ROOT / STOP_RECORD`  
`WRITER_LEASE_06: NOT_CLAIMED`  
`RUN05: NOT_STARTED / NO_ROOTS_CREATED`  
`ACTION: SEGMENT-CORRECT_ORIGIN_IDENTITIES_REQUIRED`

Independent read-only inspection also found the named S02 RUN04 checkpoint, runtime, cache, and protected-staging paths absent. This is the exact post-final-checkpoint executor-loss branch defined by `NME001_ORIGIN_EPOCH07_PROVENANCE_SAFE_CONTINUATION_2026-09-03.md`, Library `libfile_b5fb67f073dc8191b6a294097fc3e0c4`, 10,607 bytes, SHA-256 `ae268b60d68dde4c751fe2728eec3fb9e9ea9b0c12ec8141897ad08b0e8d302c`: rematerialize the exact checkpoint into the next segment and restart the affected run from zero.

The missing `STOP_RECORD` is a missing local S02 copy, not loss of durable provenance. The exact RUN04 stop remains available as `NME001_EPOCH07_S02_RUN04_UV_SYNC_DEFINED_STOP_2026-09-05.json`, Library `libfile_bb092990dca081919857dbd284540926`, version `0`, 5,300 bytes, SHA-256 `df21d07a926018d234e262db9506d41c46edf64068ff86c0a04a3ab6e600443c`; fresh Library content read succeeded.

S02 quiescence does not rest on missing directories alone. The durable RUN04 stop records one child, terminal exit code `1`, execution ceased, no retry, and no downstream launch; lease 05 closed there. The Developer now attests that conditional lease 06 was never claimed and RUN05 created no root or child. Origin therefore withdraws and classifies S02 lease 06 as `CONDITIONAL_GRANT_NEVER_EFFECTIVE / RETIRED_UNCLAIMED`, and classifies S02 RUN05 as `RESERVATION_RETIRED / NOT_STARTED / NOT_AN_EXECUTION_ATTEMPT / NOT_EVIDENCE`. No unknown S02 execution remains authorized.

Do not later claim, launch, resume, or relabel either S02 identity. Close S02 without reconstructing its vanished runtime. Any delayed or reappearing S02 root, output, heartbeat, or process claim is quarantined as untrusted diagnostic material and cannot revive lease 06, RUN05, or evidentiary authority.

## 2. Segment-correct identities

Remain within the existing `NME-001-SEO-01-RECOVERY-EPOCH-07`. Do not create Epoch 08.

- Successor segment: `EPOCH07-S03`.
- Run identity: `NME001-SEO01-EPOCH07-S03-RUN01`.
- Writer lease: `NME001-E07-S03-WRITER-LEASE-01 / SEGMENT-BOOTSTRAP-HARNESS-AND-SINGLE-RUN-ONLY / POST-CHECKPOINT-SEGMENT-RECOVERY-AND-SINGLE-ENVIRONMENT-SANITIZATION-BOUND / NO-SOURCE-CONFIGURATION-TEST-LOCKFILE-CHECKPOINT-INVENTORY-DEPENDENCY-OR-SCIENTIFIC-SEMANTIC-CHANGE`.
- The same oriented Developer may claim this lease after exact readback of this control and confirmation that no other writer or unknown run remains active. No Developer-created S03 execution artifact, root, or write may precede the claim; this Origin control is the authority being read, not Developer execution output. The lease stays `BOOTSTRAP_ONLY / EXECUTION_GATES_CLOSED` until Section 4 passes.
- No S03 RUN02 authority or retry loop is granted.

Run ordinals are segment-local for this recovery: S03 RUN01 is the first and only reserved S03 attempt. It does not relabel, continue, or revive retired S02 RUN05.

The sole execution source remains prospective checkpoint `NME001_SEO01_RECOVERY_EPOCH07_S02_PROSPECTIVE_SOURCE_CHECKPOINT.zip`, Library `libfile_04f5f1bfe55881919e025e0214c2f06d`, version `3`, 3,966,322 bytes, SHA-256 `c046792f90ab2362993bf556e3a8abc855524af2b88d41823d6c4986c6f22894`; manifest SHA-256 `5a4e3f4d10943918b4525cd0b21fcf514aebb93c6caeff6fb68d072faf9febbf`; source-tree SHA-256 `8f53575bb5101096be63809cd9096217f0092c59a9c85ba3ba60208b781cab78`; exact members `169/169`.

The `S02` text in that immutable checkpoint's filename and internal provenance remains historical identity. Do not rename, edit, relabel, or refreeze it. This Origin record externally binds those exact bytes as the S03 execution source. Checkpoint version 4 and another checkpoint review are neither required nor authorized.

Frozen inventories remain:

- hermetic: `980`, ordered SHA-256 `8c9d737fd99d5212891681c2feaad2bdf083d5ef1f3f4bea691ea9166cc67d24`;
- licensed-inclusive: `1,041`, ordered SHA-256 `d6adcdfcd813548e0f11106b6a3c3618218e5cd976992f7b35a8072f049751d3`.

No S03 rolling source WIP or new source checkpoint is needed or authorized because the final prospective checkpoint already exists and source changes are prohibited.

## 3. Incorporated controls and exact substitutions

The technical correction and complete run contract in `NME001_ORIGIN_EPOCH07_S02_RUN05_SOURCE_DATE_EPOCH_CONTINUATION_2026-09-05.md`, Library `libfile_290a7a190ff881919fe2e8c466fdbba0`, version `0`, 13,975 bytes, SHA-256 `d6a37cbe3f62b2435d025bb3678ac0aa319e10d751e3dcd9ee4ed4d3cb0a363e`, remain controlling by reference except for their expressly conditional S02/RUN05/lease-06/root/readiness identities. This record replaces only those identities with S03/RUN01/lease-01 and fresh S03 roots.

Only the applicable post-checkpoint execution, test/scientific, custody, safety, stop, completion, and authority controls of `NME001_ORIGIN_EPOCH07_S02_MINIMAL_RECOVERY_AND_EXECUTION_ORDER_2026-09-04.md`, Library `libfile_94c3ca00fb5c8191a04c11a63b81ff1a`, SHA-256 `580c361023616cab2ca384c72ec7ed49aa622c0649df18b6a7bf7fa65e8f133d`, remain inherited. Its pre-checkpoint DWO-05 reconstruction, rolling-WIP, feedback, checkpoint-freeze/review, and S02 identity/lease/run steps do not apply in S03 and are superseded by this exact-checkpoint post-recovery branch. The scientific control projection remains unchanged: `NME001_ORIGIN_EPOCH07_S02_V4_CONTROL_PROJECTION_AND_CONFORMANCE_REMEDIATION_2026-09-04.json`, Library `libfile_96adab97fea88191a3218df17cc83033`, SHA-256 `2d42306ab9a37d225fe6354345bbd6826d69d5bc8da1d47025ef0803f7f3b03b`. Neither record authorizes rewriting its historical S02 text.

The RUN04 custody-placement, protected-input, restoration, lane-order, leakage, observability, and stop controls incorporated by the RUN05 continuation remain unchanged. The exact six protected inputs and three working-fixture placements remain those in `NME001_ORIGIN_EPOCH07_S02_RUN04_CUSTODY_PLACEMENT_CONTINUATION_2026-09-05.md`, Library `libfile_ee142cefd5188191a3089a901596a920`, version `0`, SHA-256 `23919845225e38f0ce660f65563abfa9c95a1b44a9ef381d4b96115afca3f88f`.

The controlling public offline cache remains `NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64.zip`, Library `libfile_7e5b770cc5708191a05b044ebdecf534`, 148,782,742 bytes, SHA-256 `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`; payload-manifest SHA-256 `f153c44e1d1f07685c1855026c54b764f19c6d1ec008f65e66af03abf55e0def`; package-member-manifest SHA-256 `4fb00aa2d367d8ff4ef18658ef794e85831468bead201e0fe0b44de0a994fa68`.

The sanitized RUN04 external harness is preserved as `NME001_EPOCH07_S02_RUN04_EXTERNAL_HARNESS_DIAGNOSTIC_SNAPSHOT.zip`, Library `libfile_d5a25ad0a2708191bfbe0bf9ce59896d`, version `0`, 32,874 bytes, SHA-256 `4b30262da949f2ace2f7bb8d54d0ec1f1f86efbb5f7e719f023a2c7a55bf906d`. It is the sole harness reconstruction template, contains no protected payload bytes, and must never be executed directly or treated as evidence.

The S03 readiness-gate object is compact UTF-8 JSON followed by one LF:

`{"run_identity":"NME001-SEO01-EPOCH07-S03-RUN01","status":"AUTHORIZED_INPUTS_MATERIALIZED_AND_HASHED"}`

It is exactly `103` bytes with SHA-256 `4459f33ee47986c893ae6a398a1f507494172759d24741f3aed26053b7b68868`. Bind this exact S03 identity in the placement controller, protected-input gate, sequence, launcher, and durability probe. Every S02 readiness object/hash is history and must not be expected or emitted by S03.

This is the segment-correct continuation required by the S02 control. It does not authorize S02 RUN06 or any other S02 execution; it replaces only the failed same-segment condition and the S02 root, RUN05, lease-06, and readiness identities with the exact S03 identities above. It grants no broader change.

## 4. Clean S03 bootstrap

After claiming the S03 lease in `BOOTSTRAP_ONLY` state, and before importing/testing project code:

Choose one new absent absolute parent `B` and bind this S03 root map:

| Symbol | Required role |
| --- | --- |
| `Q = B/EPOCH07-S03-RUN01` | Fresh checkpoint materialization root |
| `R = B/s03_run01_runtime` | Fresh runtime root |
| `P = B/s03_run01_cache/xdg-cache-home` | Fresh XDG cache parent; uv resolves to `P/uv` |
| `T = B/s03_run01_control` | Fresh `CONTROL_ROOT`: external harness, outer launcher, and preflight files |
| `L = R/observability` | Fresh logs, heartbeat, status, launcher, and probes |
| `O = R/output` | Fresh run outputs and sealed-return staging |
| `S = B/s03_run01_protected_stage` | Protected transfer staging; absent until post-hermetic gate |
| `C = R/custody` | Six-input custody; absent until post-hermetic gate |

`B` must be disjoint from every known S01/S02 path. `Q/data/raw`, `S`, `C`, and the readiness marker must remain absent until the post-hermetic placement stage. A terminal stop record or complete-return control record is written under `L` and then preserved durably; sealed return staging remains under `O`. Record the resolved absolute map in the single S03 launcher record and durability probe.

1. At the external orchestration boundary, construct the normalized S03 environment with global `SOURCE_DATE_EPOCH` absent before invoking any S03 shell, cache bootstrap, supervisor, build, test, or project subprocess. Preserve the environment-selection/removal contract without dumping unrelated values or secrets.
2. Create only the pre-hermetic roots authorized by the map. Record the new executor, filesystem, runtime, Python, uv, platform, and absolute-root identities.
3. Re-resolve and verify this Origin control and every durable Library artifact named in Sections 1–3.
4. Freshly materialize checkpoint v3 into an absent S03 checkpoint root. Verify its outer identity, manifest, all `169/169` members, source-tree identity, and both ordered inventories/digests.
5. Verify the public cache package and freshly realize it once into a new S03-specific `XDG_CACHE_HOME=P`; require `uv cache dir` to resolve exactly to `P/uv`. Create one sanitized S03 cache-realization receipt, freshly read it back, and bind its exact size/SHA-256 in the launcher record and durability probe. Do not reuse any S02 realized cache or receipt.
6. Carry the sanitized declarations `NO_S02_RUNTIME_REUSED / NO_PROJECT_IMPORT / NO_TEST_EXECUTION / NO_PROTECTED_INPUT_MATERIALIZATION / NO_ACCEPTANCE_OPEN / NO_KIBOT_DECOMPRESSION / NO_MARKET_ROWS / HISTORICAL_FINAL_CLOSED`, plus the exact checkpoint, controls, cache, environment, and segment identities, into the single S03 launcher record and durability probe required by Section 5. Do not create a separate bootstrap-receipt artifact.
7. Update the Developer-owned role memory in place to point to S03, this control, checkpoint v3, and the next bounded action. Do not copy volatile details into other role memories.
8. Only after these checks pass may the existing S03 lease transition to `HARNESS_BUILD_ALLOWED / RUN_GATE_CLOSED` and permit Section 5 work.

If any durable identity differs or the exact checkpoint cannot be rematerialized, stop. Do not fall back to rolling WIP, DWO-05 reconstruction, S02 remnants, or a new checkpoint: the post-checkpoint recovery rule requires the exact final checkpoint.

## 5. S03-bound external harness

Build fresh external S03 harness files outside the checkpoint from the exact sanitized RUN04 template. The only allowed differences are:

- mechanical active external-harness segment, run, lease, root, schema, filename, log, and output fields replaced with S03/RUN01 equivalents; checkpoint identity/filename, internal member paths, source-module/path names such as `s02_execution.py`, historical S02 provenance and control citations, hashes, and contents are excluded from substitution;
- lease 05 replaced with S03 lease 01;
- the exact S03 readiness object/hash above;
- construction of the effective normalized global environment with `SOURCE_DATE_EPOCH` absent before the first S03 shell, cache bootstrap, supervisor, build, test, or project subprocess starts, plus its prelaunch and actual pre-`uv sync` absence checks; an ambient parent value is permissible only if the external pre-process sanitizer removes it first;
- one fresh standalone S03 outer-launcher/sanitizer artifact binding the exact supervisor argv and environment-selection/removal contract; and
- hashes and receipts necessarily identifying those fresh external bytes and paths.

The frozen distribution subprocesses may retain their checkpoint-controlled scoped `SOURCE_DATE_EPOCH=315532800`; do not set any global replacement value.

Before launch, preserve and freshly read back the exact template-to-S03 unified diff, a deterministic allowlist result, every S03 harness-component hash, the exact outer-launcher/sanitizer hash, the fresh S03 cache-realization receipt, the prelaunch non-project two-generation probe under the exact final normalized environment, the S03 launcher record, and a fresh S03 durability probe. Both probe generations must observe global `SOURCE_DATE_EPOCH` absent and the exact `XDG_CACHE_HOME`/resolved uv-cache binding. The launcher binds the required `SOURCE_DATE_EPOCH: ABSENT` contract; the actual sequence stage status and terminal record bind the runtime assertion result.

The S03 launcher record and durability probe are the single records for both bootstrap and launch readiness; they must include the Section 4 root map and sanitized bootstrap declarations. Only after their exact readback may the lease transition to `RUN_LAUNCH_READY` and permit Section 6.

This is a mechanical external-harness conformance check, not a checkpoint/source review or new panel.

## 6. S03 RUN01 from-zero sequence

1. Launch S03 RUN01 exactly once from the verified bootstrap and fresh mutable roots.
2. In the actual sequence process, assert global `SOURCE_DATE_EPOCH` absent and run unchanged `uv sync --locked --extra dev --offline`.
3. Collect and execute the complete exact `980`-case hermetic lane; require the frozen ordered digest and `980` passed, `0` failed, `0` errors, `0` skipped.
4. Only after the complete hermetic pass, create fresh protected-staging/custody paths and the three checkpoint `data/raw` working copies under the unchanged six-custody-plus-three-placement contract; verify the exact S03 readiness gate.
5. Only after placement passes, collect and execute the complete exact `1,041` licensed-inclusive lane; require the frozen ordered digest and zero failures, errors, or skips.
6. Only after the licensed lane passes, complete the unchanged post-licensed `data/raw` restoration and exact nine-placement rehash; require both to pass.
7. Only after both engineering lanes and restoration/rehash pass, run the unchanged scientific-development lane.
8. Complete the original sealed return, licensed-byte leakage scan, durable logs/heartbeat/evidence sequence, and required single final-return review.

No S01/S02 test result, `.venv`, cache, temporary build, protected staging, output, log, JUnit, probe, readiness marker, or scientific artifact may enter or vote in S03. Control records and the sanitized harness snapshot are non-evidentiary authorities/templates only. All returned evidence must originate from the single clean S03 RUN01 attempt.

## 7. Stop and authority boundaries

Stop and preserve immediately if any checkpoint, control, cache, platform, harness allowlist, source, inventory, input, placement, restoration, lane, leakage, observability, or review control differs or fails; if an ambient parent `SOURCE_DATE_EPOCH` is not removed before the first S03 subprocess or if the key is present in the environment delivered to either probe generation, the supervisor, or the actual sequence immediately before `uv sync`; if protected access occurs before its gate; if any S02 mutable residue would be required; if historical-final bytes are accessed; or if completion requires a source/configuration/test/lockfile/checkpoint/dependency/scientific change or S03 RUN02.

Historical final remains unopened and `HOLD`. Operational release remains `HOLD`. Formal predictive, trading, broker, alerting, and automated-action authority remain `NONE`. Development evidence authority remains `NONE` unless and until the complete S03 RUN01 return and its required review pass.

Proceed autonomously after the S03 bootstrap. Return only at a defined stop or with the complete sealed S03 RUN01 return; no intermediate approval ceremony is required.
