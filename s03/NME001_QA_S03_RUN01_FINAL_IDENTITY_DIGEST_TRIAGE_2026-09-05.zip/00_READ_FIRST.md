# Project Nexus — S03 RUN01 Final-Identity Digest QA Triage

**Packet:** `NME001_QA_S03_RUN01_FINAL_IDENTITY_DIGEST_TRIAGE_2026-09-05.zip`  
**Disposition:** `READY_FOR_INDEPENDENT_QA_TRIAGE`  
**Scope:** `POST_2026-09-02_DELTA / PACKAGING_AND_DIAGNOSTIC_REVIEW_ONLY / ZERO_SCIENTIFIC_VOTE`  
**Scientific status:** `RUN01_INCOMPLETE_NOT_EVIDENCE / NO_SCIENTIFIC_RESULT / NO_SEALED_RETURN`  
**Execution status:** `DEVELOPER_STOPPED / NO_ACTIVE_WRITER_LEASE / NO_RESUME_AUTHORIZED`

## 1. Required context model

```text
CONTEXT MODEL: INCOMING_QA_BASELINE_PLUS_THIS_DELTA_PACKET

This outgoing ZIP is a post-2026-09-02 delta, not a standalone project history.
Outside QA and any advisory Developer must use it together with
NME001_THIRD_PARTY_QA_KNOWLEDGE_STATE_2026-09-05.zip,
SHA-256 a0c10beac6a5aef00334ad7e0bc880e4ab2e09d696b7257b6116171889604358.
If that baseline is unavailable, do not claim a full-context review; return
INSUFFICIENT_CONTEXT.
```

Incoming QA baseline:

- Filename: `NME001_THIRD_PARTY_QA_KNOWLEDGE_STATE_2026-09-05.zip`
- Library ID: `libfile_ff31f30a37808191ac917ded5d6b2e33`
- Version: `0`
- Size: `84,800` bytes
- SHA-256: `a0c10beac6a5aef00334ad7e0bc880e4ab2e09d696b7257b6116171889604358`
- Internal inventory: `01_HELD_ARTIFACT_INVENTORY_SHA256.txt`
- Internal inventory SHA-256: `99431d7acfd918ef321dfa38779be4a09ca338a26896ac01e4c6672b6e600dfe`
- Verified properties: archive integrity, internal SHA list, path safety, duplicate-path check, and nested-archive check all `PASS`
- Knowledge horizon: through `2026-09-02`

The baseline already supplies the August 29–September 2 DWO-04/DWO-05, Kibot acceptance-delta, prior-QA, and TVCA history. That history is not duplicated here. The incoming QA ZIP is not nested in this outgoing ZIP.

The historical `07_DRAFT_PAUSE_RATIFICATION_DIRECTIVE_2026-08-29.md` is `HISTORICAL_REFERENCE / NONCONTROLLING / NO_CURRENT_AUTHORITY`. It is not an active instruction.

## 2. Controlling S03 state

Accept the exact S03 return as:

```text
S03_RUN01_DEFINED_STOP / RUN01_CONSUMED / INCOMPLETE_NOT_EVIDENCE /
HERMETIC_980_OF_980_PASS / LICENSED_INCLUSIVE_1041_OF_1041_PASS /
POST_LICENSED_PLACEMENT_REHASH_PASS / SCIENTIFIC_DEVELOPMENT_FAILED /
NO_SCIENTIFIC_RESULT / NO_SEALED_RETURN
```

Controlling stop:

- Filename: `NME001_EPOCH07_S03_RUN01_SCIENTIFIC_DEVELOPMENT_DEFINED_STOP_2026-09-05.json`
- Library ID: `libfile_12ba2627f2b88191b3e3128eb2efb401`
- Version: `0`
- Size: `9,497` bytes
- SHA-256: `90c9cc26b6ec36860bea0fbc010b87cb4926bc1ae819c0ff913f295b0137c990`
- Durable readback: `PASS`

The unchanged command failed with:

```text
S02ExecutionError: frozen final ordered identity digest mismatch
```

The failure occurred after both engineering lanes and the nine-placement rehash passed, but before the Kibot development prefix was read, the corporate-action ledger was parsed, a scientific result was emitted, or a historical-final payload byte was accessed.

Historical-final outcomes remain unopened. The passing engineering lanes are diagnostic only. They are not official evidence because RUN01 did not complete and no sealed return or final review exists.

Writer Lease 03 is closed. No Developer writer is active. While QA triage is pending, no scientific-stage resume, RUN02, Writer Lease 04, checkpoint v4, source edit, rerun, or evidence promotion is authorized. Developer must remain stopped.

## 3. Authority precedence and supplied controls

Apply the supplied records in this order:

1. Current S03 RUN01 defined stop in `03_RUN01_CORE_DIAGNOSTICS/`
2. Lease-03 continuation
3. S03 parent control
4. Scientific control projection
5. Inherited Epoch-07 lineage, only where not superseded by the later records above

Epoch-07 lineage cannot override the later terms.

The five authority records copied unchanged into `01_AUTHORITY/` are:

1. `NME001_ORIGIN_EPOCH07_S03_POST_CHECKPOINT_RECOVERY_AND_RUN01_2026-09-05.md`
   - Library ID: `libfile_8a0d418fea648191bd9a3ef93154f1a2`
   - Version: `0`; size: `17,343` bytes
   - SHA-256: `17efb16a19fa403aca9e98388129a7bfab976a39861df0300e4222fb25a047ea`
   - Classification: `S03_PARENT_CONTROL / CURRENT_WHERE_NOT_SUPERSEDED`

2. `NME001_ORIGIN_EPOCH07_S02_V4_CONTROL_PROJECTION_AND_CONFORMANCE_REMEDIATION_2026-09-04.json`
   - Library ID: `libfile_96adab97fea88191a3218df17cc83033`
   - Version: `0`; size: `13,805` bytes
   - SHA-256: `2d42306ab9a37d225fe6354345bbd6826d69d5bc8da1d47025ef0803f7f3b03b`
   - Classification: `SCIENTIFIC_CONTROL_PROJECTION / CURRENT_WHERE_NOT_SUPERSEDED`

3. `NME001_ORIGIN_EPOCH07_S03_DURABILITY_PREFIX_REMEDIATION_AND_RUN01_CONTINUATION_2026-09-05.md`
   - Library ID: `libfile_3b6c79761e40819185e27684e25ed4d3`
   - Version: `0`; size: `12,885` bytes
   - SHA-256: `e773e9abaaa167965587f46ca82433d65a4592e7dbb8af203a84e338d23f5e70`
   - Classification: `LEASE03_CONTINUATION / NONCONTROLLING_AFTER_DEFINED_STOP`

4. `NME001_ORIGIN_EPOCH07_PROVENANCE_SAFE_CONTINUATION_2026-09-03.md`
   - Library ID: `libfile_b5fb67f073dc8191b6a294097fc3e0c4`
   - Version: `0`; size: `10,607` bytes
   - SHA-256: `ae268b60d68dde4c751fe2728eec3fb9e9ea9b0c12ec8141897ad08b0e8d302c`
   - Classification: `INHERITED_LINEAGE / NONCONTROLLING_WHERE_SUPERSEDED`

5. `NME001_ORIGIN_STEWARD_ORDER_QA_S03_RUN01_DIGEST_TRIAGE_PACKET_2026-09-05.md`
   - Library ID: `libfile_bec808b3fd948191b8562db404f72672`
   - Version: `0`; size: `21,472` bytes
   - SHA-256: `9ff65e19a9e4305d7442f0e1efaec2175f9d9ec012472a1d87b2850d98681d24`
   - Classification: `CURRENT_STEWARD_PACKET_ORDER / PACKET_ASSEMBLY_AUTHORITY`

The broader SEO-01 order is already held by QA and is pointer-only here: Library `libfile_b0c21e139bc48191a00cac3abf20cc30`, SHA-256 `92a1da1ad9904ee63358c545562aea1cf05b717a8618be25b8f94b06b6fffcb3`.

The historical `1,461` count was rejected as unsupported and is noncontrolling. The prospective named inventories and ordered digests govern. Historical candidate, return, or PASS-shaped documents nested inside checkpoint v3 are checkpoint/source context only and cannot override the current `INCOMPLETE_NOT_EVIDENCE` defined stop.

The Project Compass and role memories are not included. They are navigation records, not evidence, and may contain rapidly changing or historical execution summaries. The exact controls and defined stop govern.

## 4. Current role and authority map

| Role | Current scope and authority |
| --- | --- |
| Product Owner | Reserves authority over material scientific changes, spending/provider/account/security action, historical-final opening, authority promotion, broker/trading/automation, public disclosure, and destructive action. |
| Origin | Owns bounded direction and disposition within the adopted Project Nexus goal. |
| Developer | Stopped. No active writer lease and no authority to edit, rerun, resume, create RUN02, or promote evidence. |
| Outside QA | Independent documentary and technical reviewer with zero Nexus execution authority. |
| Advisory Developer used by QA | May work only within the isolated, sanitized advisory scope below; zero Nexus writer or execution authority. |
| Steward | Assembles and files this packet only; gains no scientific authority or new private-data custodian authority. Protected inputs remain under existing custody controls. |
| Live Market Desk | May make descriptive current-market observations only. |
| TradingView Lab | Develops the separate direct interpreter. |
| Researcher | May develop research candidates but cannot purchase, implement, or approve modules. |

All trading, broker, alerting, predictive-release, and automated-action authority remains `NONE`. Project Nexus remains active; unrelated projects remain paused.

## 5. Sanitized chronology

The Product Owner's bounded `stage=development` continuation is recorded in `NEXUS_ORIGIN_SUCCESSION_AND_STATE_RECONCILIATION_2026-08-31.md` — Library `libfile_b9c11ca7773881918daa3319e407aec1`, 15,058 bytes, SHA-256 `5f8fc87d1c11f9daf17e86b2e0e24947c4d7d59c1d9a026ae842ce4a6b09bf80`.

The legacy TradingView corporate-action fixture was initially missing, then later recovered exactly and custody-bound. Separately, a subsequent semantic stop found that the complete 1998–2024 corporate-action boundary set lacked an authoritative source; the execution-neutral ledger addressed that distinct metadata-boundary blocker. The present RUN01 failure occurred before ledger parsing.

The superseded Epoch-05/TVCA-custody continuation at Library `libfile_86f9a750a10c8191b4664460605e7a55` is `SUPERSEDED / NOT_SUPPLIED`. Its account/browser-specific information is excluded; it is not copied, quoted, or exposed.

## 6. Preliminary Origin hypothesis

This is a diagnostic lead requiring independent QA verification, not an adopted finding.

1. The exact frozen identity file passed its filename, whole-file SHA-256 `db4737f03b94c1779ccd186b675d0a41fb33af3e165a949c36e476bef224c003`, count `630`, first session `2022-06-22`, and last session `2024-12-31` checks.
2. Nexus's established `exposure.session_identity_bytes` convention serializes the ordered dates as a compact JSON array plus one terminal LF. It produces the frozen digest `423f3ad6a8b398b12700710cdb37584ded4beac091d985118a7ebebf159bf429`. Outside QA reports independently reproducing that canonical identity, displayed in its return as `423f3ad6...`.
3. `s02_execution.load_frozen_final_identities` appears to serialize one ISO date plus LF per line. On the same 630 dates, that produces `ba899593920081b0ee17a2e19c7331fef9defd1a96a57c2901006f3c120013b2`, then fails against the frozen digest.
4. The synthetic test appears to derive its expectation with the same newline-per-date algorithm, allowing test and implementation to agree while disagreeing with the real frozen contract.

The separate `authority_order_sha256` value `8c340da0f567d68bd812daca1950d427f0cf39ba09ea7fa287709de60d046b2d` identifies the governing DWO-03 order. It is not another serialization of the 630 dates. The unrelated nine-session technical-event digest begins `c7f252dd...`; it is not the historical-final identity.

QA must independently reproduce or reject each point from exact packet bytes. Do not change the 630-date identity file or frozen `423f...f429` value merely to make execution pass. A change to either is outside scope unless QA first proves an authoritative conflict.

## 7. Packet map and verification metadata

This ZIP contains only:

```text
00_READ_FIRST.md
PACKAGE_CONTENTS.json
MANIFEST_SHA256SUMS.txt
01_AUTHORITY/
02_SOURCE_CHECKPOINT/
03_RUN01_CORE_DIAGNOSTICS/
```

The three root files are the only generated members. All other supplied members are unchanged durable Library bytes.

`PACKAGE_CONTENTS.json` records each imported member's relative path, source Library identity/version, size, SHA-256, classification, and purpose. Generated members use `origin: GENERATED_FOR_PACKET`.

`MANIFEST_SHA256SUMS.txt` is the hash authority for every final regular member except itself. It is ordered bytewise by relative UTF-8 path and formatted as `SHA256`, two ASCII spaces, relative path, LF.

```text
manifest_excludes_self: true
```

The manifest SHA-256 and outer ZIP size/SHA-256 are bound only in the Steward completion/readback return.

## 8. Source checkpoint

`02_SOURCE_CHECKPOINT/` contains one unchanged nested ZIP:

- Filename: `NME001_SEO01_RECOVERY_EPOCH07_S02_PROSPECTIVE_SOURCE_CHECKPOINT.zip`
- Library ID: `libfile_04f5f1bfe55881919e025e0214c2f06d`
- Version: `3`; size: `3,966,322` bytes
- SHA-256: `c046792f90ab2362993bf556e3a8abc855524af2b88d41823d6c4986c6f22894`
- Checkpoint-manifest SHA-256: `5a4e3f4d10943918b4525cd0b21fcf514aebb93c6caeff6fb68d072faf9febbf`
- Source-tree SHA-256: `8f53575bb5101096be63809cd9096217f0092c59a9c85ba3ba60208b781cab78`
- Manifest-bound payload members: `169/169` verified
- Total archive paths: `170` — 169 manifest-bound members plus the prospective-checkpoint manifest

The checkpoint ZIP is nested byte-for-byte; it was not unpacked and repacked. Allowed checkpoint categories are sanitized artifacts including historical candidate ZIPs, configuration, receipt metadata, documentation, governance, recovery records, source, tests, `pyproject.toml`, `uv.lock`, and the checkpoint manifest. It contains no private fixture payload, Kibot/raw market data, historical-final bars or outcomes, or `data/raw` member.

QA should inspect these paths inside the nested checkpoint without duplicated extracted copies:

- `src/nexus_nme001/s02_execution.py`
- `src/nexus_nme001/exposure.py`
- `src/nexus_nme001/calendar.py`
- `src/nexus_nme001/partitions.py`
- `tests/test_s02_execution.py`
- `tests/test_identity_dwo02.py`
- `tests/test_exposure_dwo04.py`
- `tests/test_partitions_holdout.py`
- `config/frozen_config.json`
- `governance/NEXUS_MARKET_EXPERIMENT_001_v1_2_2.md`
- `governance/NME001_HISTORICAL_FINAL_IDENTITIES_2022-06-22_TO_2024-12-31.json`
- `governance/NME001_PRIOR_EXPOSURE_LEDGER_v1_0_1.json`
- `s02_recovery/S02_DEPENDENCY_PROJECTION.json`
- `s02_recovery/S02_TEST_INVENTORIES.json`

A separate checkpoint-v3 freeze/review receipt is `NOT_SEPARATELY_RESOLVED / NOT_INCLUDED / NOT_RECONSTRUCTED`. Use the checkpoint's own manifest and the copied S03 parent control.

## 9. RUN01 diagnostics

The following are copied unchanged into `03_RUN01_CORE_DIAGNOSTICS/`.

Items 1–3 are `CORE_CAUSAL_DIAGNOSTIC / NOT_EVIDENCE`:

1. `NME001_EPOCH07_S03_RUN01_SCIENTIFIC_DEVELOPMENT_DEFINED_STOP_2026-09-05.json` — Library `libfile_12ba2627f2b88191b3e3128eb2efb401`, v0, 9,497 bytes, SHA-256 `90c9cc26b6ec36860bea0fbc010b87cb4926bc1ae819c0ff913f295b0137c990`.
2. `s03_supervisor.log` — Library `libfile_c75b37feecb081918612e03e9bcc3038`, v0, 6,261 bytes, SHA-256 `ad42bc57d3ab8f8d155545a12dd8a705d3ee30ebc0e18115f833a753de78d318`.
3. `s03_stage_status.jsonl` — Library `libfile_32be10a0d9b08191a22fbdaee0702c29`, v0, 2,474 bytes, SHA-256 `5a4d5b783cdb054fc1bb8eb4ce5ce03955abe969e76a69e1fdcbd1f4370d2ea3`.

Items 4–7 are `SUPPORTING_LANE_CONTEXT / NOT_EVIDENCE`:

4. `s03_hermetic_collection_check.json` — Library `libfile_fa365b89bc5081919904e1fdbda77d43`, v0, 347 bytes, SHA-256 `e2a531c80b611d48fb3cefbcb8e7dc224a0a352fa675431522588c8ce6eb7635`.
5. `s03_hermetic_junit_check.json` — Library `libfile_64ac70370d608191ad14acff030cc706`, v0, 213 bytes, SHA-256 `846dedc3a8123ff26bfb3d8d41347b4744b9791b396d706d684cbc65785a2dd5`.
6. `s03_licensed_collection_check.json` — Library `libfile_aced3166fa988191bbd50bfc18af7068`, v0, 359 bytes, SHA-256 `e4b3769ce590704c353aecee148839d77d0d32e30ff058db5139e504400daff6`.
7. `s03_licensed_junit_check.json` — Library `libfile_51c1239083448191a546c08ef4ec71d9`, v0, 224 bytes, SHA-256 `a05433a0f1de664158ca67ef78f656763cafa5525a539b80e1f1f1ccab579780`.

The four collection/JUnit files are compact validation records, not raw inventories or JUnit XML. The raw artifacts are `NOT_DURABLY_RESOLVED / NOT_INCLUDED / NOT_RECONSTRUCTED`; do not substitute historical JUnits or regenerate current results.

## 10. Stable supporting pointers

These are pointer-only and are not copied into this ZIP:

- heartbeat `libfile_53546766c5408191bfb058bf36c999bc`
- launcher `libfile_d107e91ba40c8191b167844c9f18e52c`, v1
- durability probe `libfile_f3864ecfae1c8191a7a33d975982623a`, v1
- supervisor probe `libfile_1d72471e446881919596e509bca0edce`
- static review `libfile_a1912726f93881919386a20902fea18d`
- allowlist result `libfile_8c9fc247444081919b73b8fae1900b45`
- positive control `libfile_8ff061e826688191b9090ee5a3f74dc3`
- component manifest `libfile_a9917da9c0148191a7e75228a87e0d42`
- placement matrix `libfile_a22543713b34819198ba9b938452738f`
- cache probe `libfile_2fde4bd7991c819183ab6fdf85663ecb`
- harness diff `libfile_174dcd05899c8191937978571ba6bb60`, v1
- placement receipt `libfile_5dcf843cb1f881918aaf2aa5a795723e`
- initial protected gate `libfile_d7717bdf12ec81918e759a35ee1683f1`, v0, 3,573 bytes, SHA-256 `d5d799fde356fabbe4e820a198036eb7d6aa9b6cf3a49bd8503f499e49c2f573`
- post-licensed placement rehash `libfile_82f4667f75688191a90dfd5746507280`, v0, 3,573 bytes, SHA-256 `d5d799fde356fabbe4e820a198036eb7d6aa9b6cf3a49bd8503f499e49c2f573`

Additional pointer-only records:

- Lease-02 continuation: `libfile_32de2d2010a08191b571fd7c570fc823`
- Custody control: `libfile_ee142cefd5188191a3089a901596a920`
- Accepted Kibot evidence: `libfile_397205f46a148191b92100cdf42e5f63`
- Execution-neutral corporate-action ledger: `libfile_21d801cfae948191b83b0e016976d4c6`, v2, SHA-256 `fc36574eedb161284fb9be2d857b468df3e09720ca738717b878987d64ff55b9`
- Prior QA delta: `libfile_d316dd90c110819182e72682daad07ff`
- TVCA return: `libfile_e0122623fa5881918254917170f60056`
- Product Owner bounded-continuation reconciliation: `libfile_b9c11ca7773881918daa3319e407aec1`, 15,058 bytes, SHA-256 `5f8fc87d1c11f9daf17e86b2e0e24947c4d7d59c1d9a026ae842ce4a6b09bf80`

## 11. Absolute exclusions

This packet does not contain, materialize for packaging, or expose:

- private Kibot gzip or decompressed data;
- any TradingView licensed fixture CSV payload;
- protected-stage, custody, or checkpoint `data/raw` working copies;
- raw or derived OHLCV/market rows;
- historical-final bars, outcomes, events, features, labels, predictions, metrics, plots, or scores;
- credentials, account/session data, browser state, or secrets;
- `.venv`, dependency cache, temporary roots, build/cache, or bytecode material;
- mutable Developer workspaces or execution roots;
- invalidated checkpoints; or
- a fabricated sealed return, scientific output, JUnit, inventory, or final-review record.

Private payload bytes were not materialized to prove absence. Absence is established through the exact allowlist, durable classifications, recursive archive inventory, and candidate-package scans. Textual private filenames, `.csv` or `data/raw` strings, sizes, and SHA-256 identities inside source, controls, or metadata are expected references and are not payload leakage.

The incoming QA baseline is excluded from this outgoing ZIP because it is the separate context baseline, not a delta member. The checkpoint-v3 freeze/review receipt is not separately resolved, included, or reconstructed.

## 12. Packet verification boundaries

Before relying on this packet, verify imported files against their durable identities, versions, sizes, and SHA-256 values; outer ZIP integrity; exact member count; `PACKAGE_CONTENTS.json`; every manifest-bound member; the unchanged nested checkpoint ZIP; recursive nested-archive inventory; source-identity bindings; and exclusion scans.

Reject duplicate or case-colliding paths, absolute or traversal paths, symlink or special-file members, encrypted or otherwise uninspectable nested archives, prohibited archive members, credential or secret material, actual tabular market rows, and any candidate member whose actual bytes, size, or SHA-256 matches a protected payload identity. Every scan hit must be classified and explained.

A clean packet is only `READY_FOR_INDEPENDENT_QA_TRIAGE`. It is never `QA_APPROVED`, scientific evidence, an execution continuation, or an authority promotion.

## 13. Outside-QA and advisory-Developer boundary

Outside QA may use its capable Developer as an advisory technical reviewer in a private isolated copy. They may inspect sanitized source, tests, configuration, protocols, controls, manifests, and logs; recompute digests; run no-network synthetic or hermetic diagnostics requiring no excluded input; identify root cause; and return an unapplied source/test diff.

They may not modify Nexus Library records, claim a Nexus writer lease, touch licensed inputs, run the official licensed or scientific lane, open historical-final market bytes or outcomes, create or seal official evidence, promote a result, or authorize execution. Any proposed patch has zero authority until Origin independently adopts it.

## 14. Questions for QA

Return one independently reasoned report addressing:

1. Does the exact 630-date file reproduce `423f...f429` under the established canonical serialization?
2. Does `load_frozen_final_identities` produce `ba899...013b2` because it uses a different serializer?
3. Did the synthetic test mask that divergence?
4. Is this localized binding/serialization implementation drift with zero scientific-semantic effect, or an authoritative conflict?
5. Do supplied records show checkpoint corruption, identity-list drift, protected-data leakage, or final-outcome exposure? Use `NOT_ASSESSED / INSUFFICIENT_SCOPE` for anything the sanitized packet cannot establish.
6. What is the smallest exact repair? Prefer the established canonical helper over another duplicate serializer.
7. What exact real-artifact regression is needed? If a test is added or renamed, identify the named-inventory and ordered-digest consequence.
8. Can the diagnosis and repair be established without licensed bytes or final outcomes?
9. Must a repair create a new prospective checkpoint and run every lane afresh under a new segment/run identity?
10. What immutable inputs, competence requirements, and fresh-root boundary should the sole successor Developer receive?
11. `SECONDARY / NONBLOCKING`: reconcile the historical `922/983` parents with current `980/1041` inventories from supplied records, or state exactly what evidence is unavailable. This must not delay the serializer-root-cause disposition.

## 15. Required QA return

Preferred return: one concise Markdown main report plus an optional separate unapplied source/test diff, each with exact size and SHA-256. Do not create a giant appendix unless a material finding cannot be evidenced otherwise.

Classify the main return as exactly one of:

- `ROOT_CAUSE_CONFIRMED / NARROW_REPAIR_RECOMMENDED`
- `ROOT_CAUSE_REJECTED / ALTERNATE_DIAGNOSIS_PROVIDED`
- `AUTHORITATIVE_CONFLICT / ORIGIN_DECISION_REQUIRED`
- `INSUFFICIENT_SANITIZED_EVIDENCE`

No QA return authorizes implementation, execution, evidence promotion, historical-final access, or release. Developer remains stopped pending a separate Origin disposition.
