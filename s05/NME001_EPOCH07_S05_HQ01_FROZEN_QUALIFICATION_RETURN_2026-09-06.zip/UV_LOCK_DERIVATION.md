# Prospective uv project-lock path derivation

This is bounded first-repair analysis of the undeclared temporary lock produced
by the already executed F00 QP-01 synchronization. No additional uv invocation,
case, synchronization, dependency acquisition, or filesystem probe was used.

## Exact observations

- Runtime binary: `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/uv`.
- Bound runtime version: `uv 0.11.33 (x86_64-unknown-linux-gnu)`.
- Binary: stripped ELF x86-64; BuildID `05955ce1fdcd8b2cfcf699abdac7174208c92cb8`.
- Installed uv SBOM identifies `seahash` version `4.1.0`.
- The F00 sync stderr identifies the project environment at
  `/workspace/scratch/cbd6528b11d8/NME001_EPOCH07_S05_HQ01/cases/F00/QP-01/runtime/.venv`.
- Its observed TMP file is `uv-bf849b7789075826.lock`, a zero-byte regular file.

Static binary inspection found the `uv-{digest}.lock` format at ELF virtual
address `0x2650de`. A format call at `0x1938d37` follows the Path digest call to
`0x1dc0390`. That routine uses SeaHash's four standard seeds, consumes path
components without separators, and appends a little-endian u64 containing
component lengths accumulated with a two-bit right rotation after each
component. SeaHash write and finalize are at `0xfbcc70` and `0xfbd1e0`;
`0x2327b90` encodes the finalized u64's little-endian bytes as hexadecimal.
A separate string digest at `0x1dc05e0` appends `0xff`; that is distinct from
the Path representation that reproduces this project lock.

Independent, read-only Python arithmetic reproduced these values:

| Input path | Path digest |
| --- | --- |
| `/workspace/scratch/cbd6528b11d8/NME001_EPOCH07_S05_HQ01/cases/F00/QP-01/synthetic` (Q) | `bf849b7789075826` |
| `/workspace/scratch/cbd6528b11d8/NME001_EPOCH07_S05_HQ01/cases/F00/QP-01/runtime/.venv` (V) | `bf6897d41458aa5d` |
| `/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python` | `14c375719a4f3a40` |

The expected filename from the Q calculation and the observed F00 filename are
both exactly `uv-bf849b7789075826.lock`. Thus the applicable temporary project
lock is bound to Q; it is not invariant under a change of Q's absolute prefix.
`qualification/uv_path_contract.py` computes each descriptor's exact filename
prospectively, without executing uv or learning a path from a new realization.
This derivation is scoped to the bound binary, platform, and canonical absolute
POSIX paths. It does not claim support for arbitrary uv versions or platforms.

## Remaining unknown

The derivation and prefix invariance of the interpreter-cache keys
`interpreter-v4/e128016a93bda1d6/7f8106be2b9d4caa.msgpack` remain **UNKNOWN**.
The temporary project-lock derivation does not establish their contract.
