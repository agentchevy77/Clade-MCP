"""Observe inherited process state without correcting it."""
from __future__ import annotations
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


def main() -> int:
    descriptor = json.loads(Path(sys.argv[1]).read_text())
    generation = sys.argv[2]
    expected = descriptor['environment']
    observation = {
        'generation': generation, 'pid': os.getpid(), 'parent_pid': os.getppid(),
        'cwd': str(Path.cwd()), 'environment': dict(os.environ),
        'executable': sys.executable, 'version': platform.python_version(),
        'dont_write_bytecode': sys.dont_write_bytecode,
        'argv_no_bytecode': '-B' in sys.orig_argv,
    }
    if Path.cwd() != Path(descriptor['roots']['Q']):
        observation.update(status='FAIL', boundary='INHERITED_CWD_GATE')
    elif (dict(os.environ) != expected or not sys.dont_write_bytecode
          or '-B' not in sys.orig_argv
          or sys.executable != descriptor['runtime']['python']
          or platform.python_version() != descriptor['runtime']['python_version']):
        observation.update(status='FAIL', boundary='INHERITED_ENVIRONMENT_GATE')
    else:
        observation.update(status='PASS', boundary='INHERITED_STATE_GATE')
    if observation['status'] == 'PASS' and generation == 'child':
        child = subprocess.run(
            descriptor['inheritance']['grandchild_argv'],
            cwd=Path.cwd(), env=dict(os.environ), stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=False,
        )
        observation['grandchild_exit_code'] = child.returncode
        observation['grandchild_stderr'] = child.stderr.decode(errors='replace')
        try:
            observation['grandchild'] = json.loads(child.stdout)
        except (ValueError, UnicodeDecodeError):
            observation.update(status='FAIL', boundary='INHERITED_ENVIRONMENT_GATE')
            observation['grandchild_stdout'] = child.stdout.decode(errors='replace')
        if child.returncode != 0:
            observation.update(status='FAIL', boundary=observation.get('grandchild', {}).get(
                'boundary', 'INHERITED_ENVIRONMENT_GATE'))
    print(json.dumps(observation, sort_keys=True))
    return 0 if observation['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
