"""Root-parameterized production launcher; no qualification fault controls."""
from __future__ import annotations
import argparse
import datetime
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import stat
import subprocess
import sys
import uuid
import xml.etree.ElementTree as ET

from cache import verify_cache, CacheError
from supervisor import supervise, verify_durable_probe, S02SupervisorError


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':')) + '\n').encode()


def sha(value):
    return hashlib.sha256(value).hexdigest()


def identity(path):
    data = Path(path).read_bytes()
    return {'size_bytes': len(data), 'sha256': sha(data)}


def exists(path):
    return os.path.lexists(path)


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def real_dir(path):
    p = Path(path)
    if not stat.S_ISDIR(p.lstat().st_mode) or p.is_symlink():
        raise RuntimeError(f'not a real directory: {p}')
    return p


def write_exclusive(path, data):
    p = Path(path)
    real_dir(p.parent)
    with p.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_dir(p.parent)
    with p.open('rb') as stream:
        observed = stream.read()
    if observed != data:
        raise RuntimeError(f'exclusive write readback differs: {p}')


def probe_dir(path):
    p = real_dir(path)
    token = uuid.uuid4().hex
    first, second = p / ('.probe-' + token), p / ('.probe-' + token + '-renamed')
    payload = ('NME001_WRITE_PROBE:' + token).encode()
    try:
        write_exclusive(first, payload)
        first.rename(second)
        fsync_dir(p)
        if second.read_bytes() != payload:
            raise RuntimeError(f'probe readback differs: {p}')
        second.unlink()
        fsync_dir(p)
        if exists(first) or exists(second):
            raise RuntimeError(f'probe residue: {p}')
    finally:
        for residue in (first, second):
            if exists(residue):
                residue.unlink()
    return {'directory': str(p), 'method': 'create/write/flush/file-fsync/rename/parent-fsync/read/delete/parent-fsync',
            'probe_paths': [str(first), str(second)], 'residue_absent': True, 'status': 'PASS'}


class GateError(RuntimeError):
    def __init__(self, boundary, detail):
        super().__init__(detail)
        self.boundary = boundary


class Harness:
    def __init__(self, descriptor_path):
        self.descriptor_path = Path(descriptor_path)
        self.descriptor_bytes = self.descriptor_path.read_bytes()
        self.d = json.loads(self.descriptor_bytes)
        self.roots = {k: Path(v) for k, v in self.d['roots'].items()}
        self.entries = self.d['write_set']
        self.targets = {e['id']: e for e in self.entries}
        self.receipts = []
        self.processes = []
        self.commit_count = 0
        self.spawn_attempt_count = 0
        self.synthetic_spawns = 0
        self.boundary = 'DESCRIPTOR_GATE'
        self.validate_descriptor()

    def path(self, key):
        return Path(self.targets[key]['path'])

    def emit(self, key, payload):
        if key not in self.targets:
            raise GateError('WRITE_SET_GATE', f'undeclared output: {key}')
        write_exclusive(self.path(key), canonical(payload))
        self.observe_output(key)

    def observe_output(self, key):
        entry = self.targets[key]
        p = self.path(key)
        if entry['after'] != 'EXISTS_IF_STAGE_REACHED':
            raise GateError('WRITE_SET_GATE', f'output postcondition differs: {key}')
        st = p.lstat()
        if not stat.S_ISREG(st.st_mode) or p.is_symlink():
            raise GateError('WRITE_SET_GATE', f'output not realized regular file: {p}')
        observed = {'id': key, 'stage': entry['stage'], 'after_required': entry['after'],
                    'observed_type': 'file', 'path': str(p), 'identity': identity(p), 'status': 'PASS'}
        self.receipts.append(observed)
        return observed

    def validate_descriptor(self):
        schema = json.loads((Path(__file__).parent / 'descriptor.schema.json').read_text())
        if set(self.d) != set(schema['required']):
            raise GateError('DESCRIPTOR_GATE', 'descriptor fields differ from schema')
        if self.d['schema_version'] != schema['properties']['schema_version']['const']:
            raise GateError('DESCRIPTOR_GATE', 'schema version differs')
        rs = schema['properties']['roots']
        if set(self.roots) != set(rs['required']):
            raise GateError('DESCRIPTOR_GATE', 'root keys differ')
        b = self.roots['B']
        if not b.is_absolute() or b.resolve() != b:
            raise GateError('DESCRIPTOR_GATE', 'B must be an absolute real path')
        for k, p in self.roots.items():
            if not p.is_absolute() or (k != 'B' and (p == b or not p.is_relative_to(b))):
                raise GateError('DESCRIPTOR_GATE', f'root not strictly contained: {k}')
            if p.resolve() != p:
                raise GateError('DESCRIPTOR_GATE', f'root alias: {k}')
        topology = rs['x-topology']
        for parent, group in [('B', topology['direct_children_of_B']), ('R', topology['direct_children_of_R'])]:
            values = [self.roots[k] for k in group]
            if len(set(values)) != len(values) or any(p.parent != self.roots[parent] for p in values):
                raise GateError('DESCRIPTOR_GATE', 'root topology differs')
        if self.roots['V'].name != topology['V_basename']:
            raise GateError('DESCRIPTOR_GATE', 'V is not R/.venv')
        if len(self.targets) != len(self.entries) or len({e['path'] for e in self.entries}) != len(self.entries):
            raise GateError('WRITE_SET_GATE', 'duplicate write target')
        allowed = schema['properties']['write_set']['items']['properties']
        required = schema['properties']['write_set']['items']['required']
        for e in self.entries:
            if not set(required) <= set(e) or set(e) - set(allowed):
                raise GateError('WRITE_SET_GATE', 'write entry fields differ')
            p = Path(e['path'])
            if p == b or not p.is_absolute() or not p.is_relative_to(b) or p.resolve() != p:
                raise GateError('WRITE_SET_GATE', f'write target escapes or aliases: {p}')
        self.check_protected()
        if self.d['execution_class'] == 'QUALIFICATION':
            if self.d['run_identity'] is not None or 'RUN' in self.d['execution_identity']:
                raise GateError('AUTHORITY_GATE', 'invalid qualification identity')
        elif self.d['execution_class'] == 'RUN':
            if not self.d['run_identity']:
                raise GateError('AUTHORITY_GATE', 'run requires exact nonempty identity')
        else:
            raise GateError('AUTHORITY_GATE', 'unknown execution class')
        expected = self.d['environment']
        r = self.roots
        bindings = {'XDG_CACHE_HOME': str(r['P']), 'UV_PROJECT_ENVIRONMENT': str(r['V']),
                    'TMPDIR': str(r['TMP']), 'MPLCONFIGDIR': str(r['MPL']),
                    'UV_OFFLINE': '1', 'UV_NO_CONFIG': '1', 'PYTHONDONTWRITEBYTECODE': '1'}
        if any(expected.get(k) != v for k, v in bindings.items()) or 'SOURCE_DATE_EPOCH' in expected:
            raise GateError('ENVIRONMENT_GATE', 'descriptor environment bindings differ')
        if sorted(k for k in expected if k.startswith('UV_')) != ['UV_NO_CONFIG', 'UV_OFFLINE', 'UV_PROJECT_ENVIRONMENT']:
            raise GateError('ENVIRONMENT_GATE', 'UV key set differs')
        runtime = self.d['runtime']
        if (dict(os.environ) != expected or not sys.dont_write_bytecode or '-B' not in sys.orig_argv
            or sys.executable != runtime['python'] or platform.python_version() != runtime['python_version']
            or platform.python_implementation() != runtime['implementation']
            or platform.system() != runtime['system'] or platform.machine() != runtime['machine']
            or list(platform.libc_ver()) != runtime['libc']):
            raise GateError('ENVIRONMENT_GATE', 'actual parent environment/runtime differs')
        if Path.cwd() != r['T']:
            raise GateError('INHERITED_CWD_GATE', 'outer cwd differs')

    def check_protected(self):
        for e in self.entries:
            if e['kind'] == 'protected' and exists(e['path']):
                raise GateError('PROTECTED_BOUNDARY_GATE', f'prohibited path exists: {e["path"]}')

    def check_inputs(self):
        observed = {}
        for name, record in self.d['inputs'].items():
            p = Path(name)
            if not p.is_relative_to(self.roots['B']) or not stat.S_ISREG(p.lstat().st_mode) or p.is_symlink():
                raise GateError('PROVENANCE_GATE', f'input type/containment differs: {name}')
            observed[name] = identity(p)
            if observed[name] != record:
                raise GateError('PROVENANCE_GATE', f'input bytes differ: {name}')
        for p in self.roots['Q'].rglob('*'):
            if p.is_file() and str(p) not in observed:
                raise GateError('PROVENANCE_GATE', f'undeclared source member: {p}')
        return observed

    def readiness(self):
        self.boundary = 'WRITE_SET_READINESS_GATE'
        # Construction, observation, and probes all iterate the descriptor's one write set.
        for e in self.entries:
            if e['stage'] != 'PRECOMMIT' or e['kind'] != 'directory':
                continue
            p = Path(e['path'])
            if not exists(p):
                real_dir(p.parent)
                p.mkdir()
                fsync_dir(p.parent)
            real_dir(p)
            if e['before'] == 'ABSENT_OR_EXISTS_WRITABLE_EMPTY' and any(p.iterdir()):
                raise GateError(self.boundary, f'nonempty precommit root: {p}')
            self.receipts.append({'id': e['id'], 'stage': 'PRECOMMIT', 'observed_type': 'directory',
                                  'mode': oct(p.lstat().st_mode), 'probe': probe_dir(p), 'status': 'PASS'})
        for e in self.entries:
            p = Path(e['path'])
            if e['kind'] == 'protected':
                if exists(p):
                    raise GateError('PROTECTED_BOUNDARY_GATE', f'protected path exists: {p}')
                self.receipts.append({'id': e['id'], 'stage': 'PRECOMMIT', 'observed': 'ABSENT', 'status': 'PASS'})
            elif e['before'].startswith('RESERVED_ABSENT'):
                if exists(p):
                    raise GateError(self.boundary, f'reserved target prematurely exists: {p}')
                parent = real_dir(p.parent)
                self.receipts.append({'id': e['id'], 'stage': 'PRECOMMIT_PARENT', 'target_observed': 'ABSENT',
                                      'parent_probe': probe_dir(parent), 'status': 'PASS'})
        self.emit('readiness', {'schema_version': 'NME001_WRITE_SET_OBSERVATION_V1', 'status': 'PASS',
                               'write_set_sha256': sha(canonical(self.entries)), 'entries': self.receipts})

    def command(self, key, boundary):
        spec = self.d['commands'][key]
        for output in ('stdout', 'stderr'):
            target = self.path(spec[output])
            real_dir(target.parent)
            probe_dir(target.parent)
            if exists(target):
                raise GateError(boundary, f'command output already exists: {target}')
        self.boundary = boundary
        with self.path(spec['stdout']).open('xb') as out, self.path(spec['stderr']).open('xb') as err:
            process = subprocess.Popen(spec['argv'], cwd=spec['cwd'], env=self.d['environment'],
                                       stdin=subprocess.DEVNULL, stdout=out, stderr=err, shell=False)
            started = utc()
            code = process.wait()
            for stream in (out, err):
                stream.flush()
                os.fsync(stream.fileno())
        result = {'stage': key, 'pid': process.pid, 'started_utc': started, 'exited_utc': utc(),
                  'exit_code': code, 'argv': spec['argv'], 'cwd': spec['cwd'],
                  'stdout': str(self.path(spec['stdout'])), 'stderr': str(self.path(spec['stderr']))}
        self.processes.append(result)
        for output in ('stdout', 'stderr'):
            self.observe_output(spec[output])
        owning_stage = self.targets[spec['stdout']]['stage']
        for entry in self.entries:
            if (entry['kind'] == 'file' and entry['stage'] == owning_stage
                    and entry['id'] not in (spec['stdout'], spec['stderr']) and exists(entry['path'])):
                self.observe_output(entry['id'])
        return result

    def managed_observe(self, key):
        entry = self.targets[key]
        if entry['after'] != 'EXISTS_WRITABLE_VERIFIED':
            raise GateError('WRITE_SET_GATE', f'managed-tree postcondition differs: {key}')
        root = real_dir(entry['path'])
        rows = []
        for base, dirs, files in os.walk(root, followlinks=False):
            for name in sorted(dirs + files):
                p = Path(base) / name
                st = p.lstat()
                rel = str(p.relative_to(root))
                if stat.S_ISLNK(st.st_mode):
                    rows.append({'path': rel, 'type': 'symlink', 'target': os.readlink(p)})
                elif stat.S_ISDIR(st.st_mode):
                    rows.append({'path': rel, 'type': 'directory'})
                elif stat.S_ISREG(st.st_mode):
                    rows.append({'path': rel, 'type': 'file', **identity(p)})
                else:
                    raise GateError('WRITE_SET_GATE', f'special entry in managed tree: {p}')
        rows.sort(key=lambda x: x['path'])
        contract = entry['member_contract']
        if 'required_members' in contract:
            actual = {row['path']: row for row in rows}
            required = contract['required_members']
            optional = contract.get('optional_members', {})
            if set(required) - set(actual) or set(actual) - (set(required) | set(optional)):
                raise GateError('WRITE_SET_GATE', f'{key} member set differs: missing={sorted(set(required)-set(actual))[:12]}, unexpected={sorted(set(actual)-(set(required)|set(optional)))[:12]}')
            for relative, observed in actual.items():
                expected = (optional | required)[relative]
                if observed['type'] != expected['kind']:
                    raise GateError('WRITE_SET_GATE', f'{key} member type differs: {relative}')
                if 'sha256' in expected and observed.get('sha256') != expected['sha256']:
                    raise GateError('WRITE_SET_GATE', f'{key} immutable member differs: {relative}')
            missing_optional = sorted(set(optional) - set(actual) - set(required))
        else:
            missing_optional = []
        probes = [probe_dir(root)]
        # Every writable descendant directory is observed and write-probed after its owning construction stage.
        for row in rows:
            if row['type'] == 'directory':
                probes.append(probe_dir(root / row['path']))
        return {'id': key, 'stage': entry['stage'], 'root': str(root), 'observed_type': 'directory',
                'after_required': entry['after'], 'status': 'PASS', 'members': rows,
                'optional_members_observed_absent': missing_optional,
                'members_sha256': sha(canonical(rows)), 'directory_probes': probes}

    def commit(self):
        self.boundary = 'COMMIT_GATE'
        lock = self.path('launch_lock')
        write_exclusive(lock, canonical({'execution_identity': self.d['execution_identity'], 'owner_pid': os.getpid()}))
        self.observe_output('launch_lock')
        commit_key = 'qualification_commit' if self.d['execution_class'] == 'QUALIFICATION' else 'run_commit'
        binding = {'record_type': 'QUALIFICATION_CASE_COMMIT' if commit_key == 'qualification_commit' else 'RUN_ATTEMPT_COMMIT',
                   'execution_identity': self.d['execution_identity'], 'run_identity': self.d['run_identity'],
                   'execution_class': self.d['execution_class'], 'lease_identity': self.d['lease_identity'],
                   'created_utc': utc(), 'checkpoint_sha256': self.d['fixture_sha256'],
                   'production_sha256': self.d['production_sha256'], 'descriptor_sha256': sha(self.descriptor_bytes),
                   'command': self.d['commands']['collection'], 'environment': self.d['environment'],
                   'expected_collection': self.d['expected_collection'],
                   'readiness': identity(self.path('readiness')), 'precommit': identity(self.path('precommit')),
                   'authority': 'NONE' if commit_key == 'qualification_commit' else 'REQUIRES_SEPARATE_ORIGIN_ORDER'}
        write_exclusive(self.path(commit_key), canonical(binding))
        self.commit_count = 1
        self.observe_output(commit_key)
        return binding

    def supervised(self, key):
        spec = self.d['commands'][key]
        self.boundary = 'SUPERVISED_' + key.upper()
        for name in [spec['stdout'], spec['stderr'], 'heartbeat', 'stage_status', 'supervisor_log']:
            probe_dir(self.path(name).parent)
        if key == 'collection':
            self.spawn_attempt_count += 1
        result = supervise(spec['argv'], execution_identity=self.d['execution_identity'],
            run_identity=self.d['run_identity'], execution_class=self.d['execution_class'],
            heartbeat_path=self.path('heartbeat'), log_path=self.path('supervisor_log'),
            stdout_path=self.path(spec['stdout']), stderr_path=self.path(spec['stderr']),
            stage=key.upper(), stage_status_path=self.path('stage_status'),
            durable_probe_path=self.roots['T'] / 'durable_probe.json',
            durable_probe_readback_path=self.roots['T'] / 'durable_probe_readback.json',
            checkpoint_sha256=self.d['fixture_sha256'], cwd=spec['cwd'], environment=self.d['environment'])
        self.synthetic_spawns += 1
        self.processes.append({'stage': key, 'argv': spec['argv'], 'cwd': spec['cwd'], **result})
        for name in [spec['stdout'], spec['stderr'], 'heartbeat', 'stage_status', 'supervisor_log']:
            self.observe_output(name)
        if result['exit_code'] != 0:
            raise GateError('SUPERVISED_CHILD_EXIT_GATE', f'{key} child exited {result["exit_code"]}')
        return result

    def counts(self):
        # Heartbeat STARTED is the observed successful OS creation, independent of return-value accounting.
        started = []
        if exists(self.path('heartbeat')):
            started = [json.loads(x) for x in self.path('heartbeat').read_text().splitlines()
                       if json.loads(x).get('status') == 'STARTED']
        return {'qualification_commits': int(exists(self.path('qualification_commit'))),
                'run_attempt_commits': int(exists(self.path('run_commit'))),
                'synthetic_child_spawns': len(started), 'synthetic_child_pids': [r['child_pid'] for r in started],
                'first_child_spawn_attempts': self.spawn_attempt_count,
                'protected_contact_count': 0, 'scientific_episode_count': 0}

    def execute(self):
        # A durable commit is terminal for re-entry, before any readiness repair or child creation.
        if exists(self.path('qualification_commit')) or exists(self.path('run_commit')):
            self.emit('replay_rejection', {'status': 'REJECTED', 'boundary': 'COMMIT_REPLAY_GATE',
                      'execution_identity': self.d['execution_identity'], 'run_identity': self.d['run_identity'],
                      'new_spawn_attempts': 0, **self.counts()})
            return 73
        try:
            self.readiness()
            before = self.check_inputs()
            self.emit('input_before', before)
            self.boundary = 'DURABLE_RECOVERY_GATE'
            durable_hash = verify_durable_probe(self.roots['T'] / 'durable_probe.json',
                self.roots['T'] / 'durable_probe_readback.json', execution_identity=self.d['execution_identity'],
                run_identity=self.d['run_identity'], execution_class=self.d['execution_class'],
                checkpoint_sha256=self.d['fixture_sha256'])
            self.boundary = 'RUNTIME_GATE'
            version = subprocess.run([self.d['runtime']['uv'], '--version'], cwd=self.roots['T'],
                env=self.d['environment'], stdin=subprocess.DEVNULL, capture_output=True, text=True, shell=False)
            if version.returncode or version.stdout.strip() != self.d['runtime']['uv_version']:
                raise GateError(self.boundary, 'uv runtime differs')
            result = self.command('inheritance', 'INHERITED_ENVIRONMENT_GATE')
            observed = json.loads(self.path('inheritance_stdout').read_bytes())
            if result['exit_code'] or observed.get('status') != 'PASS':
                raise GateError(observed.get('boundary', 'INHERITED_ENVIRONMENT_GATE'), 'inherited process observation failed')
            result = self.command('bootstrap', 'CACHE_BOOTSTRAP_GATE')
            if result['exit_code']:
                raise GateError('CACHE_BOOTSTRAP_GATE', f'bootstrap exited {result["exit_code"]}')
            self.boundary = 'EXACT_PUBLIC_CACHE_GATE'
            cache = verify_cache(Path(self.d['cache']['package_root']), self.roots['P'] / 'uv',
                uv_executable=self.d['runtime']['uv'], cwd=self.roots['T'], environment=self.d['environment'])
            self.emit('cache_receipt', cache)
            cache_write = self.managed_observe('public_cache')
            self.emit('cache_write_receipt', cache_write)
            if exists(self.roots['V']):
                raise GateError('UV_SYNC_GATE', 'V exists before owning synchronization stage')
            probe_dir(self.roots['V'].parent)
            result = self.command('sync', 'UV_SYNC_GATE')
            if result['exit_code']:
                raise GateError('UV_SYNC_GATE', f'locked offline sync exited {result["exit_code"]}')
            self.boundary = 'UV_SYNC_GATE'
            venv = self.managed_observe('virtual_environment')
            installed = {d.metadata['Name'].lower(): d.version for d in importlib.metadata.distributions(
                path=[str(self.roots['V'] / 'lib' / 'python3.12' / 'site-packages')])}
            if installed != self.targets['virtual_environment']['member_contract']['distributions']:
                raise GateError('UV_SYNC_GATE', f'installed projection differs: {installed}')
            venv['installed_projection'] = installed
            self.emit('venv_receipt', venv)
            self.emit('cache_post_sync', self.managed_observe('public_cache'))
            if exists(self.roots['Q'] / '.venv'):
                raise GateError('WRITE_SET_GATE', 'runtime environment entered source')
            self.check_inputs()
            self.check_protected()
            self.emit('precommit', {'status': 'PASS', 'durable_probe_sha256': durable_hash,
                'descriptor_sha256': sha(self.descriptor_bytes), 'processes': self.processes,
                'readiness': identity(self.path('readiness')), 'cache': identity(self.path('cache_receipt')),
                'cache_write_set': identity(self.path('cache_write_receipt')), 'venv': identity(self.path('venv_receipt'))})
            self.commit()
            self.supervised('collection')
            self.boundary = 'COLLECTION_INVENTORY_GATE'
            text = self.path('collection_stdout').read_text()
            inventory = [x.strip() for x in text.splitlines() if '::' in x and not x.startswith(' ')]
            if inventory != self.d['expected_collection']:
                raise GateError(self.boundary, f'collection inventory differs: {inventory}')
            self.emit('collection_check', {'status': 'PASS', 'inventory': inventory, 'count': len(inventory)})
            self.supervised('test')
            self.boundary = 'JUNIT_GATE'
            self.observe_output('junit')
            xml = ET.parse(self.path('junit')).getroot()
            cases = xml.findall('.//testcase')
            names = [[c.attrib.get('classname'), c.attrib.get('name')] for c in cases]
            if (names != self.d['expected_junit'] or any(c.find(k) is not None for c in cases for k in ('failure', 'error', 'skipped'))):
                raise GateError(self.boundary, f'JUnit testcase results differ: {names}')
            self.emit('junit_check', {'status': 'PASS', 'testcases': names, 'tests': len(cases), 'failures': 0, 'errors': 0, 'skips': 0})
            after = self.check_inputs()
            if before != after:
                raise GateError('PROVENANCE_GATE', 'source/production bytes drifted')
            self.emit('input_after', after)
            self.check_protected()
            self.emit('success', {'status': 'SUCCESS', 'execution_identity': self.d['execution_identity'],
                'run_identity': self.d['run_identity'], 'authority': 'NONE', 'processes': self.processes,
                'input_byte_drift': False, **self.counts()})
            return 0
        except (Exception,) as exc:
            boundary = exc.boundary if isinstance(exc, GateError) else self.boundary
            if isinstance(exc, CacheError):
                boundary = 'EXACT_PUBLIC_CACHE_GATE'
            if isinstance(exc, S02SupervisorError) and 'unable to launch' in str(exc):
                boundary = 'POSTCOMMIT_CHILD_SPAWN_GATE'
            payload = {'status': 'STOP', 'boundary': boundary, 'error_type': type(exc).__name__, 'error': str(exc),
                       'execution_identity': self.d['execution_identity'], 'run_identity': self.d['run_identity'],
                       'observed_utc': utc(), 'processes': self.processes, 'partial_write_observations': self.receipts,
                       'underlying_error': str(exc.__cause__) if exc.__cause__ else None,
                       'authority': 'NONE', **self.counts()}
            if not exists(self.path('stop')):
                self.emit('stop', payload)
            print(json.dumps({'status': 'STOP', 'boundary': boundary, 'error': str(exc)}, sort_keys=True))
            return 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('descriptor')
    args = parser.parse_args()
    return Harness(args.descriptor).execute()


if __name__ == '__main__':
    raise SystemExit(main())
