"""Verify frozen public-cache controls and independently observe a realization."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess


PACKAGE_BASENAME = "NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64"
CONTROL_HASHES = {
    "CACHE_PAYLOAD_MANIFEST.json": "f153c44e1d1f07685c1855026c54b764f19c6d1ec008f65e66af03abf55e0def",
    "PACKAGE_MEMBER_MANIFEST.json": "4fb00aa2d367d8ff4ef18658ef794e85831468bead201e0fe0b44de0a994fa68",
    "PUBLIC_WHEEL_SOURCE_IDENTITIES.json": "a01d4e2e5d7ce5fb267a8c2db812875353aa78170cfc7ff8ad303c7cf6b26466",
    "UV_CACHE_SYMLINK_MAP.json": "ef888c8981ba1375c7df590f9f2e01d879376da18b4e2f0b2647cb8d81b50368",
    "bootstrap_uv_cache.py": "1509a85876f73e0c404306a52ec1d153715271fa08a9fec445134abc6ad64740",
}
EXPECTED_COUNTS = {"regular_files": 8928, "symlinks": 31, "directories": 839,
                   "total_regular_size_bytes": 481715990, "special_entries": 0}


class CacheError(RuntimeError):
    """The frozen public-cache contract was not independently established."""


def _json_bytes(value: object) -> bytes:
    return (json.dumps(value, sort_keys=True, separators=(",", ":"),
                       ensure_ascii=True, allow_nan=False) + "\n").encode("utf-8")


def _inventory_hash(value: object) -> str:
    return hashlib.sha256(_json_bytes(value)).hexdigest()


def _relative(raw: str, *, allow_parent: bool = False) -> PurePosixPath:
    forbidden = {"", "."} if allow_parent else {"", ".", ".."}
    if (not isinstance(raw, str) or not raw or "\\" in raw or "\x00" in raw
            or raw.startswith("/") or any(p in forbidden for p in raw.split("/"))):
        raise CacheError(f"unsafe relative path: {raw!r}")
    return PurePosixPath(raw)


def _real_directory(path: Path) -> None:
    """Check lexical ancestry without first resolving away a forbidden alias."""
    if not path.is_absolute() or ".." in path.parts:
        raise CacheError(f"directory must be absolute and canonical: {path}")
    current = Path(path.anchor)
    for part in ("", *path.parts[1:]):
        if part:
            current /= part
        if not stat.S_ISDIR(current.lstat().st_mode):
            raise CacheError(f"non-real directory ancestor: {current}")


def _regular_bytes(path: Path) -> bytes:
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
            raise CacheError(f"not a regular file: {path}")
        return stream.read()


def _regular_identity(path: Path) -> dict:
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        metadata = os.fstat(stream.fileno())
        if not stat.S_ISREG(metadata.st_mode):
            raise CacheError(f"not a regular file: {path}")
        digest = hashlib.sha256()
        size = 0
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            size += len(block)
            digest.update(block)
        if size != metadata.st_size:
            raise CacheError(f"file size changed while reading: {path}")
    return {"size_bytes": size, "sha256": digest.hexdigest()}


def _target_relative(link: str, literal: str) -> PurePosixPath:
    target = _relative(literal, allow_parent=True)
    parts = list(_relative(link).parent.parts)
    for part in target.parts:
        if part == "..":
            if not parts:
                raise CacheError(f"symlink target escapes cache: {link}")
            parts.pop()
        else:
            parts.append(part)
    if not parts:
        raise CacheError(f"symlink target resolves to cache root: {link}")
    return PurePosixPath(*parts)


def read_expected(package_root: Path) -> dict:
    """Verify all five frozen controls; return cache-relative expected members."""
    package_root = Path(package_root)
    try:
        _real_directory(package_root)
        if package_root.name != PACKAGE_BASENAME:
            raise CacheError(f"unexpected public package basename: {package_root.name}")
        controls = {}
        content = {}
        for name, expected in CONTROL_HASHES.items():
            raw = _regular_bytes(package_root / name)
            actual = hashlib.sha256(raw).hexdigest()
            if actual != expected:
                raise CacheError(f"frozen control hash mismatch: {name}; observed={actual}")
            controls[name] = actual
            content[name] = raw
        payload = json.loads(content["CACHE_PAYLOAD_MANIFEST.json"])
        link_map = json.loads(content["UV_CACHE_SYMLINK_MAP.json"])
        regular = {}
        for record in payload["members"]:
            raw = record["path"]
            if not raw.startswith("uv-cache/") or raw.startswith("uv-cache/uv-cache/"):
                raise CacheError(f"payload path prefix mismatch: {raw}")
            relative = raw.removeprefix("uv-cache/")
            _relative(relative)
            if relative in regular:
                raise CacheError(f"duplicate regular manifest path: {relative}")
            regular[relative] = {"size_bytes": record["size_bytes"], "sha256": record["sha256"]}
        links = {}
        for record in link_map["links"]:
            relative, literal = record["path"], record["target"]
            _relative(relative)
            _target_relative(relative, literal)
            if relative in links or relative in regular:
                raise CacheError(f"duplicate or aliased symlink manifest path: {relative}")
            links[relative] = literal
        directories = set()
        for relative in [*regular, *links]:
            parent = PurePosixPath(relative).parent
            while parent.parts:
                directories.add(parent.as_posix())
                parent = parent.parent
        observed = {"regular_files": len(regular), "symlinks": len(links),
                    "directories": len(directories), "special_entries": 0,
                    "total_regular_size_bytes": sum(r["size_bytes"] for r in regular.values())}
        if observed != EXPECTED_COUNTS:
            raise CacheError(f"frozen manifest counts mismatch: {observed}")
        for relative, literal in links.items():
            if _target_relative(relative, literal).as_posix() not in directories:
                raise CacheError(f"symlink target is not a declared directory: {relative}")
        return {"regular": regular, "links": links, "directories": sorted(directories),
                "control_sha256": controls}
    except CacheError:
        raise
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise CacheError(f"public-cache control read failed: {error}") from error


def _exact_set(kind: str, actual: set, expected: set) -> None:
    if actual != expected:
        raise CacheError(f"{kind} path-set mismatch: missing={sorted(expected - actual)[:10]!r}; "
                         f"unexpected={sorted(actual - expected)[:10]!r}")


def verify_cache(package_root: Path, cache_root: Path, *, uv_executable: str,
                 cwd: Path, environment: dict) -> dict:
    """Observe every realized member, then query uv using the supplied CWD/env.

    Inventories contain cache-relative paths. Their SHA-256 values bind UTF-8
    JSON with sorted keys, compact separators, ASCII escaping, and one newline.
    No previous bootstrap or verification receipt contributes to this result.
    """
    expected = read_expected(package_root)
    cache_root, cwd = Path(cache_root), Path(cwd)
    try:
        _real_directory(cache_root)
        _real_directory(cwd)
        if not Path(uv_executable).is_absolute():
            raise CacheError("uv executable must be absolute")
        regular_paths, links, directories = {}, {}, set()
        pending = [cache_root]
        while pending:
            directory = pending.pop()
            _real_directory(directory)
            with os.scandir(directory) as entries:
                for entry in entries:
                    path = Path(entry.path)
                    relative = path.relative_to(cache_root).as_posix()
                    metadata = entry.stat(follow_symlinks=False)
                    if stat.S_ISLNK(metadata.st_mode):
                        links[relative] = os.readlink(path)
                    elif stat.S_ISDIR(metadata.st_mode):
                        directories.add(relative)
                        pending.append(path)
                    elif stat.S_ISREG(metadata.st_mode):
                        regular_paths[relative] = path
                    else:
                        raise CacheError(f"special cache entry: {relative}")
        _exact_set("regular", set(regular_paths), set(expected["regular"]))
        _exact_set("symlink", set(links), set(expected["links"]))
        _exact_set("directory", directories, set(expected["directories"]))
        regular_inventory = []
        for relative in sorted(regular_paths):
            identity = _regular_identity(regular_paths[relative])
            if identity != expected["regular"][relative]:
                raise CacheError(f"regular member identity mismatch: {relative}; observed={identity}")
            regular_inventory.append({"path": relative, **identity})
        link_inventory = []
        for relative, literal in sorted(links.items()):
            if literal != expected["links"][relative]:
                raise CacheError(f"symlink literal target mismatch: {relative}; observed={literal!r}")
            target = _target_relative(relative, literal)
            _real_directory((cache_root / relative).parent)
            _real_directory(cache_root.joinpath(*target.parts))
            link_inventory.append({"path": relative, "target": literal})
        directory_inventory = sorted(directories)
        counts = {"regular_files": len(regular_inventory), "symlinks": len(link_inventory),
                  "directories": len(directories), "special_entries": 0,
                  "total_regular_size_bytes": sum(r["size_bytes"] for r in regular_inventory)}
        if counts != EXPECTED_COUNTS:
            raise CacheError(f"observed cache counts mismatch: {counts}")
        result = subprocess.run([uv_executable, "cache", "dir"], cwd=cwd,
                                env=dict(environment), stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, timeout=30, check=False)
        reported = result.stdout.strip()
        if result.returncode != 0 or reported != str(cache_root):
            raise CacheError(f"uv cache dir mismatch: exit={result.returncode}; "
                             f"stdout={reported!r}; stderr={result.stderr!r}")
        return {"status": "PASS", "cache_root": str(cache_root),
                "control_sha256": expected["control_sha256"], "observed": counts,
                "regular_inventory": regular_inventory, "link_inventory": link_inventory,
                "directory_inventory": directory_inventory,
                "regular_inventory_sha256": _inventory_hash(regular_inventory),
                "link_inventory_sha256": _inventory_hash(link_inventory),
                "directory_inventory_sha256": _inventory_hash(directory_inventory),
                "uv_cache_dir": {"command": [uv_executable, "cache", "dir"],
                                 "cwd": str(cwd), "environment": dict(environment),
                                 "exit": result.returncode, "stdout": result.stdout,
                                 "stderr": result.stderr},
                "path_sets": "EXACT", "regular_member_identities": "EXACT",
                "literal_symlink_targets": "EXACT", "ancestor_topology": "REAL_DIRECTORIES",
                "authority": "NONE"}
    except CacheError:
        raise
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        raise CacheError(f"public-cache filesystem verification failed: {error}") from error
