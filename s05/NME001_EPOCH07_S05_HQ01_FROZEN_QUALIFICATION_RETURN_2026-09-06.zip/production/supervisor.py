"""Descriptor-generalized copy of the exact S02 out-of-process supervisor.

Donor: s02_supervisor.py, 7,295 bytes, SHA-256
50998a204336c71d79303f83ad9c71a6a2bc79807c28447df554a151eb78d038.
The caller owns readiness, the exclusive durable commit, and stop records.
"""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import threading
import time
from typing import IO, Mapping, Sequence


class S02SupervisorError(RuntimeError):
    """The bounded launcher or heartbeat record failed."""


DURABLE_PROBE_SCHEMA = "NME001_HARNESS_DURABLE_PROBE_V1"


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def verify_durable_probe(
    probe_path: str | Path,
    probe_readback_path: str | Path,
    *,
    execution_identity: str,
    run_identity: str | None,
    execution_class: str,
    checkpoint_sha256: str,
) -> str:
    """Require byte-identical external readback before a child can launch."""

    if len(checkpoint_sha256) != 64 or any(
        character not in "0123456789abcdef" for character in checkpoint_sha256
    ):
        raise S02SupervisorError("checkpoint SHA-256 is invalid")
    probe = Path(probe_path).resolve()
    readback = Path(probe_readback_path).resolve()
    if probe == readback:
        raise S02SupervisorError("durable probe requires an independent readback path")
    try:
        original = probe.read_bytes()
        returned = readback.read_bytes()
    except OSError as exc:
        raise S02SupervisorError("durable probe or readback is unavailable") from exc
    if not original or original != returned:
        raise S02SupervisorError("durable probe readback bytes differ")
    try:
        payload = json.loads(returned)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise S02SupervisorError("durable probe is not valid JSON") from exc
    if not isinstance(payload, dict) or set(payload) != {
        "schema_version",
        "execution_identity",
        "run_identity",
        "execution_class",
        "checkpoint_sha256",
        "durable_target",
        "purpose",
        "licensed_inputs_opened",
    }:
        raise S02SupervisorError("durable probe schema fields mismatch")
    if (
        payload["schema_version"] != DURABLE_PROBE_SCHEMA
        or payload["execution_identity"] != execution_identity
        or payload["run_identity"] != run_identity
        or payload["execution_class"] != execution_class
        or payload["checkpoint_sha256"] != checkpoint_sha256
        or payload["durable_target"] != "CHATGPT_LIBRARY"
        or payload["purpose"] != "PRE_EXECUTION_DURABILITY_PROBE"
        or payload["licensed_inputs_opened"] is not False
    ):
        raise S02SupervisorError("durable probe identity or state mismatch")
    return _sha256_bytes(returned)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_record(stream: IO[str], record: dict[str, object]) -> None:
    stream.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
    stream.flush()
    os.fsync(stream.fileno())


def _append_heartbeat(
    stream: IO[str],
    *,
    execution_identity: str,
    run_identity: str | None,
    execution_class: str,
    stage: str,
    status: str,
    child_pid: int,
    elapsed_seconds: float,
    exit_code: int | None = None,
) -> None:
    record: dict[str, object] = {
        "schema_version": "NME001_HARNESS_HEARTBEAT_V1",
        "execution_identity": execution_identity,
        "run_identity": run_identity,
        "execution_class": execution_class,
        "stage": stage,
        "status": status,
        "child_pid": child_pid,
        "elapsed_seconds": round(elapsed_seconds, 3),
        "observed_utc": _utc_now(),
    }
    if exit_code is not None:
        record["exit_code"] = exit_code
    _append_record(stream, record)


def _require_real_directory(path: Path) -> None:
    try:
        metadata = path.lstat()
    except OSError as exc:
        raise S02SupervisorError(f"required directory is unavailable: {path}") from exc
    if not stat.S_ISDIR(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
        raise S02SupervisorError(f"required path is not a real directory: {path}")


def supervise(
    command: Sequence[str],
    *,
    execution_identity: str,
    run_identity: str | None,
    execution_class: str,
    heartbeat_path: str | Path,
    log_path: str | Path,
    stdout_path: str | Path,
    stderr_path: str | Path,
    stage: str,
    stage_status_path: str | Path,
    durable_probe_path: str | Path,
    durable_probe_readback_path: str | Path,
    checkpoint_sha256: str,
    cwd: str | Path,
    environment: Mapping[str, str],
    interval_seconds: float = 30.0,
) -> dict[str, object]:
    """Launch one explicitly bound child with fsynced observable status.

    Popen failure raises without emitting STARTED or inventing a PID. The
    caller retains ownership of the already durable commit and truthful stop.
    """

    if (
        isinstance(command, (str, bytes))
        or not command
        or any(not isinstance(value, str) or not value for value in command)
    ):
        raise S02SupervisorError("supervised command is empty or invalid")
    if not execution_identity or any(character.isspace() for character in execution_identity):
        raise S02SupervisorError("execution identity is empty or contains whitespace")
    if not execution_class or any(character.isspace() for character in execution_class):
        raise S02SupervisorError("execution class is empty or contains whitespace")
    if execution_class == "QUALIFICATION":
        if run_identity is not None:
            raise S02SupervisorError("qualification run identity must be null")
    elif not run_identity or any(character.isspace() for character in run_identity):
        raise S02SupervisorError("run identity is empty or contains whitespace")
    if not stage or any(character.isspace() for character in stage):
        raise S02SupervisorError("stage is empty or contains whitespace")
    if interval_seconds <= 0 or interval_seconds > 300:
        raise S02SupervisorError("heartbeat interval must be in (0, 300] seconds")
    if any(not isinstance(key, str) or not isinstance(value, str)
           for key, value in environment.items()):
        raise S02SupervisorError("child environment is invalid")

    verify_durable_probe(
        durable_probe_path,
        durable_probe_readback_path,
        execution_identity=execution_identity,
        run_identity=run_identity,
        execution_class=execution_class,
        checkpoint_sha256=checkpoint_sha256,
    )

    heartbeat, log, stdout, stderr, stage_status = [
        Path(value) for value in (
            heartbeat_path, log_path, stdout_path, stderr_path, stage_status_path
        )
    ]
    targets = (heartbeat, log, stdout, stderr, stage_status)
    if any(not target.is_absolute() for target in targets):
        raise S02SupervisorError("supervisor output paths must be absolute")
    if len({target.resolve() for target in targets}) != len(targets):
        raise S02SupervisorError("supervisor output paths must differ")
    for target in targets:
        _require_real_directory(target.parent)
        if target.is_symlink() or (target.exists() and not stat.S_ISREG(target.lstat().st_mode)):
            raise S02SupervisorError(f"supervisor output is not a regular file target: {target}")
    working_directory = Path(cwd)
    if not working_directory.is_absolute():
        raise S02SupervisorError("child working directory must be absolute")
    _require_real_directory(working_directory)

    started = time.monotonic()
    with log.open("ab", buffering=0) as log_stream, heartbeat.open(
        "a", encoding="utf-8", newline="\n"
    ) as heartbeat_stream, stdout.open("xb", buffering=0) as stdout_stream, stderr.open(
        "xb", buffering=0
    ) as stderr_stream, stage_status.open("a", encoding="utf-8", newline="\n") as stage_stream:
        try:
            process = subprocess.Popen(
                list(command),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                shell=False,
                cwd=working_directory,
                env=dict(environment),
            )
        except OSError as exc:
            raise S02SupervisorError("unable to launch supervised process") from exc

        started_utc = _utc_now()
        identity: dict[str, object] = {
            "schema_version": "NME001_HARNESS_STAGE_STATUS_V1",
            "execution_identity": execution_identity,
            "run_identity": run_identity,
            "execution_class": execution_class,
            "stage": stage,
            "child_pid": process.pid,
        }
        _append_record(stage_stream, {
            **identity, "status": "STARTED", "observed_utc": started_utc,
            "command": list(command), "cwd": str(working_directory),
            "stdout_path": str(stdout), "stderr_path": str(stderr),
        })
        _append_heartbeat(
            heartbeat_stream,
            execution_identity=execution_identity,
            run_identity=run_identity,
            execution_class=execution_class,
            stage=stage,
            status="STARTED",
            child_pid=process.pid,
            elapsed_seconds=0.0,
        )

        log_lock = threading.Lock()
        reader_errors: list[BaseException] = []

        def copy_output(pipe: IO[bytes], stream: IO[bytes]) -> None:
            try:
                for chunk in iter(lambda: pipe.read(65536), b""):
                    stream.write(chunk)
                    with log_lock:
                        log_stream.write(chunk)
                stream.flush()
                os.fsync(stream.fileno())
            except BaseException as exc:
                reader_errors.append(exc)
                # A failed observation must not leave a child blocked on its pipe.
                process.terminate()
            finally:
                pipe.close()

        assert process.stdout is not None and process.stderr is not None
        readers = [
            threading.Thread(target=copy_output, args=(process.stdout, stdout_stream)),
            threading.Thread(target=copy_output, args=(process.stderr, stderr_stream)),
        ]
        for reader in readers:
            reader.start()
        while True:
            try:
                exit_code = process.wait(timeout=interval_seconds)
            except subprocess.TimeoutExpired:
                _append_heartbeat(
                    heartbeat_stream,
                    execution_identity=execution_identity,
                    run_identity=run_identity,
                    execution_class=execution_class,
                    stage=stage,
                    status="RUNNING",
                    child_pid=process.pid,
                    elapsed_seconds=time.monotonic() - started,
                )
                continue
            exited_utc = _utc_now()
            elapsed_seconds = time.monotonic() - started
            _append_heartbeat(
                heartbeat_stream,
                execution_identity=execution_identity,
                run_identity=run_identity,
                execution_class=execution_class,
                stage=stage,
                status="EXITED",
                child_pid=process.pid,
                elapsed_seconds=elapsed_seconds,
                exit_code=exit_code,
            )
            for reader in readers:
                reader.join()
            os.fsync(log_stream.fileno())
            _append_record(stage_stream, {
                **identity, "status": "EXITED", "observed_utc": exited_utc,
                "elapsed_seconds": round(elapsed_seconds, 3), "exit_code": exit_code,
                "output_capture_status": "FAIL" if reader_errors else "PASS",
            })
            if reader_errors:
                raise S02SupervisorError("unable to preserve supervised output") from reader_errors[0]
            return {
                "exit_code": exit_code,
                "pid": process.pid,
                "started_utc": started_utc,
                "exited_utc": exited_utc,
                "elapsed_seconds": round(elapsed_seconds, 3),
            }
