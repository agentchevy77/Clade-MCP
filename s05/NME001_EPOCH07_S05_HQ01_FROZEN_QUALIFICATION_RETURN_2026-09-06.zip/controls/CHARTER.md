# NME-001 Origin — S04 RUN01 Stop Acceptance and S05 Harness Qualification Charter

**Identity:** `NME001-ORIGIN-EPOCH07-S04-RUN01-STOP-ACCEPTANCE-AND-S05-HARNESS-QUALIFICATION-CHARTER-01`  
**Issued:** `2026-09-06T05:41:39Z`  
**Status:** `AUTHORITATIVE_S04_DISPOSITION / ACTIVE_S05_HARNESS_QUALIFICATION_ORDER`  
**Disposition:** `S04_RUN01_CONSUMED_INCOMPLETE_NOT_EVIDENCE / LEASE04_CLOSED / ACCEPTED_S04_SOURCE_CHECKPOINT_UNCHANGED / S05_HARNESS_QUALIFICATION_AUTHORIZED / NO_S05_RUN_RESERVED / S05_HQ01_WRITER_LEASE01_AUTHORIZED / EXTERNAL_QA_REQUIRED_ONLY_AFTER_QUALIFIED_RETURN_AND_BEFORE_ANY_REAL_RUN`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`  
**Authority basis:** Origin's standing bounded Nexus autonomy under the Product Owner's anti-ceremony direction. Product Owner approval is not requested. One implementation-level QA gate is adopted after four harness-origin stops; QA remains advisory and does not control execution.

## 1. S04 disposition

Origin accepts the exact Developer stop without reinterpretation:

- Stop record: `NME001_EPOCH07_S04_RUN01_LEASE04_DEFINED_STOP.json`
- Library: `libfile_044afdb8b90881918314a52f32206a36`
- Backing file: `file_00000000fbb081f5948f07b5fcdcdce0`
- Version: `0`
- Size: `8,913 bytes`
- SHA-256: `b7e127fe23f3a42b5552d9f0572f86a4a167ffe95af2b028825085afd23660be`
- Exact state: `RUN01_LAUNCHED_ONCE / ATTEMPT_CONSUMED / RUN01_INCOMPLETE_NOT_EVIDENCE`

`NME001-E07-S04-WRITER-LEASE-04` is closed permanently. `NME001-SEO01-EPOCH07-S04-RUN01` must not be relaunched, retried, or relabeled. No S04 RUN02 is authorized or reserved.

The following facts remain distinct and binding:

- outer launcher invocation: `1`;
- supervisor child invocation: `1`;
- S04 attempt: `CONSUMED` under the then-controlling handoff rule;
- environment recheck: `PASS`;
- locked offline synchronization: `PASS`;
- hermetic collection process: `NOT_SPAWNED`;
- Nexus test bytes: `NOT_EXECUTED`;
- protected inputs: `NOT_MATERIALIZED / NOT_OPENED`;
- scientific episode: `NOT_STARTED`;
- historical-final payload and outcomes: `CLOSED / NOT_ACCESSED`;
- evidence authority: `NONE`.

S04 is therefore a consumed engineering execution attempt with no test or scientific evidence. This classification is not changed retrospectively merely because the failure preceded pytest.

## 2. Exact cause finding

The immediate failure was not a relative-path or working-directory side effect.

The frozen sequence attempted shell redirection to the absolute path:

`/workspace/scratch/8ee21c4e3e47/NME001_EPOCH07_S04_RUN01_LEASE04/s04_run01_runtime/evidence/s04_hermetic_collection.txt`

Its absolute parent:

`/workspace/scratch/8ee21c4e3e47/NME001_EPOCH07_S04_RUN01_LEASE04/s04_run01_runtime/evidence`

did not exist. Shell redirection failed before the pytest collection child could be created.

The root map declared runtime, observability, and output roots but omitted the actual evidence write-root. Neither the outer launcher nor `s04_sequence.sh` created it. Static review and durability checks nevertheless reported launch readiness. The control defect was therefore:

`INCOMPLETE_REALIZED_WRITE_SET / INTENDED_COMPONENTS_CERTIFIED_WITHOUT_FULL_OUTPUT_REACHABILITY`

QA's broader pattern finding is accepted: lease-rebuilt harness code has become the dominant failure source. Its provisional claim that the Lease-04 CWD correction moved a relative evidence path is rejected by the exact bytes.

## 3. Preserved source input

The accepted project-source checkpoint remains unchanged and may be explicitly adopted later as the sole S05 project-source input:

- `NME001_SEO01_RECOVERY_EPOCH07_S04_PROSPECTIVE_SOURCE_CHECKPOINT.zip`
- Library: `libfile_ac30da9757808191abde59ff75dceff6`
- Version: `0`
- Size: `4,001,839 bytes`
- SHA-256: `74ca21c1dab80fb3fb1a8fd87211127495c7e60c0fde13448e7bcb42affb0104`
- Manifest SHA-256: `1f59b080407ee65cd622c6175fd5f3a26861251361b3a2ed3c463b70cf56f5cc`
- Source tree: `d700092b3c414e8ccfb3dfb7bc076ed7a8ea1359be38b2ebba728b0e3d5893fa`
- Accounting: `171 manifest-bound + 1 self-excluded manifest`
- Dependency projection: `13+1 / 14 EXACT` / SHA-256 `878bc4fac6824920d427f1c9b5f862949604896365ba752f143c2aedd87822f5`
- Hermetic inventory: `981` / `46dde6a20b29221f6961bd8ff02254950080d58ffb3f517a98c8c25cab6e626e`
- Licensed-inclusive inventory: `1,042` / `137203ed6b1267349e37898f1deed5a2844429eebea1be3cb8b4eb4e74428464`

No new project-source checkpoint, scientific change, test change, or refreeze is authorized by this charter.

## 4. Strategic correction

Origin selects a separate bounded qualification stage before any successor run is reserved:

```yaml
segment: NME001-SEO01-RECOVERY-EPOCH07-S05
qualification: EPOCH07-S05-HQ01
classification: NONSCIENTIFIC_ENGINEERING_QUALIFICATION
run_identity: NOT_RESERVED
run_attempt: NOT_CREATED
writer_lease: NME001-E07-S05-HQ01-WRITER-LEASE-01 / AUTHORIZED_NOT_YET_CLAIMED
protected_inputs: PROHIBITED
project_tests: PROHIBITED
scientific_execution: PROHIBITED
historical_final: CLOSED
authority: NONE
```

S05-HQ01 has one purpose: build, exercise, and freeze one reusable external launch harness before a Nexus run number is assigned. It is not a new research workstream, scientific test, permanent governance layer, or excuse to redesign NME-001.

Analogy: the S04 rocket remains intact, but its launch tower omitted a doorway used by the first instrument cable. We will load-test one reusable launch tower with dummy equipment before placing another rocket on it.

## 5. Qualification target

The target is exactly:

1. one hash-bound reusable production harness bundle;
2. one declarative run-descriptor schema and one fully resolved example descriptor;
3. one qualification-only driver;
4. one tiny deterministic synthetic pytest mini-project containing one trivial test; and
5. one case ledger; and
6. one compact qualification return package containing the fully resolved per-case descriptors.

The controlling exact diagnostic donor is:

- `NME001_EPOCH07_S04_LEASE04_EXACT_HARNESS_DONOR_BUNDLE.zip`
- Library: `libfile_eb966d6710688191a9f8489762a9ac2e`
- Backing file: `file_00000000c03c81f5bc65cfea2c8cc5e4`
- Version: `1`
- Size: `67,162 bytes`
- SHA-256: `ac85751e5904607e9b2c82b59e9dd835cb0e44cb5978f5d9a8a2e7a03f390e9c`
- Members: `15`, deterministic ZIP integrity and durable readback `PASS`.

The donor includes the exact ten harness members plus this binding material:

- prelaunch capsule: `libfile_9da5f59a954881919da6183445eca451`, v0, 12,967 bytes, SHA-256 `78396a855a79f7576f0202b605b6a78f8d30f562aa728183f2a0d9a09446187b`;
- component manifest: `libfile_9795876c55508191aed211c978a3f50a`, v0, 8,317 bytes, SHA-256 `226458f2d8539b238dc3ac3ed1b5364e3a6a71e4b62ff87fdb155ef94b615799`; and
- external-harness diff: `libfile_4a06fa03c6348191a7cd2ce5a744857f`, v0, 86,293 bytes, SHA-256 `5fcb15dfd8e796211e75d448481554680e175801ed52cfc6f2d9a914757a3e77`.

The manifest's exact ten member names, sizes, and hashes control inside that bundle. The bundle additionally contains the exact supervisor invoked by the donor launcher: checkpoint member `src/nexus_nme001/s02_supervisor.py`, 7,295 bytes, SHA-256 `50998a204336c71d79303f83ad9c71a6a2bc79807c28447df554a151eb78d038`. The bundle is the required retrieval route; do not repeat individual-file Library archaeology unless its exact bytes are unavailable. Prior PASS records do not transfer. S04 mutable runtime, cache realization, `.venv`, receipts, and outputs must not be reused.

The public offline dependency source is the preserved cache archive `libfile_7e5b770cc5708191a05b044ebdecf534`, SHA-256 `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`. Use the frozen bootstrap and verify the accepted `8,928 regular files + 31 safe relative symlinks + 481,715,990 regular bytes` realization. The synthetic mini-project may declare only the exact pytest/runtime dependencies already present in that cache; network access and new dependency acquisition are forbidden.

The production bundle must include a generalized copy of that exact supervisor; qualifying a substitute supervisor is forbidden. Root/descriptor generalization of the supervisor is authorized, but its heartbeat, logging, durable-probe, subprocess, and fail-closed semantics may not be weakened. Each qualification case has a non-run `execution_identity`, while `run_identity` remains null; the same generalized supervisor bytes must later accept a real-run descriptor. The rest of the production harness must also be root-parameterized. Lease/run-specific absolute values belong in the descriptor; changing a schema-valid descriptor value must not require editing production harness code. Any later production-harness byte change invalidates qualification. Offline synchronization must bind `UV_PROJECT_ENVIRONMENT` to the descriptor's exact `V` path so no runtime environment is written into `Q`.

## 6. Exact operational root and write-set contract

The descriptor schema must declare exactly these root keys:

| Key | Meaning |
| --- | --- |
| `B` | qualification or run parent |
| `Q` | synthetic mini-project during HQ; accepted checkpoint only under a later real-run order |
| `T` | control and production-harness tree |
| `P` | public offline cache / XDG cache root |
| `R` | runtime root |
| `V` | runtime virtual environment |
| `E` | evidence: collection output, JUnit, and checks |
| `L` | heartbeat, stage status, and supervisor log |
| `O` | scientific/build/package output |
| `D` | diagnostic and stop-record staging |
| `TMP` | temporary-file root |
| `MPL` | Matplotlib cache root |
| `S` | protected staging; absent during qualification |
| `C` | protected custody; absent during qualification |

`B` must be absolute. `Q`, `T`, `P`, `R`, `S`, and `C` must be pairwise-distinct direct children of `B`. `V=R/.venv`; `E`, `L`, `O`, `D`, `TMP`, and `MPL` must be pairwise-distinct children of `R` and distinct from `V`. Every path other than `B` must be a strict descendant of `B`. `S` and `C` remain absent throughout qualification. No additional root key or topology is allowed without Origin authority.

The descriptor must also enumerate every exact file or directory the run can write, assign each target its owning stage, and state its required boundary condition, such as `EXISTS_WRITABLE_EMPTY`, `EXISTS_READ_ONLY`, or `RESERVED_ABSENT_UNTIL_GATE`. In particular, `P=RESERVED_ABSENT_UNTIL_CACHE_BOOTSTRAP` and `V=RESERVED_ABSENT_UNTIL_UV_SYNC`; their declared parents are probed first, and `P`/`V` are observed and verified only after their owning construction stages. Only `E`, `L`, `O`, `D`, `TMP`, and `MPL` are constructed and write-probed before qualification commit. The launcher, readiness logic, and receipts must consume that same write-set manifest rather than maintain copied path lists. A write target absent from the manifest cannot be certified; a manifest entry not observed at its required boundary cannot receive `PASS`.

Before any real attempt can later be committed, the production harness must:

1. create every precommit writable parent it owns;
2. observe each with `lstat` after construction;
3. prove type, containment, and required separation;
4. for every writable directory root, perform create/write/flush/file-fsync/rename/parent-fsync/read/delete using a unique probe file inside that directory; for a writable file target, probe its declared parent without creating or renaming the reserved target itself; probe the declared parents of `P` and `V` before their construction stages, then remove every probe and verify absence before authoritative content is produced;
5. record absolute stdout, stderr, JUnit, heartbeat, log, stage-status, scientific-output, package, and stop-record targets;
6. prove the `V` parent writable before offline synchronization; and
7. reject any target that disagrees with its stage-specific declared state, including a target missing after its owning construction stage, a prematurely created protected path, a non-directory, an outside-root path, a forbidden alias, or an unwritable target.

Receipts must report observed realized state. A receipt produced from intended construction without post-construction observation is invalid.

The protected roots `S` and `C` and any protected readiness marker remain absent throughout S05-HQ01.

## 7. Fixed qualification matrix

The exact same candidate production-harness and generalized-supervisor bytes must be used in every case. Qualification-only controls must never enter the production bundle. Every descriptor must set `execution_class=QUALIFICATION`, a unique non-run `execution_identity`, and `run_identity=null`. Any case that reaches the commit boundary must create one immutable `QUALIFICATION_CASE_COMMIT`; `QP-01`, `QP-02`, `QN-05`, and `QN-06` require commit count `1`, while `QN-01` through `QN-04` must stop before commit with commit count `0`. No case may create `RUN_ATTEMPT_COMMIT`. The qualification commit has zero run or scientific authority but must exercise the same exclusive-create, file-and-parent-fsync, exact-readback, and replay-rejection mechanics required of a future run commit. Any non-null run identity or `RUN_ATTEMPT_COMMIT` during HQ is a defined stop.

| Case | Controlled condition | Required result |
| --- | --- | --- |
| `QP-01` | fresh disposable root A | full prelaunch; collect exactly one synthetic test; execute it successfully; write valid JUnit and all expected artifacts |
| `QP-02` | fresh disposable root B with a different absolute prefix | same production-harness bytes and equivalent descriptor values pass; no stale-root binding |
| `QN-01` | `E` pre-created as a regular file | readiness rejects before synthetic child spawn |
| `QN-02` | wrong child working directory | inherited CWD gate stops at its named boundary before synthetic collection |
| `QN-03` | one required grandchild environment value deliberately stripped | inherited environment gate stops at its named boundary before synthetic collection |
| `QN-04` | one required public-cache symlink absent after controlled realization | exact cache gate stops at its named boundary before synthetic collection |
| `QN-05` | synthetic pytest child deliberately exits nonzero | supervisor records PID, stage, exit, stdout/stderr, heartbeat/log, and truthful stop; no later stage starts |
| `QN-06` | injected failure after durable qualification commit and before child spawn, followed by re-entry | re-entry rejects before spawn; commit count remains `1`; child-spawn count remains `0` |

Both positive cases must begin with `E` absent and constructible. The positive path must run the complete production prelaunch chain, collect exactly one synthetic test, execute that test, and emit its valid JUnit through the production launcher/supervisor path. It must deterministically emit stdout, stderr, heartbeat, stage-status, and supervisor log to the descriptor's absolute targets. It must exercise the frozen public-cache bootstrap and locked offline synchronization using only nonprotected inputs. It must stop immediately after the synthetic test/JUnit proof and must not import, collect, or execute Nexus tests or inspect licensed fixtures, Kibot bytes, market rows, acceptance member contents, or historical-final payload/outcomes.

The synthetic mini-project must contain immutable qualification-only `pyproject.toml`, lockfile, and single-test bytes. Before candidate freeze, bind their sizes, SHA-256 values, exact dependency projection, and exact offline sync/pytest commands in the case ledger. They must not modify, import, or claim membership in the accepted Nexus checkpoint.

Every case must have one exact expected/forbidden artifact manifest. A successful case emits the exact success receipt and no stop record. A failing case emits one truthful stop record and no success receipt.

Every fault injection must operate only on its own fresh disposable qualification realization. It must not modify the canonical offline-cache archive, the donor bundle, another case root, or any preserved artifact.

All perturbations must be imposed externally by the qualification driver through case descriptors, initial filesystem state, or supplied child commands before invoking the unchanged production entrypoint. Production code may not branch on case identity or contain fault-injection hooks. `QN-05` uses an immutable qualification child/test command that returns nonzero. `QN-06` binds an intentionally nonexistent child executable to cause a genuine postcommit `Popen` failure, then re-enters the same descriptor to prove replay rejection.

Qualification passes only if both positive roots pass, every negative case fails only at its named boundary without advancing further, all returned bytes are independently readable and hash-bound, and protected roots remain absent.

## 8. Qualification autonomy and anti-sprawl limits

After exact readback of this charter and quiescence verification, Developer may claim `NME001-E07-S05-HQ01-WRITER-LEASE-01` and work autonomously inside S05-HQ01 under these limits:

- maximum two repair-and-refreeze cycles before final qualification return;
- exactly two positive and six negative cases; no case may be added without a demonstrated uncovered failure and new Origin authority;
- one production harness bundle, one descriptor schema, one qualification driver, one synthetic one-test mini-project, one case ledger, and one compact return package;
- no new scientific, custody, exclusion, data, model, metric, gate, or authority semantics;
- no change to the accepted Nexus project source, tests, dependencies, lockfile, checkpoint, inventories, or protected-input contract; the immutable qualification-only dependency fixture expressly authorized by section 7 is excluded from this prohibition;
- no per-case Library artifact spray; intermediate state belongs in one rolling WIP identity, replaced in place;
- no QA-of-QA or recursive reviewer loop;
- a third failed qualification cycle, a scope increase, provenance ambiguity, loss of durable WIP, or any protected-data contact requires a defined stop.

Only work necessary to make the donor root-rebindable, derive readiness from the complete realized write set, exercise the known harness-control class, and implement the prospective commit semantics may be added. Unrelated hypothetical hardening is forbidden.

## 9. Prospective attempt semantics

S04's attempt classification is unchanged. Any future S05 execution order must use these prospective terms:

- `ORCHESTRATION_INVOCATION`: outer launcher or supervisor plumbing; not itself a scientific run attempt.
- `RUN_ATTEMPT_COMMIT`: one immutable record created exclusively under the single-writer launch lock, with file and parent directory fsynced, exact independent readback, and rejection of any pre-existing commit; it binds the run identity, checkpoint, harness, descriptor, command, normalized environment, inventories, and passed readiness state.
- `RUN_ATTEMPT_CONSUMED`: true immediately when the unique commit is durably read back, before the first real hermetic pytest spawn attempt.
- `HERMETIC_COLLECTION_PROCESS_STARTED`: separately recorded only after successful OS child creation with PID and start time.
- `PROTECTED_INPUTS_OPENED`: separately recorded at the custody boundary.
- `SCIENTIFIC_EPISODE_STARTED`: separately recorded immediately before the scientific child or first authorized Kibot-prefix access.

After `RUN_ATTEMPT_COMMIT`, exactly one OS spawn attempt of the bound hermetic collection child is permitted; any crash, ambiguity, spawn failure, or child failure after commit remains consumed. A child spawn without a prior valid commit is `INVALID_PROVENANCE / ATTEMPT_CONSUMED`. Only exact proof of commit count `0`, real-project child-spawn count `0`, protected-access count `0`, and scientific-episode count `0` permits an unconsumed engineering stop.

The commit must occur only after every deterministic plumbing and write-target check passes. It must not wait for a child-written collection marker, which could create an ambiguity window.

## 10. QA role and real-run gate

Developer qualification work is authorized now. QA is an advisory scout; Origin retains command. One bounded external review occurs only after Developer freezes the qualified-harness return and before any real S05 run is reserved.

QA must classify its findings as:

- `MATERIAL_BLOCKER`;
- `NONBLOCKING_IMPROVEMENT`; or
- `CLEAR_TO_PROCEED`.

That review should answer only:

1. Do the frozen harness and return preserve the exact S04 stop and accepted checkpoint state?
2. Did the same production-harness bytes pass the fixed synthetic qualification matrix without Nexus-test or protected-data contact?
3. Does the realized write-set receipt derive from and observe every descriptor entry at the correct stage?
4. Are the attempt-commit boundary and returned provenance coherent and non-gameable?

QA suggestions are not adopted automatically. Nonblocking improvements do not expand the fixed matrix or gate surface. Origin will adjudicate once and, if the frozen harness is acceptable, issue a separate S05 RUN01 order. If QA materially shaped the harness, that fact must be disclosed; final scientific review should remain role-separated where practical.

## 11. Current prohibitions

Under this charter Developer may perform only S05-HQ01. Developer must not:

- claim any lease other than `NME001-E07-S05-HQ01-WRITER-LEASE-01`;
- create any root outside the fresh bounded S05-HQ01 qualification roots;
- reserve or launch S05 RUN01;
- edit, refreeze, import, collect, or run project code/tests;
- materialize or inspect protected inputs;
- open acceptance-package member contents;
- decompress Kibot;
- read market rows or historical-final bytes/outcomes;
- reuse S04 mutable state or prior PASS claims; or
- infer authority for any S05 real run, Nexus project-test execution, protected-input action, or scientific action from this charter.

All formal, scientific, predictive, trading, alerting, broker, automated-action, and operational-release authority remains `NONE`; historical final and operational release remain `HOLD`.

## 12. Required immediate routing

1. Developer reads and verifies this exact charter, the exact S04 stop, and the exact donor bindings.
2. Developer verifies quiescence, claims only the authorized S05-HQ01 lease, and performs the bounded qualification.
3. Developer returns one defined stop or one complete, independently read-back qualification package. No S05 real run may be reserved or launched.
4. Route the complete qualification package to external QA for the single bounded review in section 10.
5. Origin will adjudicate the QA return without requesting another Product Owner approval unless QA identifies a Product-Owner-reserved change.

If a relay message conflicts with this charter, the exact charter bytes control. This charter closes S04 and opens only S05-HQ01 engineering qualification; it does not reserve or authorize S05 RUN01.
