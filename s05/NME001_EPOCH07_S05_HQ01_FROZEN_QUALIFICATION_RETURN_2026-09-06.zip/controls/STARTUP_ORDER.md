# Project Nexus — Internal Developer Startup Order

**Record identity:** `NME001-ORIGIN-INTERNAL-DEVELOPER-STARTUP-AND-HQ01-RESUMPTION-01`  
**Issued:** `2026-09-06T11:00:35Z`  
**Owner:** `ORIGIN`, under current Product Owner direction  
**Disposition:** `ONE_INTERNAL_GPT_DEVELOPER_APPOINTMENT_PREPARED / HQ01_RESUMPTION_AUTHORIZED_SUBJECT_TO_EXISTING_PREFLIGHT / LEASE_AUTHORIZED_UNCLAIMED / OUTSIDE_DEVELOPER_NOT_CREATED / EXTERNAL_QA_RETAINED`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`

## 1. Appointment, scope, and precedence

The Product Owner now requests a fresh Developer chat to continue Project Nexus and explicitly clarifies that it will be a Project-internal GPT chat, with QA external. This order implements that current instruction. It appoints exactly one fresh internal Developer session when the Product Owner gives that session the accompanying startup message. Preparing this order does not assert that the session exists, has acknowledged it, or has claimed a lease.

This order resumes the internal Developer path and supersedes the pending-work implications of `NME001_ORIGIN_OUTSIDE_DEVELOPER_DEFERRAL_AND_QA_CONTINUITY_DISPOSITION_2026-09-06.md` (Library `libfile_652eeeb812348191a77d34a5efb75edf`, v0, SHA-256 `d60f6f03236689ffb128e15c10e1b10c286e3eaeae18e79af38fad60043307b6`) only for this internal appointment. The outside Developer remains uncreated and deferred. No outside coding account, repository, branch, or Git setup is required or authorized by this startup.

The exact S05-HQ01 charter remains the implementation and scientific-scope authority. Its phrase external launch harness means a harness outside the accepted Nexus project-source tree, not a requirement for an outside chat. This order changes actor routing, native custody instructions, and the next action; it changes no qualification case, root topology, source/test boundary, scientific definition, attempt semantic, or future real-run gate. If a message contradicts the exact charter within those boundaries, the charter controls. A later explicit Product Owner decision retains precedence.

The external Developer identity bridge in the continuity packet applies to outside Developer returns and is `NOT_APPLICABLE_TO_INTERNAL_DEVELOPER_GIT_CUSTODY`. Do not import its repository/branch/base-commit prerequisites into this internal workflow. External QA retains its separate role and repository; its repository is not the Developer's workspace.

## 2. Mission and role

Develop the smallest reliable engineering system needed to complete NME-001 while preserving evidence lineage. Nexus's operational mission is a screenshot-free AI Market Desk; its research asks whether behavior near identified price levels is conditionally predictable over explicit horizons, with calibration, uncertainty, invalidation, and abstention. This assignment does not establish trading probabilities or trading authority.

Origin directs and adjudicates. The internal Developer implements and owns its current role memory and recoverable work. QA gives bounded independent advice after the candidate is ready. Steward preserves custody and filing. Market Desk and TradingView Lab retain their separate lanes. Do not take over their work or assign a second Developer writer.

Your immediate assignment is `NME-001 / SEO-01 / RECOVERY-EPOCH-07 / EPOCH07-S05-HQ01`: qualify one reusable production harness against the charter's fixed synthetic cases. Success is a complete frozen, independently read-back qualification return, or one truthful defined stop.

## 3. Read only the needed current records first

Use the Library skill and native project-file tools. Begin at `/Project Nexus/00_START_HERE/`:

- Compass: `NEXUS_PROJECT_COMPASS.md`, `libfile_69058b935a80819180fc0062c1c3f941`.
- Memory protocol: `CONTINUITY/NEXUS_MEMORY_SYSTEM.md`, `libfile_573df6d20a0c819187cc4a12c1261c38`.
- Your current role memory: `CONTINUITY/NEXUS_DEVELOPER_ROLE_MEMORY.md`, `libfile_7f3b9f43b89481918528c64303f4e71b`.
- This exact startup order, then the exact governing charter, stop, and diagnostic donor supplied by the sanitized continuity packet below.

Those memories are navigation. Verify actual control bytes before material work. Do not reconstruct the project from old transcripts or load the entire archive. The old launch cards, retired S04 run orders, and Developer memory through its closed S04 predecessor version are historical. Their stop instructions were disposed of by the later charter; their launch authority cannot be revived.

Origin initializes the same stable Developer memory as `APPOINTED_PENDING_SESSION_PREFLIGHT`; the new Developer takes ownership upon actual activation. Prior versions remain historical. Do not create a second Developer memory or edit the Compass, Origin memory, or other roles' memories.

## 4. Exact permitted input identities

Resolve these exact objects. A filename, metadata result, or download link alone is not byte verification. For a native file that text-read cannot resolve, use current Library list metadata and the Library skill's supported materialization route; do not create a duplicate or infer loss solely from text-read failure.

| Input | Exact identity |
| --- | --- |
| Sanitized continuity packet | `NME001_S05_HQ01_SANITIZED_CONTROL_CONTINUITY_PACKET_2026-09-06.zip`; Library `libfile_bd8461ebb3b48191b734d929f87e3183`; backing `file_00000000d04081f5a5d4245c6073d86e`; v0; 103,630 bytes; SHA-256 `ced7d1a4a7d3bf4cd377c9fdcc826f7b885c4201f08775edde026c7e6915a1d5` |
| Controlling charter, also inside packet | `NME001_ORIGIN_EPOCH07_S04_RUN01_STOP_ACCEPTANCE_AND_S05_HARNESS_QUALIFICATION_CHARTER_2026-09-06.md`; Library `libfile_d578967af7f4819188ba96e36a6486be`; backing `file_00000000740481f59518f7d36a8a16ab`; v1; 23,009 bytes; SHA-256 `fdca00109fe9bb078b745151eaa15b510f1db80f75046a4003732694f1676198` |
| Exact diagnostic donor, also inside packet | `NME001_EPOCH07_S04_LEASE04_EXACT_HARNESS_DONOR_BUNDLE.zip`; Library `libfile_eb966d6710688191a9f8489762a9ac2e`; backing `file_00000000c03c81f5bc65cfea2c8cc5e4`; v1; 67,162 bytes; 15 members; SHA-256 `ac85751e5904607e9b2c82b59e9dd835cb0e44cb5978f5d9a8a2e7a03f390e9c` |
| Exact S04 terminal stop, also inside packet | `NME001_EPOCH07_S04_RUN01_LEASE04_DEFINED_STOP.json`; Library `libfile_044afdb8b90881918314a52f32206a36`; backing `file_00000000fbb081f5948f07b5fcdcdce0`; v0; 8,913 bytes; SHA-256 `b7e127fe23f3a42b5552d9f0572f86a4a167ffe95af2b028825085afd23660be` |
| Separate public offline cache | `NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64.zip`; Library `libfile_7e5b770cc5708191a05b044ebdecf534`; backing `file_00000000113081fba80b1626a518e692`; v0; 148,782,742 bytes; SHA-256 `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7` |

Verify the packet outer hash before opening, all nine entries in `SHA256SUMS.txt`, donor archive integrity, its ten component bindings, and the four charter-stated bindings. The donor includes `s02_supervisor.py`, 7,295 bytes, SHA-256 `50998a204336c71d79303f83ad9c71a6a2bc79807c28447df554a151eb78d038`; generalize that supervisor only as the charter permits.

The public cache is nonprotected and may be materialized through native Library access for size/hash verification before claiming the lease. This is retrieval of an existing frozen dependency, not permission to fetch new packages or use online dependency resolution. Keep the archive separate from source and returns. Do not extract or bootstrap it before exact hash PASS and lease claim. The frozen bootstrap is bundled inside this cache; it is not a missing standalone handoff file. Follow the package controls and exact donor cache-verifier expectations after claim. Required realized cache: 8,928 regular files, 31 safe relative symlinks, and 481,715,990 regular bytes.

Accepted S04 project-source checkpoint is reference-only during HQ01: `libfile_ac30da9757808191abde59ff75dceff6`, v0, 4,001,839 bytes, SHA-256 `74ca21c1dab80fb3fb1a8fd87211127495c7e60c0fde13448e7bcb42affb0104`, inventories 981 / 1,042. Do not materialize, reconstruct, import, collect, execute, edit, or refreeze its contents under this order. All protected inputs are prohibited.

## 5. First-session preflight and sole writer

Start read-only with respect to shared project state and implementation. Local copies for exact verification are allowed. Establish:

1. Current controls and actual session capabilities: project-file read/materialization/write/readback, code execution, required runtime/tool availability and offline dependency compatibility. Record actual versions and paths; do not silently weaken an explicit runtime constraint or carry retired absolute paths forward.
2. Exact control and cache identity PASS in your own session. Origin's earlier verification does not prove your receipt.
3. Single-writer and process quiescence for the assigned execution environment, fresh absent bounded qualification parent, no conflicting current claim or in-flight return. Do not infer quiescence from an old PASS receipt. Report the actual scope observed; do not claim access to another chat's hidden process state.

Report one concise orientation/preflight status: mission, HQ01 objective, control/cache checks, lease and writer state, five documented prior attempts, exposure, native custody, concrete next action, and unknowns. Repository, branch, base commit, and Git return fields are `NOT_APPLICABLE_INTERNAL_LIBRARY_WORKFLOW`.

When all existing prerequisites are satisfied, claim only `NME001-E07-S05-HQ01-WRITER-LEASE-01` using exclusive fresh-root ownership, record the claim and observed quiescence durably with your single HQ01 work product, and update your own role memory with the actual state. Preserve and independently read back the claim/work-product custody before any materially long execution. Do not treat a memory edit as a lock or as a substitute for the durable claim. If ownership is ambiguous, stop the affected action instead of creating another root to evade the conflict.

Then continue autonomously in the same work session. The initial report is not another approval gate. Do not finish merely by proposing the already-authorized work or asking whether to proceed. This appointment does not claim the lease on your behalf, create a run identity, or consume an attempt.

## 6. Engineering behavior and execution boundaries

- Read donor code before executing anything. Never run the retired S04 launcher or sequence unchanged: their commands and paths target the retired S04/Nexus flow. Only the newly generalized production harness may exercise the synthetic fixture.
- Build one production harness, one declarative descriptor schema, one qualification driver, one immutable single-test synthetic pytest mini-project, one case ledger, and one compact return, exactly as charter sections 5-8 require.
- Use the exact root keys, topology, and stage-dependent write-set rules in charter section 6. Derive construction, readiness, observation, and receipts from the same complete write set. An intended directory is not an observed writable directory. Probe actual required parents before output redirection, synchronization, or child creation.
- Keep explicit working directories and normalized inherited environment bindings across parent, child, and grandchild. Bind `UV_PROJECT_ENVIRONMENT` to descriptor `V`; keep runtime/cache/output outside synthetic source `Q`. Observe required cache symlinks and postconstruction state; never reuse old receipts or mutable S04 state.
- Freeze candidate production bytes and the synthetic dependency/test fixture before qualification; use identical production/supervisor bytes in all cases. Root values belong in descriptors. A production-byte change invalidates prior qualification and uses the charter's repair/refreeze allowance.
- Use agents, when available, for concrete bounded reading, inspection, or nonoverlapping implementation tasks. The lead Developer remains the sole owner of lease, root, freeze, and execution decisions. Helpers do not create another lease or replace the prescribed external QA review.
- Keep updates short and evidence-based: what completed, what is running, what blocked, and the latest durable recovery pointer. Follow required heartbeat/observability behavior. A long-running tool call or repeated narration is not a work-product checkpoint.

## 7. Fixed qualification matrix

The exact charter section 7 governs every boundary and artifact requirement. The summary below must not broaden or weaken it.

| Case | Required proof |
| --- | --- |
| QP-01 | Fresh root A; full production prelaunch/cache/offline-sync path; collect exactly one synthetic test, execute it, and emit valid JUnit and all required artifacts |
| QP-02 | Fresh root B with different absolute prefix; same production bytes pass the equivalent descriptor without stale-root binding |
| QN-01 | Evidence root E is a regular file; reject before commit and synthetic child spawn |
| QN-02 | Wrong child CWD; named inherited-CWD gate stops before commit and synthetic collection |
| QN-03 | Required grandchild environment value stripped; named gate stops before commit and synthetic collection |
| QN-04 | One required realized public-cache symlink absent; exact cache gate stops before commit and synthetic collection |
| QN-05 | Synthetic child exits nonzero; supervisor records truthful diagnostics and starts no later stage |
| QN-06 | Failure after durable qualification commit and before child spawn, then re-entry; replay rejected, one commit, zero child spawns |

QP-01, QP-02, QN-05, and QN-06 require one `QUALIFICATION_CASE_COMMIT`; QN-01 through QN-04 require zero. All cases have unique non-run execution identities and null run identity. `RUN_ATTEMPT_COMMIT` is prohibited in HQ01. Use the charter's exclusive-create/fsync/readback/replay semantics without inventing a different commit boundary. Maximum two repair/refreeze cycles; do not add cases, gates, or unrelated hardening.

## 8. Native custody, recovery, and return

Use one new HQ01 rolling WIP Library identity, then replace it in place. Do not overwrite a predecessor S04/S03/S02 WIP or checkpoint. Maintain recoverable source, configuration, descriptors, synthetic fixture, executed-byte manifest, claim/state, case ledger, and necessary receipts within that one work product. Save and independently read back the recoverable candidate before long qualification work. Keep intermediate case output in this WIP, not a spray of separate Library files.

Native records bind their immutable record identity, filename, Library ID, backing-file ID, actual version, size, SHA-256, and relevant member identities. Use native compare-and-replace/version checks. Do not invent identities or convert a saved-byte receipt into a semantic PASS. Repository/commit/tree/Git-bundle fields are inapplicable to this internal custody path; exact source/member and executed-byte manifests remain required for reproducibility.

The complete return must contain the frozen production bundle, schema, qualification driver, immutable synthetic fixture/lockfile, fully resolved per-case descriptors, fixed case ledger, required commands/runtime/environment provenance, observed readiness/write-set receipts, process/commit counts, stdout/stderr/JUnits/supervisor observability, and before/after byte-drift checks. Bind all package members, explicitly self-exclude only the manifest where needed, and bind the outer package separately. Preserve exact bytes and independently read back the sealed return. Scan the return for secrets and prohibited licensed/raw data; permitted protected contact and payload count is zero.

Return one compact status with exact package identity and either complete qualification results or one defined stop. Update your role memory at material transitions, not every heartbeat. Keep it within 8 KB / 100 lines; other roles use its stable pointer rather than copying your changing WIP details.

## 9. Stop conditions and subsequent authority

Use the charter's defined stops: provenance or writer ambiguity, unavailable required exact input, loss of durable WIP, protected-data contact, out-of-scope request, or exhausted repair allowance. Preserve recoverable work and report the exact failed operation, expected versus observed state, last durable identity, process/lease state, qualification commits/spawns, and exposure. Do not relabel a failed case, restart a consumed execution, or loop indefinitely on retries. Routine implementation choices inside the order need no ceremonial reapproval.

S04 RUN01 remains consumed, incomplete, and not evidence; its lease is permanently closed and there is no S04 RUN02. Five consumed attempts are documented across S02-S04 (3+1+1); the earlier S01 ledger is not an independently audited absolute-zero record. HQ01 consumes no real Nexus attempt. No S05 RUN01 is reserved or authorized.

QA's continuity review is complete and advisory; it is not candidate qualification. After your complete frozen qualification return, Origin routes one sanitized package to external QA for the charter's single bounded implementation review and adjudicates once. Developer does not send to QA directly or write in QA's repository. Only a later separate Origin order may reserve a real S05 run. Scientific/formal evidence and predictive/trading/alerting/broker/automation authority remain NONE; historical final and operational release remain HOLD. Existing data and filing holds remain unchanged.
