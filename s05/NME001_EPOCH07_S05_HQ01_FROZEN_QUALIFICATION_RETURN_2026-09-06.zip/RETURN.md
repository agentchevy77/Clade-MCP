# HQ01 frozen qualification return

Record identity: `NME001-E07-S05-HQ01-FROZEN-QUALIFICATION-RETURN-01`  
Disposition: `SYNTHETIC_QUALIFICATION_COMPLETE / F01_8_OF_8_PASS / ORIGIN_EXTERNAL_QA_PENDING`  
Scientific effect: `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`

All eight fixed cases passed against the same F01 production and supervisor
bytes. One repair/refreeze cycle was used; the F00 positive-case failure is
preserved and is not counted as a pass. The synthetic fixture never changed.

| Case | Observed boundary/result | Qualification commits | Successful synthetic child spawns |
|---|---|---:|---:|
| QP-01 | One test collected and passed; valid JUnit | 1 | 2 |
| QP-02 | Same proof at different absolute prefix | 1 | 2 |
| QN-01 | WRITE_SET_READINESS_GATE | 0 | 0 |
| QN-02 | INHERITED_CWD_GATE | 0 | 0 |
| QN-03 | INHERITED_ENVIRONMENT_GATE | 0 | 0 |
| QN-04 | EXACT_PUBLIC_CACHE_GATE | 0 | 0 |
| QN-05 | SUPERVISED_CHILD_EXIT_GATE; exit 23; no later stage | 1 | 1 |
| QN-06 | POSTCOMMIT_CHILD_SPAWN_GATE; replay rejected with exit 73 | 1 | 0 |

Two positive-case spawns mean a collection process and a test process, each
using the same single synthetic test. QN-05 deliberately returns 23 from its
immutable qualification child after collection. QN-06 records one failed OS
spawn attempt, no PID, zero successful spawns, one unchanged commit, and a
separate replay rejection. Its empty supervisor outputs truthfully indicate
that no child was created.

There are four qualification commits and five successful synthetic child
spawns. The final candidate has eight initial orchestrations plus the one
prescribed replay; F00 adds one retired failed orchestration. There are no
real-run commits, reserved real runs, scientific episodes, or protected payload
contacts. S04 RUN01 remains consumed, incomplete, and not evidence. Its source
checkpoint was not materialized, reconstructed, imported, executed, or changed.
Five consumed predecessor attempts remain documented (S02/S03/S04: 3/1/1);
S01 is not treated as an independently audited absolute-zero record.

## Exact engineering bindings

F01 production tree SHA-256:
`bf3c981151f9c58331e13d1412b29dce5abacec2b140772cc15c986aeeefa09d`.

Generalized supervisor SHA-256:
`e218664f92b85e172b9b2b6d9fb327a573dad5f68e7c9c91145c086622d4a16c`.

Immutable fixture tree SHA-256:
`723d254cd55738e0697704bb015470fef4e0969cc2453522d52c139fe27283b7`.

Exact runtime: CPython 3.12.13; uv 0.11.33 (x86_64-unknown-linux-gnu);
Linux x86_64/glibc 2.39. RUNTIME_PROVENANCE.json binds executable paths and
bytes. Every production generation has explicit working directory and
controlled inherited environment; the recorded grandchild perturbation is the
sole deliberately missing required value. Network dependency acquisition was
not used. The five installed packages exactly match the immutable lock.

The separate public archive is 148,782,742 bytes, SHA-256
`c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`.
Fresh bootstrap observations verify 8,928 regular files, 31 safe relative
symlinks, 839 directories, and 481,715,990 regular bytes before sync.
Post-sync cache and virtual-environment receipts bind exact realized paths,
types, and content identities. QN-04 rejects the deliberately absent link.
The cache archive and mutable realizations are excluded from this return.

The descriptor schema fixes all 14 root keys and topology. Its single write set
drives construction, parent probes, output targets, and post-stage observations.
Exact manager-owned member maps declare every allowed cache/venv member; any
undeclared member rejects. Optional named files are recorded absent when not
emitted. Output receipts and independent final observations distinguish reserved
paths from observed files. All positive/negative required artifact sets match
exactly; forbidden artifacts and protected roots remain absent.

The first candidate stopped before commit when uv wrote undeclared interpreter
cache files and a Q-derived temporary lock. Repair 01 declares those exact
targets prospectively. UV_LOCK_DERIVATION.md documents the pinned binary's
project-lock calculation. Interpreter-cache key derivation remains unknown;
the exact declared keys were observed to match at both qualified prefixes.
No stale PASS record was reused, and no failed case root was repaired/replayed.

## Custody and return routing

The candidate was natively saved and independently read back as rolling WIP
v3 before F01 execution. Complete matrix evidence was saved/read back as WIP
v5: `libfile_775f78fce7d48191ae2c25881aa60fa7`, backing
`file_000000009d3081f59b9418632688fd45`, 14,066,292 bytes, SHA-256
`4f0fcf5c6dc1f0eff0efac8e5a7eab869ae0b4122b288630a1445d37b2402a56`.
The custody receipts preserve earlier versions and candidate readback paths.
Every package member is bound in PACKAGE_MANIFEST.json, which alone excludes
itself. Native publication/readback metadata binds the outer ZIP separately in
the Developer's stable memory, rolling WIP, and delivery status.

The lead retained sole lease/freeze/execution ownership. Internal helpers
authored bounded components and checked returned records; they were not external
QA. A separate raw-record packaging check verified all eight frozen descriptors,
all 119 case artifacts, positive JUnits, and negative supervisor/replay records.
No external QA was contacted and no QA repository was used.

Lease-01 is held quiescent awaiting Origin disposition. No active qualification
process was observed in the current execution namespace. Hidden process state
in other chats is not observable. Root reuse is not authorized by this return.
Repository, branch, base commit, and Git bundle fields are
`NOT_APPLICABLE_INTERNAL_LIBRARY_WORKFLOW`.

Origin should route this frozen sanitized return to the charter's single
bounded external QA review and adjudicate. Only a separate Origin order may
reserve a real S05 run. Scientific/formal evidence and predictive, trading,
alerting, broker, and automation authority remain NONE; historical final and
operational release remain HOLD.
