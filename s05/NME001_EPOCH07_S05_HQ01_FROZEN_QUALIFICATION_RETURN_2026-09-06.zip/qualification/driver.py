"""Fixed HQ01 qualification driver; fault controls never enter production."""
from __future__ import annotations
import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import zipfile
from venv_contract import build_venv_contract
from uv_path_contract import uv_project_lock_basename

WORK = Path(__file__).resolve().parents[1]
HQ = WORK.parent
CACHE = HQ.parent / 'inputs/NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64.zip'
CACHE_SHA = 'c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7'
CACHE_PREFIX = 'NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64'
PYTHON = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python'
UV = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/uv'
CASES = ['QP-01', 'QP-02', 'QN-01', 'QN-02', 'QN-03', 'QN-04', 'QN-05', 'QN-06']
BOUNDARIES = {'QP-01': 'SUCCESS', 'QP-02': 'SUCCESS', 'QN-01': 'WRITE_SET_READINESS_GATE',
              'QN-02': 'INHERITED_CWD_GATE', 'QN-03': 'INHERITED_ENVIRONMENT_GATE',
              'QN-04': 'EXACT_PUBLIC_CACHE_GATE', 'QN-05': 'SUPERVISED_CHILD_EXIT_GATE',
              'QN-06': 'POSTCOMMIT_CHILD_SPAWN_GATE'}


def canonical(v):
    return (json.dumps(v, sort_keys=True, separators=(',', ':')) + '\n').encode()


def ident(p):
    b = Path(p).read_bytes()
    return {'size_bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}


def write(p, data):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


def records(root):
    return {str(p.relative_to(root)): ident(p) for p in sorted(root.rglob('*')) if p.is_file()}


def freeze(number):
    if number not in (0, 1, 2):
        raise RuntimeError('repair/refreeze allowance exhausted')
    production = records(WORK / 'production')
    for p in (WORK / 'production').glob('*.py'):
        ast.parse(p.read_text())
    fixture = records(WORK / 'fixture')
    manifest = {'record_identity': f'NME001-E07-S05-HQ01-FROZEN-CANDIDATE-F{number:02d}',
                'freeze_number': number, 'repair_refreeze_cycles': number,
                'production': production, 'production_sha256': hashlib.sha256(canonical(production)).hexdigest(),
                'fixture': fixture, 'fixture_sha256': hashlib.sha256(canonical(fixture)).hexdigest(),
                'qualification': records(WORK / 'qualification'),
                'cache': {'size_bytes': 148782742, 'sha256': CACHE_SHA},
                'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'qualification_status': 'NOT_EXECUTED', 'authority': 'NONE'}
    dest = WORK / 'freezes' / f'F{number:02d}'
    dest.mkdir(parents=True, exist_ok=False)
    write(dest / 'FROZEN_MANIFEST.json', canonical(manifest))
    with zipfile.ZipFile(dest / 'PRODUCTION_HARNESS.zip', 'w', zipfile.ZIP_DEFLATED) as z:
        for name in production:
            zi = zipfile.ZipInfo(name, (2026, 9, 6, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o100444 << 16
            z.writestr(zi, (WORK / 'production' / name).read_bytes())
    plan(number, manifest)
    print(json.dumps({'freeze': number, 'production_sha256': manifest['production_sha256'],
                      'fixture_sha256': manifest['fixture_sha256'], 'cases_planned': CASES}))


def plan(number, frozen):
    fm = json.loads((WORK / 'fixture/fixture_manifest.json').read_text())
    projection = {p['name']: p['version'] for p in fm['dependency_projection']}
    with zipfile.ZipFile(CACHE) as z:
        controls = {Path(n).name: {'bytes': z.read(n)} for n in z.namelist() if len(Path(n).parts) == 2}
        links = json.loads(controls['UV_CACHE_SYMLINK_MAP.json']['bytes'])['links']
        payload = json.loads(controls['CACHE_PAYLOAD_MANIFEST.json']['bytes'])['members']
    cache_members = {'uv': {'kind': 'directory'}, 'NME001_DWO05_UV_CACHE_REALIZATION_RECEIPT.json': {'kind': 'file'}}
    for row in payload:
        relative = 'uv/' + row['path'].removeprefix('uv-cache/')
        cache_members[relative] = {'kind': 'file', 'sha256': row['sha256']}
    for row in links:
        cache_members['uv/' + row['path']] = {'kind': 'symlink'}
    for relative in list(cache_members):
        for parent in Path(relative).parents:
            if str(parent) != '.':
                cache_members[str(parent)] = {'kind': 'directory'}
    venv_contract = build_venv_contract(CACHE, projection)
    artifact_map = {
        'readiness': ('D', 'readiness.json', 'PRECOMMIT'), 'input_before': ('D', 'inputs_before.json', 'PRECOMMIT'),
        'inheritance_stdout': ('D', 'inheritance.stdout', 'INHERITANCE'), 'inheritance_stderr': ('D', 'inheritance.stderr', 'INHERITANCE'),
        'bootstrap_stdout': ('D', 'bootstrap.stdout', 'CACHE_BOOTSTRAP'), 'bootstrap_stderr': ('D', 'bootstrap.stderr', 'CACHE_BOOTSTRAP'),
        'cache_receipt': ('D', 'cache_observation.json', 'CACHE_BOOTSTRAP'),
        'cache_write_receipt': ('D', 'cache_write_observation.json', 'CACHE_BOOTSTRAP'),
        'sync_stdout': ('D', 'sync.stdout', 'UV_SYNC'), 'sync_stderr': ('D', 'sync.stderr', 'UV_SYNC'),
        'venv_receipt': ('D', 'venv_observation.json', 'UV_SYNC'), 'precommit': ('D', 'precommit.json', 'PRECOMMIT_COMPLETE'),
        'cache_post_sync': ('D', 'cache_post_sync.json', 'UV_SYNC'),
        'uv_project_lock': ('TMP', 'RESOLVED_FROM_Q_BEFORE_FREEZE', 'UV_SYNC'),
        'launch_lock': ('D', 'launch.lock', 'COMMIT'), 'qualification_commit': ('D', 'QUALIFICATION_CASE_COMMIT.json', 'COMMIT'),
        'collection_stdout': ('E', 'collection.stdout', 'COLLECTION'), 'collection_stderr': ('E', 'collection.stderr', 'COLLECTION'),
        'collection_check': ('E', 'collection_check.json', 'COLLECTION_CHECK'),
        'test_stdout': ('E', 'pytest.stdout', 'TEST'), 'test_stderr': ('E', 'pytest.stderr', 'TEST'),
        'junit': ('E', 'junit.xml', 'TEST'), 'junit_check': ('E', 'junit_check.json', 'JUNIT_CHECK'),
        'heartbeat': ('L', 'heartbeat.jsonl', 'SUPERVISOR'), 'stage_status': ('L', 'stage_status.jsonl', 'SUPERVISOR'),
        'supervisor_log': ('L', 'supervisor.log', 'SUPERVISOR'), 'input_after': ('D', 'inputs_after.json', 'FINAL_CHECK'),
        'success': ('O', 'SUCCESS.json', 'COMPLETE'), 'stop': ('D', 'STOP.json', 'STOP'),
        'replay_rejection': ('D', 'replay_rejection.json', 'REENTRY'),
        'scientific_output': ('O', 'scientific_output.json', 'REAL_SCIENTIFIC'),
        'package': ('O', 'package.zip', 'REAL_PACKAGE'), 'run_commit': ('D', 'RUN_ATTEMPT_COMMIT.json', 'REAL_COMMIT'),
        'protected_ready': ('L', 'PROTECTED_READY.json', 'PROTECTED_GATE'),
    }
    prelaunch = ['readiness', 'input_before', 'inheritance_stdout', 'inheritance_stderr', 'bootstrap_stdout',
                 'bootstrap_stderr', 'cache_receipt', 'cache_write_receipt', 'sync_stdout', 'sync_stderr',
                 'uv_project_lock', 'venv_receipt', 'cache_post_sync', 'precommit', 'launch_lock', 'qualification_commit']
    supervised = ['collection_stdout', 'collection_stderr', 'heartbeat', 'stage_status', 'supervisor_log']
    required = {
        'QP-01': prelaunch + supervised + ['collection_check', 'test_stdout', 'test_stderr', 'junit', 'junit_check', 'input_after', 'success'],
        'QP-02': prelaunch + supervised + ['collection_check', 'test_stdout', 'test_stderr', 'junit', 'junit_check', 'input_after', 'success'],
        'QN-01': ['stop'],
        'QN-02': prelaunch[:4] + ['stop'], 'QN-03': prelaunch[:4] + ['stop'],
        'QN-04': prelaunch[:6] + ['stop'],
        'QN-05': prelaunch + supervised + ['stop'],
        'QN-06': prelaunch + supervised + ['stop', 'replay_rejection'],
    }
    all_rows = []
    for case in CASES:
        b = HQ / ('alternate_absolute_prefix/deep' if case == 'QP-02' else 'cases') / f'F{number:02d}' / case
        r = b / 'runtime'
        roots = {'B': b, 'Q': b / 'synthetic', 'T': b / 'control', 'P': b / 'public_cache', 'R': r,
                 'V': r / '.venv', 'E': r / 'evidence', 'L': r / 'observability', 'O': r / 'output',
                 'D': r / 'diagnostic', 'TMP': r / 'tmp', 'MPL': r / 'mpl', 'S': b / 'protected_stage', 'C': b / 'protected_custody'}
        t, q, v = roots['T'], roots['Q'], roots['V']
        artifact_map['uv_project_lock'] = ('TMP', uv_project_lock_basename(str(q)), 'UV_SYNC')
        package = t / CACHE_PREFIX
        entries = []
        for key in ['D', 'L', 'O', 'TMP', 'MPL', 'E']:
            entries.append({'id': key, 'path': str(roots[key]), 'kind': 'directory', 'stage': 'PRECOMMIT',
                            'before': 'ABSENT_OR_EXISTS_WRITABLE_EMPTY', 'after': 'EXISTS_WRITABLE'})
        entries.extend([
            {'id': 'public_cache', 'path': str(roots['P']), 'kind': 'managed_tree', 'stage': 'CACHE_BOOTSTRAP',
             'before': 'RESERVED_ABSENT_UNTIL_CACHE_BOOTSTRAP', 'after': 'EXISTS_WRITABLE_VERIFIED',
             'managed_by': 'frozen bootstrap then locked offline uv sync',
             'member_contract': {'cache_payload_manifest': str(package / 'CACHE_PAYLOAD_MANIFEST.json'),
                                 'symlink_map': str(package / 'UV_CACHE_SYMLINK_MAP.json'),
                                 'uv_cache_subdirectory': 'uv', 'regular_files': 8928, 'symlinks': 31,
                                 'regular_bytes': 481715990, 'required_members': cache_members,
                                 'optional_members': {'uv/.lock': {'kind': 'file'}, 'uv/.gitignore': {'kind': 'file'},
                                      'uv/CACHEDIR.TAG': {'kind': 'file'},
                                      'uv/interpreter-v4': {'kind': 'directory'},
                                      'uv/interpreter-v4/e128016a93bda1d6': {'kind': 'directory'},
                                      'uv/interpreter-v4/e128016a93bda1d6/7f8106be2b9d4caa.msgpack': {'kind': 'file'},
                                      'uv/sdists-v9': {'kind': 'directory'}, 'uv/sdists-v9/.git': {'kind': 'file'},
                                      'uv/sdists-v9/.gitignore': {'kind': 'file'}}}},
            {'id': 'virtual_environment', 'path': str(v), 'kind': 'managed_tree', 'stage': 'UV_SYNC',
             'before': 'RESERVED_ABSENT_UNTIL_UV_SYNC', 'after': 'EXISTS_WRITABLE_VERIFIED',
             'managed_by': 'uv 0.11.33 locked offline sync', 'member_contract': venv_contract},
        ])
        for key in ['S', 'C']:
            entries.append({'id': key, 'path': str(roots[key]), 'kind': 'protected', 'stage': 'PROHIBITED',
                            'before': 'ABSENT', 'after': 'ABSENT'})
        for key, (parent, basename, stage) in artifact_map.items():
            prohibited = key in ['run_commit', 'protected_ready', 'scientific_output', 'package']
            entries.append({'id': key, 'path': str(roots[parent] / basename), 'kind': 'protected' if prohibited else 'file',
                            'stage': stage, 'before': 'ABSENT' if prohibited else 'RESERVED_ABSENT_UNTIL_GATE',
                            'after': 'ABSENT' if prohibited else 'EXISTS_IF_STAGE_REACHED'})
        env = {'PATH': str(Path(PYTHON).parent) + ':/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
               'TZ': 'UTC', 'PYTHONHASHSEED': '0', 'PYTHONDONTWRITEBYTECODE': '1',
               'OMP_NUM_THREADS': '1', 'OPENBLAS_NUM_THREADS': '1', 'MKL_NUM_THREADS': '1', 'NUMEXPR_NUM_THREADS': '1',
               'PYTEST_DISABLE_PLUGIN_AUTOLOAD': '1', 'XDG_CACHE_HOME': str(roots['P']),
               'UV_OFFLINE': '1', 'UV_NO_CONFIG': '1', 'UV_PROJECT_ENVIRONMENT': str(v),
               'TMPDIR': str(roots['TMP']), 'MPLCONFIGDIR': str(roots['MPL'])}
        descriptor_path = t / 'descriptor.json'
        grandchild = [PYTHON, '-B', str(t / 'production/inherit.py'), str(descriptor_path), 'grandchild']
        if case == 'QN-03':
            grandchild = ['/usr/bin/env', '-u', 'UV_PROJECT_ENVIRONMENT'] + grandchild
        commands = {
            'inheritance': {'argv': [PYTHON, '-B', str(t / 'production/inherit.py'), str(descriptor_path), 'child'],
                            'cwd': str(t if case == 'QN-02' else q), 'stdout': 'inheritance_stdout', 'stderr': 'inheritance_stderr'},
            'bootstrap': {'argv': [PYTHON, '-B', str(package / 'bootstrap_uv_cache.py'), '--package-root', str(package), '--xdg-cache-home', str(roots['P'])],
                          'cwd': str(t), 'stdout': 'bootstrap_stdout', 'stderr': 'bootstrap_stderr'},
            'sync': {'argv': [UV, 'sync', '--locked', '--offline', '--no-dev', '--no-install-project', '--no-build',
                             '--no-managed-python', '--link-mode', 'copy', '--python', PYTHON],
                     'cwd': str(q), 'stdout': 'sync_stdout', 'stderr': 'sync_stderr'},
            'collection': {'argv': [str(v / 'bin/python'), '-B', '-m', 'pytest', '--collect-only', '-q', '-p', 'no:cacheprovider', 'test_synthetic.py'],
                           'cwd': str(q), 'stdout': 'collection_stdout', 'stderr': 'collection_stderr'},
            'test': {'argv': [str(v / 'bin/python'), '-B', '-m', 'pytest', '-q', '-s', '-p', 'no:cacheprovider',
                             '--junitxml=' + str(roots['E'] / 'junit.xml'), 'test_synthetic.py'],
                     'cwd': str(q), 'stdout': 'test_stdout', 'stderr': 'test_stderr'},
        }
        if case == 'QN-04':
            commands['bootstrap']['argv'] = [PYTHON, '-B', str(t / 'qualification/bootstrap_missing_link.py'),
                PYTHON, str(package / 'bootstrap_uv_cache.py'), str(package), str(roots['P']), links[0]['path']]
        if case == 'QN-05':
            commands['collection']['argv'] = [str(v / 'bin/python'), '-B', str(t / 'qualification/fail_child.py')]
        if case == 'QN-06':
            commands['collection']['argv'] = [str(t / 'intentionally_absent_executable')]
        execution = f'NME001-E07-S05-HQ01-{case}-F{number:02d}'
        probe = {'schema_version': 'NME001_HARNESS_DURABLE_PROBE_V1', 'execution_identity': execution,
                 'run_identity': None, 'execution_class': 'QUALIFICATION', 'checkpoint_sha256': frozen['fixture_sha256'],
                 'durable_target': 'CHATGPT_LIBRARY', 'purpose': 'PRE_EXECUTION_DURABILITY_PROBE', 'licensed_inputs_opened': False}
        input_files = {}
        for prefix, src, mapping in [('production', WORK / 'production', frozen['production']),
                                    ('qualification', WORK / 'qualification', frozen['qualification'])]:
            for name, rec in mapping.items():
                # Driver itself is recovery/qualification code and is not needed in a production realization.
                if prefix == 'qualification' and name == 'driver.py':
                    continue
                input_files[str(t / prefix / name)] = rec
        for name, rec in frozen['fixture'].items():
            input_files[str((t if name == 'fixture_manifest.json' else q) / name)] = rec
        for name, rec in controls.items():
            raw = rec['bytes']
            input_files[str(package / name)] = {'size_bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
        for name in ['durable_probe.json', 'durable_probe_readback.json']:
            input_files[str(t / name)] = {'size_bytes': len(canonical(probe)), 'sha256': hashlib.sha256(canonical(probe)).hexdigest()}
        descriptor = {'schema_version': 'NME001-HARNESS-DESCRIPTOR-V1', 'execution_class': 'QUALIFICATION',
                      'execution_identity': execution, 'run_identity': None, 'lease_identity': 'NME001-E07-S05-HQ01-WRITER-LEASE-01',
                      'roots': {k: str(p) for k, p in roots.items()}, 'runtime': {'python': PYTHON, 'python_version': '3.12.13',
                      'implementation': 'CPython', 'system': 'Linux', 'machine': 'x86_64', 'libc': ['glibc', '2.39'],
                      'uv': UV, 'uv_version': 'uv 0.11.33 (x86_64-unknown-linux-gnu)'},
                      'environment': env, 'write_set': entries, 'inputs': input_files,
                      'cache': {'archive': str(CACHE), 'archive_sha256': CACHE_SHA, 'package_root': str(package)},
                      'inheritance': {'grandchild_argv': grandchild}, 'commands': commands,
                      'fixture_sha256': frozen['fixture_sha256'], 'production_sha256': frozen['production_sha256'],
                      'expected_collection': ['test_synthetic.py::test_synthetic'], 'expected_junit': [['test_synthetic', 'test_synthetic']]}
        expected = {'case': case, 'boundary': BOUNDARIES[case], 'required_artifacts': [str(roots[artifact_map[k][0]] / artifact_map[k][1]) for k in required[case]],
                    'forbidden_artifacts': [str(roots[vv[0]] / vv[1]) for k, vv in artifact_map.items() if k not in required[case]],
                    'qualification_commits': 1 if case in ['QP-01', 'QP-02', 'QN-05', 'QN-06'] else 0,
                    'synthetic_child_spawns': 2 if case.startswith('QP') else (1 if case == 'QN-05' else 0),
                    'run_attempt_commits': 0, 'protected_contact_count': 0, 'run_identity': None,
                    'reentry_count': 1 if case == 'QN-06' else 0,
                    'initial_evidence_state': 'REGULAR_FILE' if case == 'QN-01' else 'ABSENT',
                    'cache_link_removed': links[0]['path'] if case == 'QN-04' else None}
        out = WORK / 'case_specs' / f'F{number:02d}' / case
        write(out / 'descriptor.json', canonical(descriptor))
        write(out / 'durable_probe.json', canonical(probe))
        write(out / 'expected_artifacts.json', canonical(expected))
        all_rows.append({'case': case, 'execution_identity': execution, 'descriptor': ident(out / 'descriptor.json'),
                         'expected_artifacts': ident(out / 'expected_artifacts.json'), 'state': 'PLANNED_NOT_INVOKED'})
    write(WORK / 'freezes' / f'F{number:02d}' / 'CASE_LEDGER_FROZEN.json', canonical({
        'record_identity': f'NME001-E07-S05-HQ01-CASE-LEDGER-F{number:02d}', 'production_sha256': frozen['production_sha256'],
        'fixture_sha256': frozen['fixture_sha256'], 'fixture_members': frozen['fixture'],
        'dependency_projection': fm['dependency_projection'], 'cases': all_rows, 'case_count': 8,
        'command_binding': 'Exact sync/pytest commands are in each hash-bound resolved descriptor.'}))


def run(number, case, readback):
    if case not in CASES:
        raise RuntimeError('case not in fixed matrix')
    froot = WORK / 'freezes' / f'F{number:02d}'
    frozen = json.loads((froot / 'FROZEN_MANIFEST.json').read_text())
    if records(WORK / 'production') != frozen['production'] or records(WORK / 'fixture') != frozen['fixture'] or records(WORK / 'qualification') != frozen['qualification']:
        raise RuntimeError('candidate bytes changed; qualification requires refreeze')
    spec = WORK / 'case_specs' / f'F{number:02d}' / case
    d = json.loads((spec / 'descriptor.json').read_text())
    expected = json.loads((spec / 'expected_artifacts.json').read_text())
    roots = {k: Path(v) for k, v in d['roots'].items()}
    result_root = WORK / 'case_results' / f'F{number:02d}' / case
    result_root.mkdir(parents=True, exist_ok=False)
    if ident(CACHE) != {'size_bytes': 148782742, 'sha256': CACHE_SHA}:
        raise RuntimeError('canonical public cache differs')
    native_probe = Path(readback) / 'case_specs' / f'F{number:02d}' / case / 'durable_probe.json'
    if native_probe.read_bytes() != (spec / 'durable_probe.json').read_bytes():
        raise RuntimeError('native recovered probe differs')
    roots['B'].parent.mkdir(parents=True, exist_ok=True)
    roots['B'].mkdir(exist_ok=False)
    for key in ['Q', 'T', 'R']:
        roots[key].mkdir()
    shutil.copytree(WORK / 'production', roots['T'] / 'production')
    (roots['T'] / 'qualification').mkdir()
    for p in (WORK / 'qualification').glob('*.py'):
        if p.name != 'driver.py':
            shutil.copyfile(p, roots['T'] / 'qualification' / p.name)
    for p in (WORK / 'fixture').iterdir():
        shutil.copyfile(p, (roots['T'] if p.name == 'fixture_manifest.json' else roots['Q']) / p.name)
    with zipfile.ZipFile(CACHE) as z:
        for name in z.namelist():
            if Path(name).is_absolute() or '..' in Path(name).parts:
                raise RuntimeError('unsafe frozen cache archive member')
        z.extractall(roots['T'])
    shutil.copyfile(spec / 'descriptor.json', roots['T'] / 'descriptor.json')
    shutil.copyfile(spec / 'durable_probe.json', roots['T'] / 'durable_probe.json')
    shutil.copyfile(native_probe, roots['T'] / 'durable_probe_readback.json')
    for name in d['inputs']:
        p = Path(name)
        if ident(p) != d['inputs'][name]:
            raise RuntimeError(f'realized input differs before invocation: {name}')
        p.chmod(0o444)
    if case == 'QN-01':
        write(roots['E'], b'QN-01 intentional evidence-root regular file\n')
    for key in ['S', 'C', 'P', 'V']:
        if os.path.lexists(roots[key]):
            raise RuntimeError(f'initial reserved root exists: {key}')
    invocation = {'record_identity': d['execution_identity'] + '-ORCHESTRATION-01', 'state': 'INVOKING',
                  'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'run_identity': None,
                  'descriptor': ident(spec / 'descriptor.json'), 'production_sha256': frozen['production_sha256'],
                  'fixture_sha256': frozen['fixture_sha256'], 'initial_evidence_state': expected['initial_evidence_state'],
                  'native_probe_readback_source': str(native_probe), 'protected_roots_absent': True}
    write(result_root / 'invocation.json', canonical(invocation))
    argv = [PYTHON, '-B', str(roots['T'] / 'production/harness.py'), str(roots['T'] / 'descriptor.json')]
    with (result_root / 'outer.stdout').open('xb') as out, (result_root / 'outer.stderr').open('xb') as err:
        process = subprocess.Popen(argv, cwd=roots['T'], env=d['environment'], stdin=subprocess.DEVNULL, stdout=out, stderr=err, shell=False)
        code = process.wait()
        for stream in [out, err]:
            stream.flush(); os.fsync(stream.fileno())
    reentry = None
    if case == 'QN-06' and (roots['D'] / 'QUALIFICATION_CASE_COMMIT.json').exists():
        with (result_root / 'reentry.stdout').open('xb') as out, (result_root / 'reentry.stderr').open('xb') as err:
            repeated = subprocess.run(argv, cwd=roots['T'], env=d['environment'], stdin=subprocess.DEVNULL, stdout=out, stderr=err, shell=False)
            reentry = repeated.returncode
    artifacts = {}
    for key in ['D', 'E', 'L', 'O', 'TMP', 'MPL']:
        root = roots[key]
        if root.is_dir():
            for p in root.rglob('*'):
                if p.is_file():
                    artifacts[str(p)] = ident(p)
                    destination = result_root / 'artifacts' / key / p.relative_to(root)
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(p, destination)
    stop = roots['D'] / 'STOP.json'
    success = roots['O'] / 'SUCCESS.json'
    observed = json.loads((success if success.exists() else stop).read_text()) if success.exists() or stop.exists() else {}
    boundary = 'SUCCESS' if success.exists() else observed.get('boundary', 'NO_TRUTHFUL_TERMINAL_RECORD')
    after = {name: ident(name) for name in d['inputs']}
    unchanged = after == d['inputs'] and records(WORK / 'production') == frozen['production'] and records(WORK / 'fixture') == frozen['fixture']
    required_set = set(expected['required_artifacts'])
    found = set(artifacts)
    checks = {'named_boundary': boundary == expected['boundary'], 'exact_artifacts': found == required_set,
              'forbidden_absent': not any(os.path.lexists(p) for p in expected['forbidden_artifacts']),
              'commit_count': observed.get('qualification_commits') == expected['qualification_commits'],
              'spawn_count': observed.get('synthetic_child_spawns') == expected['synthetic_child_spawns'],
              'run_commit_zero': observed.get('run_attempt_commits') == 0,
              'run_identity_null': observed.get('run_identity', 'MISSING') is None,
              'protected_absent': not any(os.path.lexists(roots[k]) for k in ['S', 'C']),
              'input_byte_drift_zero': unchanged, 'case_exit': code == (0 if case.startswith('QP') else 1),
              'reentry': reentry == 73 if case == 'QN-06' else reentry is None}
    result = {'case': case, 'execution_identity': d['execution_identity'], 'run_identity': None,
              'result': 'PASS' if all(checks.values()) else 'FAIL', 'checks': checks,
              'expected_boundary': expected['boundary'], 'observed_boundary': boundary,
              'outer_pid': process.pid, 'outer_exit': code, 'reentry_exit': reentry,
              'qualification_commits': observed.get('qualification_commits', 0),
              'synthetic_child_spawns': observed.get('synthetic_child_spawns', 0),
              'run_attempt_commits': observed.get('run_attempt_commits', 0),
              'missing_artifacts': sorted(required_set - found), 'unexpected_artifacts': sorted(found - required_set),
              'production_sha256': frozen['production_sha256'], 'fixture_sha256': frozen['fixture_sha256'],
              'descriptor': ident(spec / 'descriptor.json'), 'executed_inputs_before': d['inputs'],
              'executed_inputs_after': after, 'artifacts': artifacts, 'protected_contact_count': 0,
              'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    final_observations = []
    for entry in d['write_set']:
        path = Path(entry['path'])
        observation = {'id': entry['id'], 'path': str(path), 'owning_stage': entry['stage'],
                       'declared_after': entry['after'], 'observed': 'ABSENT'}
        if os.path.lexists(path):
            mode = path.lstat().st_mode
            observation['observed'] = 'directory' if stat.S_ISDIR(mode) else ('symlink' if stat.S_ISLNK(mode) else 'file')
            if stat.S_ISREG(mode):
                observation['identity'] = ident(path)
        final_observations.append(observation)
    result['final_write_set_observations'] = final_observations
    write(result_root / 'result.json', canonical(result))
    print(json.dumps({k: v for k, v in result.items() if k not in ['artifacts', 'executed_inputs_before', 'executed_inputs_after', 'final_write_set_observations']}, sort_keys=True))
    return 0 if result['result'] == 'PASS' else 2


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest='mode', required=True)
    f = sub.add_parser('freeze'); f.add_argument('number', type=int)
    r = sub.add_parser('run'); r.add_argument('number', type=int); r.add_argument('case'); r.add_argument('--readback', required=True)
    args = p.parse_args()
    if args.mode == 'freeze':
        freeze(args.number)
        return 0
    return run(args.number, args.case, args.readback)


if __name__ == '__main__':
    raise SystemExit(main())
