"""Derive uv's project-lock filename without invoking uv or touching a case.

The installed uv 0.11.33 x86_64 Linux binary contains the ``uv-{digest}.lock``
format at ELF VA 0x2650de. The associated Path digest routine at 0x1dc0390
feeds normalized path-component bytes and a rolling component-length u64 to
SeaHash, then encodes the resulting u64's little-endian bytes as hexadecimal.
SeaHash write/finalize are at 0xfbcc70/0xfbd1e0; hex output is at 0x2327b90.

This qualified-driver helper supports canonical absolute POSIX paths only.
It does not generalize the observed contract to another uv build or platform.
"""
from pathlib import PurePosixPath


_MASK = (1 << 64) - 1
_MULTIPLIER = 0x6EED0E9DA4D94A4F
_SEEDS = (0x16F11FE89B0D677C, 0xB480A793D8E6C86C,
          0x6FE2E5AAF078EBC9, 0x14F994A4C5259381)


def _diffuse(value: int) -> int:
    value = (value * _MULTIPLIER) & _MASK
    value ^= (value >> 32) >> (value >> 60)
    return (value * _MULTIPLIER) & _MASK


def _seahash(data: bytes) -> int:
    a, b, c, d = _SEEDS
    for offset in range(0, len(data), 8):
        chunk = int.from_bytes(data[offset:offset + 8], "little")
        a, b, c, d = b, c, d, _diffuse(a ^ chunk)
    return _diffuse(a ^ b ^ c ^ d ^ len(data))


def uv_project_lock_basename(canonical_absolute_q: str) -> str:
    """Return the exact TMP lock basename for the bound synthetic project Q."""
    q = canonical_absolute_q
    if (not isinstance(q, str) or not q or "\x00" in q or "\\" in q
            or not q.startswith("/") or q.startswith("//")):
        raise ValueError("Q must be a canonical absolute POSIX path")
    path = PurePosixPath(q)
    if path.as_posix() != q or ".." in path.parts:
        raise ValueError("Q must not contain aliases, empty components, or traversal")
    components = []
    lengths = 0
    for component in path.parts[1:]:
        try:
            raw = component.encode("utf-8")
        except UnicodeEncodeError as error:
            raise ValueError("Q must be valid UTF-8") from error
        components.append(raw)
        lengths = (lengths + len(raw)) & _MASK
        lengths = ((lengths >> 2) | (lengths << 62)) & _MASK
    data = b"".join(components) + lengths.to_bytes(8, "little")
    digest = _seahash(data).to_bytes(8, "little").hex()
    return "uv-" + digest + ".lock"


# Observed F00 control, documented without adding a qualification test/case:
# Q = /workspace/scratch/cbd6528b11d8/NME001_EPOCH07_S05_HQ01/cases/F00/QP-01/synthetic
# uv_project_lock_basename(Q) == "uv-bf849b7789075826.lock"
