"""QN-04 only: exact bootstrap followed by one fresh-realization perturbation."""
import os
from pathlib import Path
import subprocess
import sys

python, bootstrap, package, xdg, relative_link = sys.argv[1:]
result = subprocess.run([python, '-B', bootstrap, '--package-root', package, '--xdg-cache-home', xdg],
                        cwd=Path.cwd(), env=dict(os.environ), stdin=subprocess.DEVNULL, shell=False)
if result.returncode:
    raise SystemExit(result.returncode)
link = Path(xdg) / 'uv' / relative_link
if not link.is_symlink():
    raise RuntimeError('qualification perturbation target is not a realized symlink')
link.unlink()
print('QN-04 removed one declared cache symlink after exact bootstrap', flush=True)
