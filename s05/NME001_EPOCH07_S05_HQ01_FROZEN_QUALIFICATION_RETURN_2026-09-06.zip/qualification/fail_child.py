"""QN-05 only: immutable pytest child reports its deliberate nonzero exit."""
import sys
import pytest

code = pytest.main(['--collect-only', '-q', '-p', 'no:cacheprovider', 'test_synthetic.py'])
if code:
    raise SystemExit(code)
print('QN-05 deliberate child exit 23 after synthetic collection', flush=True)
print('QN-05 synthetic diagnostic stderr', file=sys.stderr, flush=True)
raise SystemExit(23)
