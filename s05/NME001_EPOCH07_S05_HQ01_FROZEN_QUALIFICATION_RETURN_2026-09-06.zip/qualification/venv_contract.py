"""Declare exact potential V members from the frozen five-wheel cache.

This qualification-only builder reads ZIP metadata and member bytes. It does
not extract anything, import wheel code, construct a venv, or execute children.
The returned map is a prospective allowlist, never an observation receipt.
"""

from __future__ import annotations

import configparser
from email.parser import BytesParser
import hashlib
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile


SITE = PurePosixPath("lib/python3.12/site-packages")
GENERATED_DISTRIBUTION_FILES = (
    "INSTALLER", "REQUESTED", "uv_cache.json", "direct_url.json",
)
OPTIONAL_RUNTIME_FILES = (
    ".gitignore", "CACHEDIR.TAG", ".lock",
    "bin/activate", "bin/activate.bat", "bin/activate.csh",
    "bin/activate.fish", "bin/activate.nu", "bin/activate.ps1",
    "bin/activate_this.py", "bin/deactivate.bat", "bin/pydoc.bat",
)


def _normalized(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def _safe_relative(value: str) -> PurePosixPath:
    path = PurePosixPath(value)
    if (not value or path.is_absolute() or ".." in path.parts
            or "\\" in value or value != path.as_posix()):
        raise ValueError(f"noncanonical relative member: {value!r}")
    return path


def build_venv_contract(cache_archive: Path, projection: dict) -> dict:
    """Return exact required/optional V paths for CPython 3.12 Linux uv sync.

    All source member bytes except mutable wheel RECORD receive their frozen
    SHA-256 binding. The interpreter links and uv-generated files are bound by
    exact path and type; their contents depend on the resolved descriptor or uv.
    """
    expected = {_normalized(name): version for name, version in projection.items()}
    if len(expected) != len(projection) or set(expected) != {
        "pytest", "iniconfig", "packaging", "pluggy", "pygments",
    }:
        raise ValueError("HQ01 requires the exact five-distribution projection")
    if any(not isinstance(version, str) or not version for version in expected.values()):
        raise ValueError("invalid distribution version")

    required: dict[str, dict] = {}
    optional: dict[str, dict] = {}

    def directory_parents(path: PurePosixPath) -> None:
        for parent in reversed(path.parents):
            if parent == PurePosixPath("."):
                continue
            key = str(parent)
            if key in required and required[key]["kind"] != "directory":
                raise ValueError(f"member-parent collision: {key}")
            required[key] = {"kind": "directory"}

    def add(target: dict[str, dict], path: str, record: dict) -> None:
        relative = _safe_relative(path)
        directory_parents(relative)
        other = optional if target is required else required
        if path in other:
            raise ValueError(f"required/optional member collision: {path}")
        if path in target and target[path] != record:
            raise ValueError(f"conflicting prospective member: {path}")
        target[path] = record

    for path in ("bin", "lib", "lib/python3.12", str(SITE)):
        add(required, path, {"kind": "directory"})
    for path in ("pyvenv.cfg", str(SITE / "_virtualenv.py"), str(SITE / "_virtualenv.pth")):
        add(required, path, {"kind": "file"})
    for path in ("bin/python", "bin/python3", "bin/python3.12"):
        add(required, path, {"kind": "symlink"})
    for path in OPTIONAL_RUNTIME_FILES:
        add(optional, path, {"kind": "file"})
    add(optional, "lib64", {"kind": "symlink"})

    selected: dict[str, tuple[str, str]] = {}
    source_bindings = {}
    generated_scripts = set()
    with zipfile.ZipFile(cache_archive) as archive:
        infos = archive.infolist()
        if len({info.filename for info in infos}) != len(infos):
            raise ValueError("duplicate archive member names")
        for info in infos:
            if "/uv-cache/archive-v0/" not in info.filename or not info.filename.endswith(".dist-info/METADATA"):
                continue
            metadata = BytesParser().parsebytes(archive.read(info), headersonly=True)
            name = _normalized(metadata.get("Name", ""))
            if name not in expected:
                continue
            version = metadata.get("Version", "")
            if version != expected[name] or name in selected:
                raise ValueError(f"ambiguous or unexpected cached distribution: {name} {version}")
            distribution_root, dist_info, _ = info.filename.rsplit("/", 2)
            selected[name] = (distribution_root + "/", dist_info)
        if set(selected) != set(expected):
            raise ValueError(f"missing cached distribution metadata: {sorted(set(expected) - set(selected))}")

        for name in sorted(selected):
            root, dist_info = selected[name]
            source_bindings[name] = {"version": expected[name], "cache_distribution_root": root,
                                     "metadata_member": root + dist_info + "/METADATA"}
            for info in infos:
                if not info.filename.startswith(root):
                    continue
                value = info.filename[len(root):]
                if not value:
                    continue
                relative = _safe_relative(value.rstrip("/"))
                if any(part.endswith(".data") for part in relative.parts):
                    raise ValueError(f"wheel .data relocation is not declared: {info.filename}")
                output = str(SITE / relative)
                mode = info.external_attr >> 16
                if info.is_dir() or stat.S_ISDIR(mode):
                    add(required, output, {"kind": "directory"})
                    continue
                if not stat.S_ISREG(mode):
                    raise ValueError(f"unsupported cached member type: {info.filename}")
                content = archive.read(info)
                # These files are generated/rewritten by the installer; bind
                # their exact path/type without claiming frozen source content.
                generated = relative.parent == PurePosixPath(dist_info) and relative.name in GENERATED_DISTRIBUTION_FILES
                mutable_record = relative == PurePosixPath(dist_info) / "RECORD"
                record = {"kind": "file"}
                if not generated and not mutable_record:
                    record["sha256"] = hashlib.sha256(content).hexdigest()
                    record["size_bytes"] = len(content)
                add(optional if generated else required, output, record)
                if relative == PurePosixPath(dist_info) / "entry_points.txt":
                    parser = configparser.ConfigParser(interpolation=None)
                    parser.optionxform = str
                    parser.read_string(content.decode("utf-8"))
                    for group in ("console_scripts", "gui_scripts"):
                        if parser.has_section(group):
                            for script in parser[group]:
                                if len(_safe_relative(script).parts) != 1:
                                    raise ValueError(f"unsafe console entrypoint: {script!r}")
                                generated_scripts.add(script)
            for basename in GENERATED_DISTRIBUTION_FILES:
                add(optional, str(SITE / dist_info / basename), {"kind": "file"})

    if generated_scripts != {"py.test", "pytest", "pygmentize"}:
        raise ValueError(f"unexpected console entrypoints: {sorted(generated_scripts)}")
    for script in sorted(generated_scripts):
        add(optional, "bin/" + script, {"kind": "file"})

    return {
        "distributions": dict(sorted(expected.items())),
        "required_members": dict(sorted(required.items())),
        "optional_members": dict(sorted(optional.items())),
        "source_bindings": source_bindings,
        "assumptions": [
            "Prospective exact member contract for CPython 3.12 Linux and the bound uv executable; this is not an observed venv inventory.",
            "The five cached wheels install directly under lib/python3.12/site-packages; any .data relocation or nonregular cache payload is rejected.",
            "All frozen copied regular files bind source SHA-256 and size except installer-rewritten RECORD and exact named generated distribution files.",
            "Required interpreter links and uv runtime baseline bind exact path/type; descriptor-specific generated contents are not assigned invented hashes.",
            "The explicitly enumerated uv auxiliary files, generated distribution metadata, and three metadata-declared console entrypoint scripts may be absent; every optional member must receive an observed PRESENT or ABSENT state.",
            "No wildcard or discovered-path promotion is permitted: any actual V member outside required_members and optional_members must be rejected.",
            "Bytecode compilation is disabled by the exact command/environment; no undeclared __pycache__ or .pyc writes are permitted.",
        ],
    }
