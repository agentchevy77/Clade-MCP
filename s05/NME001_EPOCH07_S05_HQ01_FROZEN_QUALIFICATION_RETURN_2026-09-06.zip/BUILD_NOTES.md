# HQ01 implementation record

Internal Developer implements the exact startup order and charter in controls/.
No Nexus checkpoint, project test, protected input, market row, acceptance payload,
or historical-final payload was materialized, imported, or read.

Production consists of harness.py, inherit.py, cache.py, supervisor.py, and one
descriptor schema. The supervisor is a generalized copy of the exact donor;
its donor source and diff remain recoverable. Heartbeat wait semantics,
durable-probe strictness, no-shell subprocess launch, PID/exit recording, and
flush/fsync behavior are retained. Explicit cwd/environment, separate output
streams, and observed stage records implement the charter. No qualification
case name or fault switch appears in production logic.

The descriptor's write set binds each output, its stage, and its boundary state.
Cache and virtual-environment trees expand to prospective exact required and
optional member maps. Optional entries are named prospective permissions,
recorded as absent when not emitted. An undeclared actual member is rejected.
The cache contract includes the frozen bootstrap receipt. No prior PASS receipt
is used. Root construction and output redirection probe actual writable parents;
post-stage observations consume the same declaration. Returned driver observations
also cover the terminal receipt itself after it has been written.

The qualification fixture is one trivial test and five exact cached packages.
Its manual lock remains unqualified until the fixed positive cases run.
The driver binds absolute case descriptors before freeze. QN-04 uses an external
qualification-only bootstrap wrapper, QN-05 an immutable pytest child that exits
23, and QN-06 an absent executable followed by one replay attempt. No retired
launcher or sequence is executed.

Native recovery uses one rolling WIP identity. Frozen dependency cache bytes
remain a separate exact input. Realizations can be rebuilt from this work product
and that archive; mutable caches/venvs are never promoted to source custody.
Repository, branch, base commit, and QA repository access are inapplicable.
