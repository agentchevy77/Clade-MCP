"""Small out-of-process heartbeat launcher for the S02 licensed run."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from typing import IO, Sequence


class S02SupervisorError(RuntimeError):
    """The bounded launcher or heartbeat record failed."""


DURABLE_PROBE_SCHEMA = "NME001_EPOCH07_S02_DURABLE_PROBE_V1"


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def verify_durable_probe(
    probe_path: str | Path,
    probe_readback_path: str | Path,
    *,
    run_identity: str,
    checkpoint_sha256: str,
) -> str:
    """Require byte-identical external readback before a child can launch."""

    if len(checkpoint_sha256) != 64 or any(
        character not in "0123456789abcdef" for character in checkpoint_sha256
    ):
        raise S02SupervisorError("checkpoint SHA-256 is invalid")
    probe = Path(probe_path).resolve()
    readback = Path(probe_readback_path).resolve()
    if probe == readback:
        raise S02SupervisorError("durable probe requires an independent readback path")
    try:
        original = probe.read_bytes()
        returned = readback.read_bytes()
    except OSError as exc:
        raise S02SupervisorError("durable probe or readback is unavailable") from exc
    if not original or original != returned:
        raise S02SupervisorError("durable probe readback bytes differ")
    try:
        payload = json.loads(returned)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise S02SupervisorError("durable probe is not valid JSON") from exc
    if not isinstance(payload, dict) or set(payload) != {
        "schema_version",
        "run_identity",
        "checkpoint_sha256",
        "durable_target",
        "purpose",
        "licensed_inputs_opened",
    }:
        raise S02SupervisorError("durable probe schema fields mismatch")
    if (
        payload["schema_version"] != DURABLE_PROBE_SCHEMA
        or payload["run_identity"] != run_identity
        or payload["checkpoint_sha256"] != checkpoint_sha256
        or payload["durable_target"] != "CHATGPT_LIBRARY"
        or payload["purpose"] != "PRE_LICENSED_RUN_DURABILITY_PROBE"
        or payload["licensed_inputs_opened"] is not False
    ):
        raise S02SupervisorError("durable probe identity or state mismatch")
    return _sha256_bytes(returned)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _append_heartbeat(
    stream: IO[str],
    *,
    run_identity: str,
    status: str,
    child_pid: int,
    elapsed_seconds: float,
    exit_code: int | None = None,
) -> None:
    record: dict[str, object] = {
        "schema_version": "NME001_EPOCH07_S02_HEARTBEAT_V1",
        "run_identity": run_identity,
        "status": status,
        "child_pid": child_pid,
        "elapsed_seconds": round(elapsed_seconds, 3),
        "observed_utc": _utc_now(),
    }
    if exit_code is not None:
        record["exit_code"] = exit_code
    stream.write(json.dumps(record, sort_keys=True, separators=(",", ":")) + "\n")
    stream.flush()
    os.fsync(stream.fileno())


def supervise(
    command: Sequence[str],
    *,
    run_identity: str,
    heartbeat_path: str | Path,
    log_path: str | Path,
    durable_probe_path: str | Path,
    durable_probe_readback_path: str | Path,
    checkpoint_sha256: str,
    interval_seconds: float = 60.0,
) -> int:
    """Launch one child, emitting local status suitable for durable mirroring."""

    if not command or any(not isinstance(value, str) or not value for value in command):
        raise S02SupervisorError("supervised command is empty or invalid")
    if not run_identity or any(character.isspace() for character in run_identity):
        raise S02SupervisorError("run identity is empty or contains whitespace")
    if interval_seconds <= 0 or interval_seconds > 300:
        raise S02SupervisorError("heartbeat interval must be in (0, 300] seconds")

    verify_durable_probe(
        durable_probe_path,
        durable_probe_readback_path,
        run_identity=run_identity,
        checkpoint_sha256=checkpoint_sha256,
    )

    heartbeat = Path(heartbeat_path).resolve()
    log = Path(log_path).resolve()
    if heartbeat == log:
        raise S02SupervisorError("heartbeat and log paths must differ")
    heartbeat.parent.mkdir(parents=True, exist_ok=True)
    log.parent.mkdir(parents=True, exist_ok=True)

    started = time.monotonic()
    with log.open("ab", buffering=0) as log_stream, heartbeat.open(
        "a", encoding="utf-8", newline="\n"
    ) as heartbeat_stream:
        try:
            process = subprocess.Popen(
                list(command),
                stdin=subprocess.DEVNULL,
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                shell=False,
            )
        except OSError as exc:
            raise S02SupervisorError("unable to launch supervised process") from exc

        _append_heartbeat(
            heartbeat_stream,
            run_identity=run_identity,
            status="STARTED",
            child_pid=process.pid,
            elapsed_seconds=0.0,
        )
        while True:
            try:
                exit_code = process.wait(timeout=interval_seconds)
            except subprocess.TimeoutExpired:
                _append_heartbeat(
                    heartbeat_stream,
                    run_identity=run_identity,
                    status="RUNNING",
                    child_pid=process.pid,
                    elapsed_seconds=time.monotonic() - started,
                )
                continue
            _append_heartbeat(
                heartbeat_stream,
                run_identity=run_identity,
                status="EXITED",
                child_pid=process.pid,
                elapsed_seconds=time.monotonic() - started,
                exit_code=exit_code,
            )
            os.fsync(log_stream.fileno())
            return exit_code


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-identity", required=True)
    parser.add_argument("--heartbeat", required=True)
    parser.add_argument("--log", required=True)
    parser.add_argument("--durable-probe", required=True)
    parser.add_argument("--durable-probe-readback", required=True)
    parser.add_argument("--checkpoint-sha256", required=True)
    parser.add_argument("--interval-seconds", type=float, default=60.0)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    arguments = parser.parse_args(argv)
    command = arguments.command
    if command and command[0] == "--":
        command = command[1:]
    return supervise(
        command,
        run_identity=arguments.run_identity,
        heartbeat_path=arguments.heartbeat,
        log_path=arguments.log,
        durable_probe_path=arguments.durable_probe,
        durable_probe_readback_path=arguments.durable_probe_readback,
        checkpoint_sha256=arguments.checkpoint_sha256,
        interval_seconds=arguments.interval_seconds,
    )


if __name__ == "__main__":  # pragma: no cover - CLI boundary
    raise SystemExit(main())
