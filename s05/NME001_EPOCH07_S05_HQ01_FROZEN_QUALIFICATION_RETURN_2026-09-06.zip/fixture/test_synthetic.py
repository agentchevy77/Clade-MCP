"""One immutable, deterministic qualification-only test."""

import sys


def test_synthetic():
    print("NME001_HQ01_SYNTHETIC_STDOUT", flush=True)
    print("NME001_HQ01_SYNTHETIC_STDERR", file=sys.stderr, flush=True)
    assert 2 + 2 == 4
