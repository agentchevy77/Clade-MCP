# Project Nexus — EPOCH07-S04 Lease-03 CWD Stop Disposition and Lease-04 RUN01 Continuation

**Identity:** `NME001-ORIGIN-EPOCH07-S04-LEASE03-CWD-STOP-DISPOSITION-AND-LEASE04-RUN01-CONTINUATION-01`  
**Issued:** `2026-09-06T03:42:37Z`  
**Disposition:** `LEASE03_PREFLIGHT_ENVIRONMENT_PROBE_STOP_ACCEPTED / GENERATION1_TOP_LEVEL_INVOCATION_WORKDIR_NOT_SET / RUN01_NOT_LAUNCHED / RUN_ATTEMPT_NOT_CONSUMED / LEASE03_CLOSED_PERMANENTLY / ACCEPTED_S04_CHECKPOINT_REMAINS_CONTROLLING / PERMANENT_PREFLIGHT_GATE_SURFACE_FROZEN / LEASE04_AUTHORIZED_FOR_EXACT_TOP_LEVEL_WORKDIR_BINDING_AND_THE_SAME_S04_RUN01 / NO_S04_RUN02`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`  
**Authority basis:** Origin's standing bounded Nexus autonomy under the Product Owner's anti-ceremony direction. No new Product Owner approval is required.

## 1. Exact stop disposition

Origin accepts the Lease-03 stop as a truthful, safe prelaunch engineering stop:

- stop filename: `NME001_EPOCH07_S04_RUN01_LEASE03_DEFINED_STOP.json`;
- Library: `libfile_3c6b760170a08191a4a01a3ba6e3dbcd`;
- version: `0`;
- size: `4,856` bytes;
- SHA-256: `b073a51709003b385594c995f46e6120de1aed7141f2d0ef27a5955f985ae7bb`;
- record identity: `NME001-EPOCH07-S04-RUN01-LEASE03-PREFLIGHT-ENVIRONMENT-PROBE-DEFINED-STOP-01`;
- boundary: `PRELAUNCH / ENVIRONMENT_CACHE_INHERITANCE_PROBE / GENERATION_1_CWD_MISMATCH`; and
- creation time: `2026-09-06T03:09:17Z`.

The failed probe is:

- filename: `NME001_EPOCH07_S04_RUN01_LEASE03_CACHE_INHERITANCE_PROBE.json`;
- Library: `libfile_2bef854beca88191863cb794c615ecb4`;
- version: `0`;
- size: `5,938` bytes; and
- SHA-256: `7e65c999649d46a905e20d8f80755139d646130471793b33178f565ef1195e4e`.

The exact counters control. No external-harness candidate was frozen; no static reviewer, checker, final durability probe, launcher, supervisor, project import, `uv sync`, collection, test, protected-input action, scientific action, or historical-final access began. Launch count remains `0`.

Therefore:

1. `NME001-E07-S04-WRITER-LEASE-03` is closed permanently.
2. `NME001-SEO01-EPOCH07-S04-RUN01` was not launched, attempted, consumed, retried, or converted into evidence.
3. The same RUN01 identity remains the one lawful unconsumed reservation.
4. Lease-03 records have diagnostic/preflight authority only; development and scientific evidence authority remain `NONE`.
5. This order authorizes one fresh successor lease and, only after every inherited prelaunch gate passes, the first and only S04 RUN01 launch. It is not RUN02, S05, Epoch 08, or a launched-run retry.

## 2. Exact cause finding

The Lease-03 cache realization succeeded and is not the cause of this stop. The fresh observed realization and independent durability checks bound:

- `8,928` exact regular payload files;
- `31` exact safe relative symlinks;
- `481,715,990` regular payload bytes;
- one invocation of the immutable bundled bootstrap;
- canonical bootstrap receipt SHA-256 `d95c84e62fe4c0bfeb12a75c43a92bb2e93a246ff2acb01af0886facbd702d75`;
- independent filesystem verification SHA-256 `4311d09f047d46fd1e72ea38f27de3abcd125c9a419eb4c94d7e800fce3b0eaf`;
- observed regular-ledger SHA-256 `76dcd911ee48b65e16c7b28ab8ecbd8adee418bc02fb89bcf22f587fd1bc1975`;
- observed symlink-ledger SHA-256 `41809b0785e868de09bb3d5443a831d4bff61e176c0040cb4d1d9a8503912d41`; and
- wrapper receipt SHA-256 `569752fe8af702bb06612259e6ca864e66de165065f122485208426f9aae9d5d`.

The environment/cache probe also established that every normalized environment and cache binding passed, including the Lease-03 XDG and uv roots, CPython `3.12.13`, x86_64/glibc `2.39`, `PYTHONDONTWRITEBYTECODE=1`, `sys.dont_write_bytecode=true`, `python -B`, `SOURCE_DATE_EPOCH` absence, and the exact `uv cache dir` result. Generation 2 entered the required nonproject directory and passed. The disposable import/residue control passed.

The only mismatch was Generation 1's invocation directory:

```text
expected: /workspace/scratch/8ee21c4e3e47/NME001_EPOCH07_S04_RUN01_LEASE03/s04_run01_control/preflight/nonproject
observed: /workspace/scratch/8ee21c4e3e47
```

These are different ancestor/descendant locations, not logical and physical aliases. The expected value already names Lease 03, and no stale Lease-02 binding caused the failure. Adopt the exact cause classification:

`GENERATION1_TOP_LEVEL_INVOCATION_WORKDIR_NOT_SET / EXPECTED_T_PREFLIGHT_NONPROJECT / OBSERVED_WORKSPACE_SEGMENT_PARENT / ENVIRONMENT_AND_CACHE_BINDINGS_EXACT / GENERATION2_EXACT / CACHE_REALIZATION_EXACT`

Do not change the existing resolved-path equality rule, add a broader path-equivalence rule, alter the probe's meaning, or characterize this as cache corruption.

## 3. Accepted source and inherited authority remain unchanged

The sole accepted project-source input remains:

- checkpoint: `NME001_SEO01_RECOVERY_EPOCH07_S04_PROSPECTIVE_SOURCE_CHECKPOINT.zip`;
- Library: `libfile_ac30da9757808191abde59ff75dceff6`;
- version: `0`;
- size: `4,001,839` bytes;
- SHA-256: `74ca21c1dab80fb3fb1a8fd87211127495c7e60c0fde13448e7bcb42affb0104`;
- manifest SHA-256: `1f59b080407ee65cd622c6175fd5f3a26861251361b3a2ed3c463b70cf56f5cc`;
- source-tree SHA-256: `d700092b3c414e8ccfb3dfb7bc076ed7a8ea1359be38b2ebba728b0e3d5893fa`;
- accounting: `171` manifest-bound members plus one self-excluded manifest; and
- dependency projection: `13+1 / 14 EXACT`, SHA-256 `878bc4fac6824920d427f1c9b5f862949604896365ba752f143c2aedd87822f5`.

The accepted collect-only inventories remain:

- hermetic: `981`, ordered SHA-256 `46dde6a20b29221f6961bd8ff02254950080d58ffb3f517a98c8c25cab6e626e`; and
- licensed-inclusive: `1,042`, ordered SHA-256 `137203ed6b1267349e37898f1deed5a2844429eebea1be3cb8b4eb4e74428464`.

This order inherits without scientific or protected-data change:

1. `NME001_ORIGIN_EPOCH07_S04_CACHE_REALIZATION_REMEDIATION_AND_RUN01_CONTINUATION_2026-09-06.md` — Library `libfile_e7b248c1dd9c8191950628277bedeb7e`, backing `file_000000000d7881f58865fe3e0520f106`, v0, `19,481` bytes, SHA-256 `db3b8747da447bb065534a8d577a985705c85add4bc33dd33c55216fe49076a0`; and
2. `NME001_ORIGIN_EPOCH07_S04_CHECKPOINT_ACCEPTANCE_AND_RUN01_ORDER_2026-09-05.md` — Library `libfile_2ea24c3afb7c819186578964de4d8c66`, backing `file_00000000ec3881f592a7d0cf92066502`, v0, `24,545` bytes, SHA-256 `a47fb126fa41d20fcd5b4e4b6327b603cfed7e4495c9580f1b386ac115a0a47e`.

This order supersedes them only for the successor Lease-04 identity/root bindings, the exact Generation-1 top-level invocation working-directory condition, and the permanent gate-surface freeze. All lane, custody, scientific, packaging, leakage, return, hold, and authority rules remain controlling.

No project source, test, project configuration, lockfile, checkpoint, dependency, inventory, protocol, model, feature, label, metric, exclusion, partition, final identity, protected-input rule, or scientific meaning may change. Do not create or refreeze a source checkpoint.

## 4. Successor lease and fresh-root boundary

Remain within:

```text
work_order: NME-001-SEO-01
execution: NME-001-SEO-01-RECOVERY-EPOCH-07
segment: EPOCH07-S04
run: NME001-SEO01-EPOCH07-S04-RUN01
run_state: RESERVED_NOT_LAUNCHED / LAUNCH_COUNT_0 / ATTEMPT_NOT_CONSUMED
closed_lease: NME001-E07-S04-WRITER-LEASE-03 / CLOSED_PERMANENTLY
successor_lease: NME001-E07-S04-WRITER-LEASE-04
lease_scope: EXACT_GENERATION1_TOP_LEVEL_WORKDIR_BINDING / FROZEN_PREFLIGHT_CHAIN / SAME_RUN01_ONLY
```

Exactly one oriented high-capability Developer may claim Lease 04 after:

1. reading and hashing this order exactly;
2. confirming Lease 03 is closed and no other Nexus Developer writer, test, scientific process, or authorized run is active;
3. confirming the accepted S04 checkpoint and inherited orders resolve exactly; and
4. choosing one new absent absolute parent `B`, disjoint from all prior lease/runtime roots.

Recreate the authorized S04 root map under `B`. Lease-03 mutable cache, harness, receipts, probes, candidates, launchers, runtime artifacts, and roots are diagnostic only and must not become Lease-04 runtime state or PASS evidence. Lease 03 froze no external-harness candidate (`candidate_freezes=0`), so reconstruct from the durable sanitized baseline and authorized diffs named by the inherited orders—not from Lease-03 WIP. Freshly materialize and verify only the nonprotected authorities permitted before hermetic PASS; protected inputs remain metadata-only and absent until their inherited gate. Recreate the public cache with the exact bundled bootstrap exactly once under Lease 04 and derive receipts from observed `lstat`/`readlink` state under the unchanged `8,928 regular + 31 symlink + 481,715,990-byte` contract. The prior Lease-03 bootstrap invocation remains historical count `1`; this Lease-04 invocation is separately count `1`. Never report either as the sole segment-wide invocation. Root- or time-bearing receipt hashes may differ; the stable manifest, byte, path, target, and topology predicates must match exactly.

## 5. Permanent prelaunch gate-surface freeze

The prelaunch gate surface is now frozen for the remainder of S04 RUN01. This is a convergence control.

1. Add no new component, probe, wrapper, checker, scanner, launcher stage, receipt class, manifest class, inventory class, allowlist rule, pass condition, schema semantics, predicate semantics, or review layer. Mechanically rebound Lease-04 instances of inherited classes remain required.
2. Do not broaden, reinterpret, or weaken any existing gate.
3. Use all and only the inherited prelaunch stages, as narrowed by this order, including authority/root checks, checkpoint verification, the exact cache bootstrap and verifier, source-tree/protected-absence checks, environment/cache inheritance probe, static-review stage, positive-control checker, authoritative checker, launcher, durability checks, and prelaunch capsule.
4. A later failure is handled by the existing gate that detected it. It does not authorize another gate.
5. Any condition that cannot be represented truthfully through the frozen surface requires a defined stop for Origin, not an improvised control.

## 6. Sole authorized invocation correction

There is no probe-source or wrapper defect to repair. The correction is an execution-facility condition:

1. After the once-only Lease-04 cache realization and before external-harness candidate freeze, invoke the mechanically rebound existing environment/cache inheritance probe exactly once with `python -B`, the exact normalized environment, and the execution facility's OS-level working-directory parameter set directly to the exact Lease-04 `s04_run01_control/preflight/nonproject` directory.
2. Do not rely on ambient shell state, inherited `PWD`, a shell-local `cd`, an added wrapper, path canonicalization changes, or probe-internal directory changes.
3. Mechanically rebind only the already-required executable harness/configuration/record fields from the closed Lease-03 root to the exact Lease-04 root. The existing static review must inspect those active runtime fields. Do not add a stale-root scanner or inspect truthful prior-path quotations as if they were active bindings.
4. Do not change probe logic, control flow, predicates, schema semantics, expected-result semantics, or the resolved-path equality rule. Probe source-byte changes are limited to the authorized mechanical Lease-03-to-Lease-04 identity, root, filename, record, and fixed-target-hash rebindings.
5. Require the existing resolved-path predicate to pass for both Generation 1 and Generation 2 while their raw CWD fields truthfully record observation; require every other existing environment/cache predicate to pass. Any nonzero exit or mismatch is a defined stop; do not reinvoke the probe under Lease 04.

Lease-03 Generation 1 is the already-observed wrong-CWD failure behavior; Lease-03 Generation 2 is the already-observed correct-CWD pass behavior. Those observations support diagnosis only and transfer no Lease-04 PASS. Because Lease 04 adds no component or predicate, no new disposable CWD control, wrapper, or qualification gate is authorized.

Lease 04 authorizes exactly one mechanically rebound external-harness candidate and no repair/refreeze after the authoritative environment/cache probe. A static-review failure, any need to change a probe-bound artifact or hash, scope expansion, or ambiguity requires a defined stop. This single-candidate rule supersedes the inherited optional second-candidate allowance for Lease 04 and prevents reuse of a PASS after its bound bytes change.

## 7. Frozen prelaunch chain and conditional RUN01 launch

After the once-only cache realization in Section 4 and the one existing-probe invocation in Section 6 pass, continue the remaining existing prelaunch chain exactly as inherited. Do not rerun the bootstrap or the environment/cache inheritance probe:

1. Freeze the external harness, manifest, unified diff, planned placement matrix, expected-result contract, receipts, existing probe, checker, launcher, and durability components.
2. Obtain one role-separated nonauthor static review over the exact frozen bytes. It must confirm that changes are confined to Lease-04 identity/root/filename/record/hash rebinding; probe and gate semantics are unchanged; and the exact frozen probe result truthfully records both generations satisfying the unchanged resolved-path predicate with every non-CWD predicate passing. The order-level OS-workdir instruction remains operationally binding, but the review must certify the observed result rather than infer an unobservable invocation mechanism.
3. Invoke exactly the inherited disposable positive-control checker and then the authoritative checker under the normalized environment. These are the pre-existing checker controls and retain their existing meanings.
4. Publish/read back the checker result, launcher record, supervisor durability result, launcher-bound durability result, and compact prelaunch capsule.

Only after every inherited gate passes may the lease transition to `RUN_LAUNCH_READY` and the outer launcher start the still-unconsumed `NME001-SEO01-EPOCH07-S04-RUN01` exactly once. The launcher handoff is the sole point at which launch count becomes `1` and the attempt is consumed.

The inherited run sequence remains unchanged:

- offline locked environment synchronization;
- exact `981` hermetic collection and complete pass before protected materialization;
- exact nine-placement protected-input custody/readiness gate;
- exact `1,042` licensed-inclusive collection and complete pass;
- protected-placement restoration and rehash;
- unchanged `stage=development` scientific lane over the authorized development prefix only;
- historical-final hold;
- manifest-bound project integrity plus rejection of unlisted paths;
- deterministic double build, complete licensed-byte leakage scan and external receipt;
- role-separated final-return review; and
- either one complete sealed candidate or one defined stop.

No launched run may be retried. No S04 RUN02 is authorized.

## 8. Fail-closed and return rules

Stop, preserve/read back one exact stop record, update Developer role memory in place, close Lease 04, and await Origin if any of the following occurs:

- checkpoint, authority, manifest, inventory, cache, receipt, environment, harness, control, checker, durability, custody, placement, lane, test, science, leakage, observability, or return mismatch;
- any need to alter probe logic/control flow/predicate/schema semantics, add a wrapper, alter the permanent gate surface, change the checkpointed project tree or dependency set, change protected-input rules, or change scientific semantics;
- any prior-lease runtime binding in executable fields;
- any existing-probe or checker-control result outside its exact expected shape;
- protected-input access before all prelaunch gates pass;
- any historical-final payload/outcome access;
- any ambiguous launch count, writer state, or custody state;
- any unauthorized network, provider, acquisition, trading, broker, alerting, automation, disclosure, or destructive action; or
- any required action outside this exact order.

Return only one defined stop or one complete sealed and internally reviewed S04 RUN01 candidate. A complete return is classified only as:

`CANDIDATE_READY_FOR_EXTERNAL_QA / ZERO_SCIENTIFIC_VOTE`

Third-party QA is not a pre-run approval gate for this exact mechanical continuation. Send QA the next defined-stop or sealed-return packet. No role should interrupt Developer while Lease 04 is active unless Developer requests clarification or an external stop condition becomes known.

Authority remains:

```yaml
development_execution: AUTHORIZED_ONCE_UNDER_THE_STILL_UNCONSUMED_S04_RUN01_AFTER_ALL_LEASE04_PREFLIGHT_GATES
development_evidence_authority: NONE / ANY_LATER_ASSIGNMENT_REQUIRES_EXPLICIT_ORIGIN_DISPOSITION_AFTER_COMPLETE_RETURN_AND_THIRD_PARTY_QA
historical_final: HOLD
operational_release: HOLD
formal_predictive_authority: NONE
trading_authority: NONE
broker_authority: NONE
alerting_authority: NONE
automated_action_authority: NONE
```

Proceed autonomously after exact order readback, quiescence confirmation, and Lease-04 claim. Return only at a defined stop or with the complete sealed and internally reviewed S04 RUN01 candidate.
