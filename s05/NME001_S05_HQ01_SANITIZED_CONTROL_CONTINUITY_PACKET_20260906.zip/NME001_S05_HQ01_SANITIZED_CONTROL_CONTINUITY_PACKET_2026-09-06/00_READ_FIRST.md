# Project Nexus — S05-HQ01 Sanitized Control and Continuity Packet

**Packet identity:** `NME001-S05-HQ01-SANITIZED-CONTROL-CONTINUITY-PACKET-01`  
**Prepared:** `2026-09-06T08:03:08Z`  
**Owner:** `ORIGIN`  
**Audience:** `OUTSIDE_QA / OUTSIDE_DEVELOPER`  
**Classification:** `INTERNAL / NO_MARKET_DATA / NO_LICENSED_PAYLOAD / NO_EXECUTION_AUTHORITY`

## Purpose

This packet restores exact-byte continuity after QA context compaction and supplies the outside Developer with the same sanitized control and diagnostic records. It is a shared control-context packet, not a scientific result, run order, qualified harness, or self-contained execution kit.

## Precedence

1. `NME001_ORIGIN_EPOCH07_S04_RUN01_STOP_ACCEPTANCE_AND_S05_HARNESS_QUALIFICATION_CHARTER_2026-09-06.md` is the sole current work-and-scope authority in this packet.
2. `NME001_ORIGIN_EXTERNAL_DEVELOPER_IDENTITY_BRIDGE_2026-09-06.md` controls external content identity and custody translation only.
3. The exact Lease-02, Lease-03, and Lease-04 stop bytes control their historical facts. The Lease-04 order and harness donor are retired diagnostic/regression material and grant no current authority.
4. `NME001_ORIGIN_S05_HQ01_CURRENT_STATE_RECONCILIATION_2026-09-06.md` reconciles status only. It creates no new work authority.
5. If any summary conflicts with an exact controlling record, the exact record bytes control within that record's proper scope.

## Member classifications

| Member | Classification |
| --- | --- |
| S05-HQ01 charter | `CURRENT_CONTROLLING_WORK_AUTHORITY` |
| External Developer identity bridge | `CURRENT_EXTERNAL_IDENTITY_RULE` |
| Origin current-state reconciliation | `CURRENT_STATUS / NO_NEW_WORK_AUTHORITY` |
| Lease-02, Lease-03, Lease-04 defined stops | `EXACT_TERMINAL_FACTS / DIAGNOSTIC / REGRESSION_SPECIFICATION` |
| Lease-04 order | `RETIRED_ORDER / DIAGNOSTIC_CONTEXT_ONLY` |
| Lease-04 harness donor bundle | `SANITIZED_DIAGNOSTIC_DONOR / NOT_QUALIFIED / NOT_EVIDENCE` |
| `SHA256SUMS.txt` | `INTERNAL_MEMBER_INTEGRITY_LIST` |

## Separate execution dependency

The small packet deliberately omits the public offline uv cache. S05-HQ01 requires that separate nonprotected dependency before qualification can execute:

- size: `148,782,742` bytes;
- SHA-256: `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7`.

The outside Developer must possess and verify those exact bytes separately. Absence of the cache is a preflight block; it is not authority to substitute dependencies or use network resolution.

## Deliberate exclusions

This packet contains no TradingView licensed CSV, Kibot or other raw/derived market data, acceptance-package member content, historical-final byte or outcome, accepted S04 project-source checkpoint, mutable runtime/WIP, virtual environment, cache payload, credential, screenshot, or role-memory/Compass copy.

Verify every entry in `SHA256SUMS.txt` before use. The outer ZIP identity is reported separately because a file cannot bind its own containing archive.
