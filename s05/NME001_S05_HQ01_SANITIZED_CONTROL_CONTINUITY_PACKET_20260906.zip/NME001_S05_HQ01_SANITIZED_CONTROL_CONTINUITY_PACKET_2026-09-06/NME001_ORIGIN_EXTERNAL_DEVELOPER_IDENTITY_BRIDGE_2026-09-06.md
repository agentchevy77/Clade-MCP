# Project Nexus — External Developer Identity Bridge

**Record identity:** `NME001-ORIGIN-EXTERNAL-DEVELOPER-IDENTITY-BRIDGE-01`  
**Issued:** `2026-09-06T07:11:24Z`  
**Owner:** `ORIGIN`  
**Disposition:** `ADOPTED / EXTERNAL_CONTENT_IDENTITIES_ACCEPTED / LIBRARY_IDENTITIES_ASSIGNED_ONLY_AFTER_INGESTION`  
**Scientific effect:** `ZERO_AUTHORIZED_SCIENTIFIC_SEMANTIC_EFFECT`

## Purpose and precedence

This record defines the custody translation for an outside Developer working on the current Project Nexus assignment. It changes no scope, gate, run, test, evidence, data-access, hold, or authority rule in the controlling charter.

For the current assignment, the exact bytes of `NME001_ORIGIN_EPOCH07_S04_RUN01_STOP_ACCEPTANCE_AND_S05_HARNESS_QUALIFICATION_CHARTER_2026-09-06.md`, SHA-256 `fdca00109fe9bb078b745151eaa15b510f1db80f75046a4003732694f1676198`, remain controlling. This bridge controls only how externally created source and records are identified and later mapped into Nexus custody.

An outside Developer must not invent, predict, or claim ChatGPT Library IDs, backing-file IDs, or Library versions. Before ingestion, exact content identity—not a storage locator—is authoritative.

## Required external identities

### Source state

Every frozen source return must state:

1. repository origin or an explicit `LOCAL_ONLY` classification;
2. Git object format as reported by Git;
3. full base commit object ID;
4. full base tree object ID;
5. full return commit object ID;
6. full return tree object ID;
7. clean-worktree result, including staged, unstaged, untracked, and relevant ignored inputs;
8. SHA-256 of a full-index binary diff from base to return plus a sorted changed-path/status/mode list;
9. SHA-256 of a canonical manifest covering every returned regular file by relative path, mode, and byte size; and
10. SHA-256 and byte size of the immutable transfer archive and Git bundle.

Branch names, tags, pull-request numbers, URLs, chat links, timestamps, filenames, and abbreviated commits are descriptive locators only. They are not sufficient identities.

All source and test changes must be committed before a checkpoint is declared. Required source must not remain untracked or hidden among ignored executable/configuration inputs. Qualification and review must use the exact return commit in a clean isolated checkout. After sealing, do not amend, rebase, force-push, or otherwise replace that commit. If Nexus later rebases or cherry-picks it, Origin must issue an explicit external-commit-to-integrated-commit mapping and verify tree or executed-byte equivalence.

The stated base must be an ancestor of the return commit unless the controlling order explicitly authorizes another topology. Enumerate every result commit and its parent object IDs; an unexpected merge, unrelated history, or omitted intermediate commit is a defined stop.

Declare Git submodules, Git LFS, `.gitattributes`, checkout filters, and line-ending behavior as either `NONE` or fully enumerated. For each used submodule, bind its URL, gitlink commit, clean state, and executed-byte manifest. For Git LFS, bind both the pointer OID and the materialized object's byte size and SHA-256. Unresolved pointers or unavailable required Git objects are a defined stop.

The commit object ID identifies committed history. It does not alone identify untracked files, realized LFS objects, submodule contents, or checkout-filter output. The SHA-256 manifest and archive digest identify the exact delivered and executed bytes, including evidence and other files outside Git. Neither substitutes for the other.

### Non-source records and evidence

Every receipt, log, JUnit, manifest, report, checkpoint archive, and return package must be bound by:

- exact relative path or filename;
- byte size;
- SHA-256; and
- an immutable record identity stated inside the record where the format permits.

The execution receipt must also bind the result commit/tree and executed-byte manifest to the exact command lines, dependency-lock SHA-256, interpreter and relevant tool versions, operating system and architecture, sanitized environment allowlist, exit codes, and UTC start/end times. Redact secret values without omitting the names of environment variables that can affect execution.

Before and after qualification, produce the same canonical, bytewise-path-sorted manifest over every consumed source, test, and configuration entry as realized in the execution tree. Record relative path, entry type, mode, byte size, and SHA-256 for regular files. For symlinks, record the exact link target; do not represent a symlink as a regular-file digest. Keep virtual environments, caches, logs, and outputs outside the source tree or declare their exact exclusions. Any pre/post manifest drift is a defined stop.

A package-level manifest must cover all delivered members and explicitly exclude only itself to avoid self-reference. The sealed outer package must then be bound by an external SHA-256 receipt. If reproducible packaging is claimed, member order, timestamps, modes, compression settings, and path encoding must be fixed and documented; otherwise claim only the exact identity of the delivered archive.

### Independent resolvability

The outside Developer must supply either:

- access to the exact Git objects at the stated commits; or
- a Git bundle containing the required base and return objects.

If neither is possible, the source archive plus its complete SHA-256 manifest remains usable for diagnostic byte inspection only. The commit claim is classified `REPORTED_NOT_INDEPENDENTLY_RESOLVED`, is not eligible for acceptance, and requires a new Origin disposition.

Signatures are welcome but not mandatory unless a later order requires them. A signature authenticates an actor; it does not replace byte digests.

Before return, scan the Git bundle, sealed archive, and every archive member for secrets and prohibited licensed/raw data. Record the scan scope, tool or method, result, and scan-record SHA-256. For this S05-HQ01 assignment the permitted protected-data count is zero.

## Nexus ingestion mapping

After receipt, Origin or Steward will:

1. verify the external archive/package SHA-256 before opening it;
2. verify the internal manifest and, when available, the Git commit and tree objects;
3. preserve the exact received bytes;
4. ingest accepted files into Nexus custody; and
5. issue a mapping receipt from each external record identity, commit/tree identity, filename, size, and SHA-256 to its assigned Library ID, backing-file ID, and version.

Library identities created at ingestion are custody locators, not retroactive identities claimed by the outside Developer. Ingestion must not alter the upstream bytes. Any digest mismatch fails closed as `EXTERNAL_TO_LIBRARY_IDENTITY_MISMATCH`.

## Current S05-HQ01 boundary

This bridge authorizes no new work by itself. The controlling S05-HQ01 charter remains the sole authority for the outside Developer's current scope. In particular, S05-HQ01 is synthetic harness qualification only: no real Nexus run, Nexus test import, protected input, licensed fixture, Kibot payload, market row, scientific execution, or historical-final access is authorized.

All formal, predictive, trading, alerting, broker, automated-action, scientific-evidence, and operational-release authority remains `NONE` or `HOLD` exactly as already defined.
