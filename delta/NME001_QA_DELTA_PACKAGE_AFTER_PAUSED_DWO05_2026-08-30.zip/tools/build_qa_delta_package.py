#!/usr/bin/env python3
"""Build the deterministic post-paused-DWO05 third-party QA delta package."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo


ROOT = Path("/workspace/scratch/175b4094f117")
MATERIALIZED = ROOT / "qa_update_materialized" / "Project Nexus"
OUTPUT = ROOT / "NME001_QA_DELTA_PACKAGE_AFTER_PAUSED_DWO05_2026-08-30.zip"
SCRIPT = ROOT / "NME001_QA_DELTA_PACKAGE_BUILD" / "tools" / "build_qa_delta_package.py"

INPUTS: dict[str, Path] = {
    "00_READ_ME_FIRST/NME001_QA_DELTA_READ_ME_FIRST_2026-08-30.md": ROOT
    / "NME001_QA_DELTA_READ_ME_FIRST_2026-08-30.md",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_CLEAN_RESUMPTION_RECONCILIATION_REPORT.md": MATERIALIZED
    / "NME001_DWO05_CLEAN_RESUMPTION_RECONCILIATION_REPORT.md",
    "01_DWO05_CLEAN_RESUMPTION/NME-001-DWO-05_CLEAN_RESUMPTION_INPUT_BUNDLE.zip": MATERIALIZED
    / "NME-001-DWO-05_CLEAN_RESUMPTION_INPUT_BUNDLE.zip",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_CLEAN_RESUMPTION_LAYER_MANIFEST.json": MATERIALIZED
    / "NME001_DWO05_CLEAN_RESUMPTION_LAYER_MANIFEST.json",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_CHECKPOINT_TO_CLEAN_RESUMPTION_DIFF.json": MATERIALIZED
    / "NME001_DWO05_CHECKPOINT_TO_CLEAN_RESUMPTION_DIFF.json",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_RAW_FIXTURE_FREE_SCAN.json": MATERIALIZED
    / "NME001_DWO05_RAW_FIXTURE_FREE_SCAN.json",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_ENVIRONMENT_DEPENDENCY_RECORD.json": MATERIALIZED
    / "NME001_DWO05_ENVIRONMENT_DEPENDENCY_RECORD.json",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_NON_AUTHOR_QA_REVIEW.md": MATERIALIZED
    / "NME001_DWO05_NON_AUTHOR_QA_REVIEW.md",
    "01_DWO05_CLEAN_RESUMPTION/pytest_dwo05_clean_resumption_hermetic_packaged_cache.xml": MATERIALIZED
    / "pytest_dwo05_clean_resumption_hermetic_packaged_cache.xml",
    "01_DWO05_CLEAN_RESUMPTION/NME001_DWO05_CLEAN_RESUMPTION_RETURN_SHA256SUMS.txt": MATERIALIZED
    / "NME001_DWO05_CLEAN_RESUMPTION_RETURN_SHA256SUMS.txt",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/NME001_ORIGIN_DWO05_CLEAN_RESUMPTION_ACCEPTANCE_AND_INFRASTRUCTURE_FREEZE_2026-08-30.md": MATERIALIZED
    / "NME001_ORIGIN_DWO05_CLEAN_RESUMPTION_ACCEPTANCE_AND_INFRASTRUCTURE_FREEZE_2026-08-30.md",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/NME001_DWO05_ORIGIN_INDEPENDENT_HERMETIC_REPRODUCTION_2026-08-30.md": MATERIALIZED
    / "NME001_DWO05_ORIGIN_INDEPENDENT_HERMETIC_REPRODUCTION_2026-08-30.md",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/pytest_dwo05_origin_independent_hermetic.xml": MATERIALIZED
    / "pytest_dwo05_origin_independent_hermetic.xml",
    "03_KIBOT_ACCEPTANCE/NME001_KIBOT_POST_DELIVERY_ACCEPTANCE_EVIDENCE_2026-08-30.zip": ROOT
    / "NME001_KIBOT_POST_DELIVERY_ACCEPTANCE_EVIDENCE_2026-08-30.zip",
    "tools/build_qa_delta_package.py": SCRIPT,
}

EXPECTED = {
    "01_DWO05_CLEAN_RESUMPTION/NME-001-DWO-05_CLEAN_RESUMPTION_INPUT_BUNDLE.zip": "8cb8151a9ef619db96d5f9ed4d8c6ba01f635b309a0224634432b523d952ffbd",
    "01_DWO05_CLEAN_RESUMPTION/pytest_dwo05_clean_resumption_hermetic_packaged_cache.xml": "b2073d7cb51ca34d335ddd01f3f9cc834cf4011d1ce8bbf9607e38302012f197",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/NME001_ORIGIN_DWO05_CLEAN_RESUMPTION_ACCEPTANCE_AND_INFRASTRUCTURE_FREEZE_2026-08-30.md": "08d82c10faa92befdca4e391fd4e04d1399b6d2d78c989516016ad3d63c32f5d",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/NME001_DWO05_ORIGIN_INDEPENDENT_HERMETIC_REPRODUCTION_2026-08-30.md": "c98e9dfcb6cf54b06688e0acba0eb1fc443519c6946a9cf52391c4a9bcee187c",
    "02_ORIGIN_INDEPENDENT_ACCEPTANCE/pytest_dwo05_origin_independent_hermetic.xml": "6a6b71639543fddc902f541fbb3514cf13b4a0130813d5d5db5c226cf1612978",
    "03_KIBOT_ACCEPTANCE/NME001_KIBOT_POST_DELIVERY_ACCEPTANCE_EVIDENCE_2026-08-30.zip": "2784509e4cf3e0ef13b93c6750f3e0a595a5bf0a36971f0d7c3ded2580685eee",
}

FORBIDDEN_OUTER_NAME_PARTS = (
    "SPY.txt",
    "SPY_5MIN_RTH_INTERNAL",
    "private_data",
    "licensed-raw",
    "purchase_screenshot",
)
FORBIDDEN_NESTED_NAME_PARTS = (
    "/data/raw/",
    "SPY.txt",
    "SPY_5MIN_RTH_INTERNAL",
    "private_data/",
    "licensed-raw/",
)
EMAIL_RE = re.compile(rb"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
PASSWORD_LABEL_RE = re.compile(rb"password\s*:", re.I)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def info(name: str) -> ZipInfo:
    value = ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    value.compress_type = ZIP_DEFLATED
    value.create_system = 3
    value.external_attr = 0o100644 << 16
    return value


def inspect_nested_archive(path: Path) -> dict[str, object]:
    with ZipFile(path) as archive:
        names = archive.namelist()
        unsafe = [
            name
            for name in names
            if name.startswith("/")
            or ".." in Path(name).parts
            or any(part in name for part in FORBIDDEN_NESTED_NAME_PARTS)
        ]
        if unsafe:
            raise SystemExit(f"unsafe or licensed nested member names in {path.name}: {unsafe}")
        if len(names) != len(set(names)):
            raise SystemExit(f"duplicate nested member name in {path.name}")
        return {"entry_count": len(names), "unsafe_or_licensed_member_names": []}


def main() -> None:
    missing = [str(path) for path in INPUTS.values() if not path.is_file()]
    if missing:
        raise SystemExit(f"missing inputs: {missing}")

    payloads = {name: path.read_bytes() for name, path in sorted(INPUTS.items())}
    bad_outer = [
        name for name in payloads if any(part in name for part in FORBIDDEN_OUTER_NAME_PARTS)
    ]
    if bad_outer:
        raise SystemExit(f"prohibited outer entries: {bad_outer}")

    mismatches = {
        name: {"expected": expected, "observed": digest(payloads[name])}
        for name, expected in EXPECTED.items()
        if digest(payloads[name]) != expected
    }
    if mismatches:
        raise SystemExit(f"identity mismatch: {mismatches}")

    sensitive_matches = [
        name
        for name, data in payloads.items()
        if not name.endswith(".zip")
        and (EMAIL_RE.search(data) or PASSWORD_LABEL_RE.search(data))
    ]
    if sensitive_matches:
        raise SystemExit(f"credential/PII pattern in plaintext entries: {sensitive_matches}")

    nested = {
        name: inspect_nested_archive(INPUTS[name])
        for name in sorted(payloads)
        if name.endswith(".zip")
    }

    package_scope = {
        "package": "NME001_QA_DELTA_AFTER_PAUSED_DWO05",
        "qa_cutoff": "PAUSED_DWO05_AFTER_THREE_FAIL_CLOSED_ATTEMPTS_BEFORE_ATTEMPT_FOUR",
        "latest_included_state": "SEO01_AUTHORIZED_IN_PROGRESS_NO_FROZEN_RESULT",
        "historical_final_opened": "NO",
        "scientific_result_included": "NO",
        "raw_or_derived_market_rows_included": False,
        "credentials_payment_or_personal_information_included": False,
        "mutable_seo01_worktree_included": False,
        "previous_qa_package_included": False,
        "nested_archive_inspection": nested,
        "entries": [
            {"path": name, "bytes": len(data), "sha256": digest(data)}
            for name, data in sorted(payloads.items())
        ],
    }
    payloads["PACKAGE_SCOPE_AND_CONTENTS.json"] = (
        json.dumps(package_scope, sort_keys=True, separators=(",", ":")) + "\n"
    ).encode("utf-8")
    payloads["SHA256SUMS.txt"] = (
        "\n".join(
            f"{digest(data)}  {name}" for name, data in sorted(payloads.items())
        )
        + "\n"
    ).encode("utf-8")

    with ZipFile(OUTPUT, "w", compression=ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payloads.items()):
            archive.writestr(info(name), data)

    print(
        json.dumps(
            {
                "output": str(OUTPUT),
                "bytes": OUTPUT.stat().st_size,
                "sha256": digest(OUTPUT.read_bytes()),
                "entries": len(payloads),
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
