# NME-001 DWO-05 — Origin Clean-Resumption Acceptance and Infrastructure Freeze

Date: 2026-08-30 UTC  
Decision authority: Project Nexus Origin / Product Owner  
Disposition: `ACCEPT_CLEAN_RESUMPTION_RECONCILIATION — FREEZE_INFRASTRUCTURE — OPERATIONAL_RELEASE_REMAINS_HOLD`

## 1. Executive decision

The DWO-05 clean resumption-input reconciliation is **accepted**.

The submitted clean layer corrects the restart-preservation defect identified in the 2026-08-29 Origin review. It preserves the original 145-member checkpoint byte-for-byte, provides all fourteen exact raw-fixture-free prerequisites, replaces only the four authorized prospective documents with explicit `NOT_RUN` state, and supplies a portable offline dependency realization that independently supports the complete fixture-free test lane.

Origin independently reproduced the fixture-free lane from fresh extractions:

- **922 passed**;
- 61 expected licensed-only cases deselected;
- zero failures, errors, or skips;
- exit status 0;
- exact frozen 922-case digest; and
- exact frozen 983-case collection-only inventory binding; no licensed case was executed.

No P0, P1, or P2 defect was found in the checksum-governed return.

This acceptance closes the clean-reconciliation assignment. It does **not** create or accept a DWO-05 release candidate, qualify a licensed-data destination, authorize fixture movement, complete the release matrix, resolve the earlier filesystem-restoration hypothesis, create a scientific result, or elevate any authority.

The infrastructure phase is now frozen. DWO-05 Developer activity stops unless Origin later issues a new destination-specific order. No DWO-06 is created.

## 2. Submitted identities accepted

| Item | Bytes | SHA-256 | Origin result |
|---|---:|---|---|
| Clean resumption input bundle | 4,005,350 | `8cb8151a9ef619db96d5f9ed4d8c6ba01f635b309a0224634432b523d952ffbd` | PASS |
| Public offline uv cache, Linux x86-64 / CPython 3.12 | 148,782,742 | `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7` | PASS |
| Preserved pause checkpoint | 1,358,185 | `dd02872e2c5911b1020b35db81743bae360e0a423f7293a43e4663c6a0e7d1f6` | PASS, unchanged |
| Developer packaged-cache JUnit | 135,232 | `b2073d7cb51ca34d335ddd01f3f9cc834cf4011d1ce8bbf9607e38302012f197` | PASS as submitted evidence |
| Clean-layer manifest | 71,825 | `a6ed0f1e55bfbc9892eaef3940b44a1765137312f49c3bee8ff50d5905c04b30` | PASS |
| Checkpoint-to-layer diff | 13,064 | `abd2a3d6acfd9d0b930e34c6f5555442993275e6a846d55cd4ab4d65a3d2efcd` | PASS |
| Raw-fixture-free scan | 12,959 | `6e9ad6b2a1494ca2ecae2ca570b2f934b5c1b2c38606ea6aa3fb571e6853097c` | PASS within disclosed scope |
| Environment/dependency record | 14,972 | `58bbb2bad7999fefed0f5814b8fb1f075f165657014671bd025334702d89474f` | PASS |
| Developer reconciliation report | 6,606 | `21416cc19f3c5e19b23d3bd2a911c5280a35adbfbed0a5b67b25c752c7e02cae` | Accepted with Origin qualifications |
| Developer non-author QA | 2,439 | `46bc3a927bb598999d78633094fb94724bae6af7d1eaf182df51fba1b1253dfb` | Advisory evidence accepted |

All fifteen entries in the submitted checksum list independently passed. The checksum list itself is 1,782 bytes with SHA-256 `a014da22f4cb368407f93a275b604d4110b02d5995c6acdb4ea30f7c666aa54e`; like any ordinary self-excluding checksum list, it has no detached signature. The separately supplied primary bundle identity matches exactly.

## 3. Package, checkpoint, and deterministic-composition findings

### Clean bundle

The accepted clean bundle contains exactly 159 unique, regular, unencrypted, CRC-clean members under one safe root. No traversal path, symlink, duplicate, case/Unicode collision, archive comment, unsafe prefix, or trailing payload was found.

The 159-record whole-layer manifest independently matches every canonical path, size, SHA-256, provenance class, authority class, and consumer. Its allowlist digest independently recomputes to:

`87017946929bce2261f27686d0f72d50183cc203a2f021f64b0aaa634602df35`

Direct comparison with the preserved checkpoint establishes exactly:

| Relation | Count |
|---|---:|
| Byte-identical checkpoint members | 141 |
| Authorized documentary replacements | 4 |
| Exact prerequisites added | 14 |
| Removed checkpoint paths | 0 |

The four replacements are only:

- `docs/DWO05_REPRODUCTION.md`;
- `docs/DWO05_VERIFICATION_REPORT.md`;
- `docs/NEXUS_DEV_RETURN_DWO05.md`; and
- `docs/material_attempt_ledger_dwo05.md`.

Each explicitly records `NOT_RUN`, `HOLD`, or `NONE`. The original checkpoint and its patch remain untouched. No scientific source, test, configuration, protocol, governance contract, final identity, or authority member changed.

All fourteen added prerequisites match the exact canonical path, size, and hash table in the prior Origin order. The deterministically recovered DWO-05 output-relation file remains identity recovery of historical bytes only; it is not new licensed execution or evidence.

### Offline dependency realization

The cache archive contains 8,933 unique, regular, unencrypted, path-safe members. Its internal package manifest binds 8,932 non-self members; the payload manifest binds all 8,928 cache files; and all 31 reconstructed relative-link mappings remain within the cache root.

Origin independently verified each package/payload member and link mapping. The bootstrap script verified and reconstructed the fresh cache, and `uv sync --locked --extra dev --offline` completed without network resolution. The cache is platform-bound to Linux x86-64, CPython 3.12, and the recorded toolchain; it is not represented as universally portable.

Origin also independently re-emitted every governed member of both primary archives using the frozen ZIP metadata and compression policy. Both reconstructed archives were byte-identical to the submitted originals, reproducing the two primary SHA-256 values above. This verifies deterministic archive encoding and governed composition. It does not independently re-download or re-attest the upstream registry provenance of every public dependency wheel.

## 4. Origin independent fixture-free execution

Fresh input roots were created from the submitted bundle and cache. No submitted working environment or Developer virtual environment was reused.

Environment:

- Linux 6.18.35, x86-64;
- glibc 2.39;
- CPython 3.12.13;
- uv 0.11.33;
- git 2.51.1;
- `TZ=UTC`; and
- no inherited project/Python/pytest injection variables.

Execution:

| Check | Independent result |
|---|---|
| Cache bootstrap | PASS — 8,928 files verified; 31 bounded links recreated |
| Locked offline sync | PASS |
| Fixture-free selected lane | 922/922 PASS |
| Licensed-only deselections | 61, expected |
| Failures / errors / skips | 0 / 0 / 0 |
| Exit status | 0 |
| Duration | 439.42 seconds |
| Ordered 922-case digest | `7baf3ae855cc94a15ca26c484e7b2fb324024b9a6d5fe68262e8f3c9a5e2dc2c` |
| Collected-only 983-case inventory binding | `15138cc5ffc83929e566b1024270cd62e6ec8d70d57c1500cf28763cbd3ea12e` |

The ordered test identities match the Developer inventory exactly. Nested offline subprocess and distribution controls passed, including the sealed DWO-03 reproduction, two fresh DWO-04 builds, environment-injection stripping, locked-offline collection, clean-root raw exclusion, and synthetic-sentinel exclusion.

New Origin evidence:

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| Independent reproduction report | 5,893 | `c98e9dfcb6cf54b06688e0acba0eb1fc443519c6946a9cf52391c4a9bcee187c` |
| Independent JUnit | 135,229 | `6a6b71639543fddc902f541fbb3514cf13b4a0130813d5d5db5c226cf1612978` |
| Test transcript | 1,222 | `80229573a0003627d056a49841131a0a01542433af491c839a8fb126d1047ac5` |

`UV_OFFLINE=1`, `UV_NO_CONFIG=1`, and `--offline` enforced offline package resolution. No network access was observed or required for completion; because the executor was not placed in a kernel-level network namespace and socket activity was not audited, absence of every attempted network operation was not independently proven.

## 5. Custody and raw-fixture-free result

No separately held fixture was sought, opened, read, hashed, restored, copied, moved, uploaded, or used by Origin.

Independent review established:

- `data/raw` remained absent before and after the fresh execution;
- neither governed archive has a member path equal to or containing a registered fixture filename;
- neither contains a complete member with a registered fixture's size/SHA-256 identity;
- direct-layer fixture-name/hash occurrences are path-attributed non-payload metadata;
- recursive inspection of the 159-member clean bundle, its 109-member DWO-03 archive, its 133-member DWO-04 archive, and the 109-member DWO-03 archive nested inside DWO-04 covered 510 logical archive-member observations with no `data/raw` member path, registered fixture filename path, complete registered fixture size/SHA-256 identity, or CSV/Parquet/Arrow/Feather payload member;
- the dependency archive and its recursively inspected objects contain no registered fixture name, hash, identity, or raw path; and
- standalone and integrated synthetic path/name/whole-byte/row/fragment controls pass.

The intended limitations remain:

```yaml
direct_held_fixture_byte_comparison: NOT_RUN_PENDING_DESTINATION_SPECIFIC_FIXTURE_AUTHORITY
real_row_scan: NOT_RUN_PENDING_DESTINATION_SPECIFIC_FIXTURE_AUTHORITY
real_fragment_scan: NOT_RUN_PENDING_DESTINATION_SPECIFIC_FIXTURE_AUTHORITY
transformation_or_semantic_equivalence_proven: false
licensed_fixtures: EXTERNAL_HELD_NOT_BUNDLED
```

These limitations are correctly disclosed and do not block acceptance of a fixture-free reconciliation.

## 6. Nonblocking advisories

No P0, P1, or P2 finding remains. The following P3/scope notes are retained:

1. The Developer working directory contains unbound failed-attempt, build, environment, upload-helper, and deterministic-rebuild intermediates. They are not part of the fifteen-entry governed return and must remain excluded from all handoffs.
2. The submitted scan attributes direct-layer literal metadata occurrences but does not enumerate nested logical occurrence paths. Origin's recursive read-only inspection found no nested payload or custody defect. Future scanners may report nested logical paths for completeness; this does not justify reopening DWO-05.
3. The public-cache source record and archive identities are bound, and offline execution passes, but Origin did not independently fetch every wheel again from the registry.
4. Offline package resolution was enforced at the tool level, not by a separate kernel network namespace.

None changes the accepted identity, fixture-free execution result, or authority boundary.

## 7. Scientific interpretation and program direction

This acceptance is an engineering result, not a market-science result.

It proves that the clean laboratory can be reconstructed and that its 922 fixture-free checks pass. It does not add a successful model fit, issued forecast, scorable REAL out-of-sample episode, baseline comparison, or evidence for or against conditional predictability near market levels.

Accordingly:

- the DWO-05 clean layer becomes the accepted engineering source from which any later authorized licensed/release closure must begin;
- DWO-04 remains the last retained release-candidate parent until a DWO-05 candidate is legitimately frozen and reviewed;
- no additional packaging or governance patch is authorized now; and
- Project Nexus should next resolve the usable data lane and its licensing/custody terms before choosing a licensed executor.

This avoids selecting a hangar before knowing where the fuel is legally permitted to go. The prepared Kibot inquiry remains a separate, unsent data-lane action. Its sender name, reply address, company-field choice, unchanged message, and action-time confirmation remain required before transmission.

## 8. Exact authority and state

```yaml
origin_clean_resumption_verdict: ACCEPT
dwo05_identity: UNCHANGED
dwo05_clean_layer_status: ACCEPTED_FIXTURE_FREE_RESTART_FOUNDATION
dwo05_engineering_source: ACCEPTED_CLEAN_LAYER
dwo05_release_candidate: NOT_CREATED
dwo04_release_parent: RETAINED_PENDING_DWO05_CANDIDATE
foundation_status: DWO04_RETAINED_PENDING_DWO05
replay_diagnosis: PROVISIONAL_EXTERNAL_FILESYSTEM_RESTORATION_HYPOTHESIS

preserved_checkpoint_integrity: PASS_UNCHANGED
preserved_checkpoint_restart_completeness: FAIL_HISTORICAL
clean_resumption_layer_restart_completeness: PASS_FIXTURE_FREE
fixture_free_origin_reproduction: PASS_922_OF_922
licensed_lane: NOT_RUN_NOT_AUTHORIZED
release_matrix: NOT_RUN_NOT_AUTHORIZED
operational_release: HOLD
isolated_licensed_executor: UNSELECTED
fixture_movement_or_use: NOT_AUTHORIZED
hosted_executor_fixture_upload: NOT_AUTHORIZED

infrastructure_phase: FROZEN_AFTER_CLEAN_RECONCILIATION
developer_action: STOP_PRESERVE_EXACT_RETURN
dwo06_created: false
next_program_action: DATA_LANE_TERMS_COVERAGE_AND_CUSTODY_DECISION

development_evidence_authority: NONE
formal_evidence_authority: NONE
predictive_authority: NONE
trading_authority: NONE
alerting_authority: NONE
automated_action_authority: NONE

scientific_result_added_by_clean_reconciliation: NONE
retained_scientific_disposition: INSUFFICIENT_EVIDENCE
real_scorable_oos_added: 0
historical_final_opened: NO
stage_final: HOLD
new_confirmation_data_authority: HOLD
real_v1_1_development: HOLD_PENDING_CORRECTED_PROTOCOL_AND_SEPARATE_DATA_INGESTION_AUTHORITY
real_v1_2_0_development: NOT_RUN
real_v1_2_1_development: HOLD
real_v1_2_2_development: HOLD
v0_1_0_final_authority: HOLD

kibot_inquiry_authority: AUTHORIZED_SEPARATELY
kibot_inquiry_state: PREPARED_NOT_SENT
kibot_inquiry_execution: NOT_SENT
kibot_send_prerequisites: SENDER_NAME_REPLY_EMAIL_COMPANY_CHOICE_ACTION_TIME_CONFIRMATION
dwo05_provider_contact_scope: NONE
massive_contact_any_form: NOT_AUTHORIZED
account_trial_purchase_credentials_download_ingestion: HOLD
market_data_download_ingestion: HOLD
```

## 9. Origin handoff to Developer

> Origin independently accepts the DWO-05 clean resumption reconciliation. Preserve the exact clean bundle, dependency cache, checksum-governed sidecars, and 145-member checkpoint. The clean layer is the accepted fixture-free engineering restart foundation; DWO-04 remains the retained release parent. No further DWO-05 or DWO-06 work is authorized. Do not access or move licensed fixtures, run the licensed lane or release matrix, freeze a candidate, contact a provider, open a final, or elevate authority. Infrastructure work stops here while Origin resolves the usable data lane and destination-specific custody terms.
