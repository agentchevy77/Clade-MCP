# NME-001 DWO-05 Origin Independent Hermetic Reproduction

Execution date: 2026-08-30 UTC  
Lane: fixture-free hermetic only  
Disposition: `PASS`  
Evidence and scientific authority: `NONE`

## Scope and result

The submitted clean-resumption input bundle was extracted into a new isolated
directory. The separately submitted public offline uv cache was independently
bootstrapped into a new XDG cache, the frozen environment was synchronized in
offline locked mode, and the complete default test lane was run without the
`--licensed-fixtures` flag.

Result: **922 passed, 61 licensed-only deselected, 0 failed, 0 errors, 0
skipped**, exit status 0, in 439.42 seconds.

The new JUnit contains 922 unique named cases. Its canonical ordered named-test
digest is exactly:

`7baf3ae855cc94a15ca26c484e7b2fb324024b9a6d5fe68262e8f3c9a5e2dc2c`

The ordered names match the submitted named-test inventory exactly. A separate
fixture-free collection-binding check returned the frozen full inventory of 983
cases and digest
`15138cc5ffc83929e566b1024270cd62e6ec8d70d57c1500cf28763cbd3ea12e`.

No licensed fixture was accessed, moved, restored, uploaded, or used. The
project's `data/raw` path was absent before and after execution. No licensed CSV
name or registered whole-file byte size existed in either fresh extraction.

## Input identities

| Input | Bytes | SHA-256 |
|---|---:|---|
| Clean resumption bundle | 4,005,350 | `8cb8151a9ef619db96d5f9ed4d8c6ba01f635b309a0224634432b523d952ffbd` |
| Public offline uv cache | 148,782,742 | `c4be633674b2a4edf912be77680865f3c803fa664832cbdf2e8667d9d22c29a7` |
| Frozen `pyproject.toml` | 924 | `12a3c64d3f68f45f5c1764583313f53a2d1cddaa988c8631e545027e50c70049` |
| Frozen `uv.lock` | 49,018 | `7a087d094c0a2c5f058f14941c86566cea750265ee42b1e9fb202668f7476961` |

The supplied checksum list passed in full. Both input archives had unique,
safe, regular, unencrypted members. The clean bundle had 159 files; the cache
archive had 8,933 files.

## Environment

- Linux 6.18.35, x86_64
- glibc 2.39
- CPython 3.12.13
- uv 0.11.33
- git 2.51.1
- `TZ=UTC`
- No inherited `VIRTUAL_ENV`, `UV_PROJECT_ENVIRONMENT`, `PYTHONPATH`,
  `PYTHONHOME`, `PYTEST_ADDOPTS`, or `PYTEST_PLUGINS` value was present.

## Commands

Cache bootstrap, from the extracted cache parent:

```bash
python3 NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64/bootstrap_uv_cache.py \
  --package-root NME001_DWO05_PUBLIC_OFFLINE_UV_CACHE_LINUX_X86_64 \
  --xdg-cache-home /workspace/scratch/175b4094f117/dwo05_independent_hermetic.1J4Cqw/xdg-cache-home
```

Bootstrap result: 8,928 regular files verified and 31 bounded relative links
recreated; status `PASS`; `network_required: false`.

Locked offline synchronization, from the clean project root:

```bash
XDG_CACHE_HOME=/workspace/scratch/175b4094f117/dwo05_independent_hermetic.1J4Cqw/xdg-cache-home \
UV_OFFLINE=1 UV_NO_CONFIG=1 PYTHONDONTWRITEBYTECODE=1 \
uv sync --locked --extra dev --offline
```

Test command:

```bash
XDG_CACHE_HOME=/workspace/scratch/175b4094f117/dwo05_independent_hermetic.1J4Cqw/xdg-cache-home \
UV_OFFLINE=1 UV_NO_CONFIG=1 PYTHONDONTWRITEBYTECODE=1 \
PYTHONHASHSEED=0 PYTHONUTF8=1 TZ=UTC \
uv run --locked --extra dev pytest -q \
  --junitxml=/workspace/scratch/175b4094f117/dwo05_independent_hermetic.1J4Cqw/pytest_dwo05_origin_independent_hermetic.xml
```

Fixture-free binding check:

```bash
XDG_CACHE_HOME=/workspace/scratch/175b4094f117/dwo05_independent_hermetic.1J4Cqw/xdg-cache-home \
UV_OFFLINE=1 UV_NO_CONFIG=1 PYTHONDONTWRITEBYTECODE=1 \
PYTHONHASHSEED=0 PYTHONUTF8=1 TZ=UTC \
uv run --locked --extra dev python -m nexus_nme001.release_dwo05 \
  collection-bindings --project-root .
```

## Nested offline subprocess result

The full lane exercised and passed the nested historical reproduction and
distribution-build controls under the offline cache. Material examples from
the new JUnit include:

- `test_sealed_dwo03_cli_reproduction_remains_exact` — PASS, 149.418 s.
- `test_dwo04_two_fresh_locked_wheel_and_sdist_builds_are_byte_identical` —
  PASS, 5.794 s.
- `test_dwo04_collection_uses_candidate_locked_offline_environment` — PASS.
- `test_dwo04_subprocess_environment_strips_git_uv_python_pytest_injection` —
  PASS.
- `test_dwo05_ordinary_clean_root_build_is_raw_safe_and_retains_no_distribution`
  — PASS.
- `test_dwo05_ordinary_sentinel_present_root_build_excludes_path_name_and_bytes`
  — PASS.

This proves the supplied cache supports the nested processes exercised by the
frozen hermetic suite. `UV_OFFLINE=1` and `--offline` enforced uv's offline
package-resolution path; the executor itself was not placed in a separate
kernel-level network namespace.

## New evidence identities

| Evidence | Bytes | SHA-256 |
|---|---:|---|
| Independent JUnit | 135,229 | `6a6b71639543fddc902f541fbb3514cf13b4a0130813d5d5db5c226cf1612978` |
| Test transcript | 1,222 | `80229573a0003627d056a49841131a0a01542433af491c839a8fb126d1047ac5` |
| Bootstrap transcript | 297 | `ecae2cec7fe0911ec4395954f7951c1f4a194f0aa141789fffb1bea0cd24f6eb` |
| Offline sync transcript | 1,219 | `5f9f1e2c47c0b0e6865688bdf193ad99fd03258d6fef7d2bd5bd312c4f903a7d` |
| Collection-binding transcript | 431 | `d6e707fb58d8358c3467f25dcf666e7f9e6f14f7693b6df342c6f5f6193c5c74` |
| Cache realization receipt | 313 | `82636360d07e5cc2c12ad80ecdefb2c18895863637b80cebfebb5eed69d50413` |

The new JUnit is not expected to be byte-identical to the Developer JUnit
because execution time and timestamp attributes vary. Counts, all-pass state,
the exact ordered case set, and the canonical named-test digest reconcile.

## Discrepancies and boundary

No substantive discrepancy was found in this lane. This reproduction does not
authorize or establish a licensed regression, release matrix, candidate freeze,
scientific result, provider contact, final-holdout access, predictive authority,
or trading authority.
